#
# TABLE STRUCTURE FOR: log_import
#

DROP TABLE IF EXISTS `log_import`;

CREATE TABLE `log_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` text DEFAULT NULL,
  `file` text DEFAULT NULL,
  `wk_input` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (1, '/Applications/MAMP/tmp/php/phpGUSLZn', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 09:52:56');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (2, '/Applications/MAMP/tmp/php/phpa3sPBf', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 09:56:19');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (3, '/Applications/MAMP/tmp/php/phpyPWcS0', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 09:56:24');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (4, '/Applications/MAMP/tmp/php/phplM68hG', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 10:07:12');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (5, '/Applications/MAMP/tmp/php/phpc1lZCU', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 10:07:16');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (6, '/Applications/MAMP/tmp/php/phpM7vXQe', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:28:06');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (7, '/Applications/MAMP/tmp/php/php0ZNcnW', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:28:52');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (8, '/Applications/MAMP/tmp/php/phpBB1CNe', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:29:02');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (9, '/Applications/MAMP/tmp/php/phpJ0oAoC', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:29:07');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (10, '/Applications/MAMP/tmp/php/phpxIcsnn', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:29:29');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (11, '/Applications/MAMP/tmp/php/phpPoYr1v', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:30:17');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (12, '/Applications/MAMP/tmp/php/php9VVouV', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:35:15');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (13, '/Applications/MAMP/tmp/php/phpP5OhY6', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:35:19');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (14, '/Applications/MAMP/tmp/php/phpiwqXcB', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:36:11');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (15, '/Applications/MAMP/tmp/php/phpZmsIzA', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:36:46');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (16, '/Applications/MAMP/tmp/php/phpkvEK8h', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:37:49');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (17, '/Applications/MAMP/tmp/php/phpLXXLHj', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:38:09');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (18, '/Applications/MAMP/tmp/php/phpHsshvP', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:38:13');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (19, '/Applications/MAMP/tmp/php/phprYKeYf', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:38:58');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (20, '/Applications/MAMP/tmp/php/phpb5HwCb', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:39:17');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (21, '/Applications/MAMP/tmp/php/php8upLGe', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:39:30');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (22, '/Applications/MAMP/tmp/php/phphU9D9b', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:40:59');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (23, '/Applications/MAMP/tmp/php/phpVvkrxc', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:42:09');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (24, '/Applications/MAMP/tmp/php/phpjYDp14', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:44:47');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (25, '/Applications/MAMP/tmp/php/phphWENP1', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:45:03');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (26, '/Applications/MAMP/tmp/php/php7xyeBn', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 11:45:30');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (27, '/Applications/MAMP/tmp/php/phpugU7Z9', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 12:18:51');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (28, '/Applications/MAMP/tmp/php/phpsUouRC', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 12:20:30');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (29, '/Applications/MAMP/tmp/php/phpe261mG', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 12:20:35');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (30, '/Applications/MAMP/tmp/php/php5yqbCO', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 12:21:38');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (31, '/Applications/MAMP/tmp/php/phpAZvZh7', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 12:23:02');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (32, '/Applications/MAMP/tmp/php/phppGtugO', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 12:23:31');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (33, '/Applications/MAMP/tmp/php/phpegcHqi', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 12:24:12');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (34, '/Applications/MAMP/tmp/php/phpbARGe8', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 12:25:23');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (35, '/Applications/MAMP/tmp/php/phpkVpZTJ', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 12:26:06');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (36, '/Applications/MAMP/tmp/php/phpgKK2AT', 'format_karyawan_toko_import (3).xlsx', '2023-12-23 12:28:30');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (37, '/Applications/MAMP/tmp/php/phpQX2Zcj', 'format_karyawan_toko_import (2).xlsx', '2023-12-23 12:29:25');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (38, '/Applications/MAMP/tmp/php/phpVpRX51', 'format_karyawan_toko_import (2).xlsx', '2023-12-23 12:29:56');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (39, '/Applications/MAMP/tmp/php/php1J0uty', 'format_karyawan_toko_import (2).xlsx', '2023-12-23 12:31:05');


#
# TABLE STRUCTURE FOR: tbl_alamat_customer
#

DROP TABLE IF EXISTS `tbl_alamat_customer`;

CREATE TABLE `tbl_alamat_customer` (
  `id_alamat` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `provinsi_id` bigint(20) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `kabupaten_id` bigint(20) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  `is_default` int(11) DEFAULT 0,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_alamat`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_alamat_customer` (`id_alamat`, `customer_id`, `provinsi`, `provinsi_id`, `kabupaten`, `kabupaten_id`, `alamat`, `is_active`, `is_default`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '1', 'Bali', '1', 'Badung', '17', 'hhh', 1, 1, 'dhika', NULL, '2023-12-19 19:48:51', NULL);
INSERT INTO `tbl_alamat_customer` (`id_alamat`, `customer_id`, `provinsi`, `provinsi_id`, `kabupaten`, `kabupaten_id`, `alamat`, `is_active`, `is_default`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', '3', 'Bali', '1', 'Badung', '17', 'Jl badung nomor 23', 1, 1, 'Aut aspernatur cupid', NULL, '2023-12-25 06:21:38', NULL);


#
# TABLE STRUCTURE FOR: tbl_banner
#

DROP TABLE IF EXISTS `tbl_banner`;

CREATE TABLE `tbl_banner` (
  `id_banner` bigint(20) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `gambar` text NOT NULL,
  `is_active` int(11) DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `user_input` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user_edit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_banner`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_banner` (`id_banner`, `judul`, `gambar`, `is_active`, `created_at`, `user_input`, `updated_at`, `user_edit`) VALUES ('4', 'tess', '293114066.png', 1, '2023-12-23 01:19:17', 'Sinyo', NULL, NULL);
INSERT INTO `tbl_banner` (`id_banner`, `judul`, `gambar`, `is_active`, `created_at`, `user_input`, `updated_at`, `user_edit`) VALUES ('2', 'Hai riska ku', '1215920095.jpg', 0, '2023-12-22 22:10:55', 'Sinyo', NULL, NULL);
INSERT INTO `tbl_banner` (`id_banner`, `judul`, `gambar`, `is_active`, `created_at`, `user_input`, `updated_at`, `user_edit`) VALUES ('3', 'kiw kiw', '1501226598.png', 1, '2023-12-23 01:18:48', 'Sinyo', '2023-12-23 01:19:06', 'Sinyo');
INSERT INTO `tbl_banner` (`id_banner`, `judul`, `gambar`, `is_active`, `created_at`, `user_input`, `updated_at`, `user_edit`) VALUES ('5', 'haha', '169616792.png', 1, '2023-12-23 01:19:40', 'Sinyo', NULL, NULL);


#
# TABLE STRUCTURE FOR: tbl_barang
#

DROP TABLE IF EXISTS `tbl_barang`;

CREATE TABLE `tbl_barang` (
  `id_barang` bigint(20) NOT NULL AUTO_INCREMENT,
  `kategori_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_kategori',
  `satuan_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_satuan',
  `kode_barang` varchar(255) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `slug_barang` text NOT NULL,
  `barcode_barang` text NOT NULL,
  `harga_pokok` decimal(65,0) NOT NULL,
  `berat_barang` double NOT NULL,
  `deskripsi` text NOT NULL,
  `informasi` text DEFAULT NULL,
  `gambar` text DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_barang`),
  KEY `index_barang` (`id_barang`,`kategori_id`,`satuan_id`,`kode_barang`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('1', '2', '1', 'BRG-000001', 'Wesi yo wesi', 'wesi-yo-wesi', '83246050723878', '12000', '23', '&lt;p&gt;nslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknasklnnslkanlkcnlaknlnlknaskln&lt;/p&gt;\r\n', NULL, '547861551.JPG', 1, 'robby@ardhacodes.com', 'robby@ardhacodes.com', '2023-12-22 01:34:14', '2023-12-26 23:54:20');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', '1', '2', 'BRG-000002', 'wesmari', 'wesmari', '863246050723878', '112367', '459', '&lt;p&gt;maling&lt;/p&gt;\r\n', NULL, NULL, 1, 'robby@ardhacodes.com', 'robby@ardhacodes.com', '2023-12-22 01:35:27', '2023-12-22 03:18:38');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('3', '1', '1', 'BRG-000003', 'Rumah', 'rumah', '573319570098', '250000', '110', 'Meteran Merk Shicibukai panjang 8 Meter', NULL, NULL, 1, 'Sinyo', NULL, '2023-12-22 01:43:12', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('4', '2', '2', 'BRG-000003', 'Makan', 'makan', '514057381841', '110000', '25', 'Merk Zimbabwe', NULL, NULL, 1, 'Sinyo', NULL, '2023-12-22 01:43:12', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('5', '1', '2', 'BRG-000004', 'jkk', 'jkk', '086942852667', '111111', '122', '&lt;p&gt;vshjhjvshjvjshvjh&lt;/p&gt;\r\n', NULL, '857262961.PNG', 1, 'robby@ardhacodes.com', NULL, '2023-12-22 03:14:29', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('6', '1', '1', 'BRG-000005', 'In eos omnis vitae ua', 'in-eos-omnis-vitae-ua', '261670948043', '15000', '29', '&lt;p&gt;Dolorem dolor duis u.&lt;/p&gt;\r\n', NULL, NULL, 1, 'robby@ardhacodes.com', NULL, '2023-12-26 19:29:16', NULL);


#
# TABLE STRUCTURE FOR: tbl_barang_harga_history
#

DROP TABLE IF EXISTS `tbl_barang_harga_history`;

CREATE TABLE `tbl_barang_harga_history` (
  `id_barang_history` bigint(20) NOT NULL AUTO_INCREMENT,
  `barang_id` bigint(20) NOT NULL,
  `kategori_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_kategori',
  `satuan_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_satuan',
  `harga_pokok` decimal(65,0) NOT NULL,
  `berat_barang` double NOT NULL,
  `tanggal_perubahan` datetime NOT NULL,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_barang_history`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('1', '6', '1', '1', '15000', '29', '2023-12-26 19:29:16', 'robby@ardhacodes.com', NULL, '2023-12-26 19:29:16', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', '1', '2', '1', '34000', '0', '2023-12-26 23:30:41', 'robby@ardhacodes.com', NULL, '2023-12-26 23:30:41', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('3', '1', '2', '1', '65000', '0', '2023-12-26 23:31:02', 'robby@ardhacodes.com', NULL, '2023-12-26 23:31:02', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('4', '1', '2', '1', '25000', '85', '2023-12-26 23:51:39', 'robby@ardhacodes.com', NULL, '2023-12-26 23:51:39', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('5', '1', '2', '1', '69000', '85', '2023-12-26 23:52:12', 'robby@ardhacodes.com', NULL, '2023-12-26 23:52:12', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('6', '1', '1', '1', '69000', '85', '2023-12-26 23:52:30', 'robby@ardhacodes.com', NULL, '2023-12-26 23:52:30', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('7', '1', '1', '2', '69000', '85', '2023-12-26 23:53:54', 'robby@ardhacodes.com', NULL, '2023-12-26 23:53:54', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('8', '1', '2', '1', '12000', '23', '2023-12-26 23:54:20', 'robby@ardhacodes.com', NULL, '2023-12-26 23:54:20', NULL);


#
# TABLE STRUCTURE FOR: tbl_barang_keluar
#

DROP TABLE IF EXISTS `tbl_barang_keluar`;

CREATE TABLE `tbl_barang_keluar` (
  `id_barang_keluar` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_detail_id` bigint(20) DEFAULT NULL,
  `harga_id` bigint(20) NOT NULL,
  `jenis_keluar` varchar(100) NOT NULL COMMENT 'TERJUAL DISTRIBUSI',
  `request_id` bigint(20) DEFAULT 0,
  `jml_keluar` bigint(20) NOT NULL,
  `bukti_keluar` text NOT NULL,
  `is_rollback` int(11) DEFAULT 0,
  `user_input` varchar(100) NOT NULL,
  `user_edit` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_barang_keluar`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', NULL, '1', 'DISTRIBUSI', '0', '1', '', 0, 'Sinyo', '', '2023-12-22 01:49:13', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', NULL, '1', 'DISTRIBUSI', '0', '1', '', 0, 'Sinyo', '', '2023-12-22 01:49:33', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', '1', '1', 'TERJUAL', '0', '2', '', 0, 'Kasir bunda', '', '2023-12-22 01:55:19', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('4', '2', '1', 'TERJUAL', '0', '1', '', 0, 'Kasir bunda', '', '2023-12-22 01:57:17', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('5', '3', '1', 'TERJUAL', '0', '1', '', 0, 'Kasir bunda', '', '2023-12-22 02:00:07', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('6', '4', '1', 'TERJUAL', '0', '1', '', 0, 'Kasir bunda', '', '2023-12-22 02:01:18', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('7', '5', '1', 'TERJUAL', '0', '2', '', 0, 'Sinyo', '', '2023-12-22 02:05:07', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('8', '7', '1', 'TERJUAL', '0', '2', '', 0, 'Kasir bunda', '', '2023-12-22 20:45:54', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('9', '8', '1', 'TERJUAL', '0', '1', '', 0, 'Kasir bunda', '', '2023-12-22 21:33:14', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('10', '9', '1', 'TERJUAL', '0', '1', '', 0, 'Kasir bunda', '', '2023-12-22 21:34:00', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('11', '10', '1', 'TERJUAL', '0', '1', '', 0, 'Kasir bunda', '', '2023-12-22 21:36:47', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('12', '11', '1', 'TERJUAL', '0', '1', '', 0, 'Kasir bunda', '', '2023-12-22 21:37:19', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('13', '12', '1', 'TERJUAL', '0', '1', '', 0, 'Kasir bunda', '', '2023-12-22 21:38:40', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('14', '13', '1', 'TERJUAL', '0', '1', '', 0, 'Kasir bunda', '', '2023-12-22 22:38:59', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('15', '14', '1', 'TERJUAL', '0', '3', '', 0, 'Kasir bunda', '', '2023-12-22 23:00:56', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('16', '15', '1', 'TERJUAL', '0', '3', '', 0, 'Kasir bunda', '', '2023-12-22 23:04:54', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('17', NULL, '2', 'DISTRIBUSI', '0', '1', '', 0, 'Usopp', '', '2023-12-22 23:05:23', NULL);


#
# TABLE STRUCTURE FOR: tbl_barang_masuk
#

DROP TABLE IF EXISTS `tbl_barang_masuk`;

CREATE TABLE `tbl_barang_masuk` (
  `id_barang_masuk` bigint(20) NOT NULL AUTO_INCREMENT,
  `toko_id` bigint(20) DEFAULT NULL,
  `barang_id` bigint(20) DEFAULT NULL,
  `jml_masuk` bigint(20) DEFAULT NULL,
  `bukti_beli` text DEFAULT NULL,
  `tipe` varchar(100) DEFAULT NULL COMMENT '''toko_luar'',''gudang''',
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_barang_masuk`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang_masuk` (`id_barang_masuk`, `toko_id`, `barang_id`, `jml_masuk`, `bukti_beli`, `tipe`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '2', '2', '2000', 'bukti struk.PNG', 'toko_luar', 'admin', NULL, '2023-12-22 20:57:39', NULL);
INSERT INTO `tbl_barang_masuk` (`id_barang_masuk`, `toko_id`, `barang_id`, `jml_masuk`, `bukti_beli`, `tipe`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', '1', '2', '20', 'bukti struk.PNG', 'toko_luar', 'admin', NULL, '2023-12-22 21:03:33', NULL);
INSERT INTO `tbl_barang_masuk` (`id_barang_masuk`, `toko_id`, `barang_id`, `jml_masuk`, `bukti_beli`, `tipe`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', '2', '2', '12', 'IMG-20201231-WA0012.jpg', 'gudang', 'robby@ardhacodes.com', NULL, '2023-12-26 03:43:59', NULL);


#
# TABLE STRUCTURE FOR: tbl_barang_temp
#

DROP TABLE IF EXISTS `tbl_barang_temp`;

CREATE TABLE `tbl_barang_temp` (
  `id_barang` bigint(20) NOT NULL AUTO_INCREMENT,
  `kategori_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_kategori',
  `satuan_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_satuan',
  `kode_barang` varchar(255) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `slug_barang` text NOT NULL,
  `barcode_barang` text NOT NULL,
  `harga_pokok` decimal(65,0) NOT NULL,
  `berat_barang` double NOT NULL,
  `deskripsi` text NOT NULL,
  `gambar` text DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_barang`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang_temp` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `gambar`, `is_active`) VALUES ('1', '0', '0', 'BRG-000005', 'Meteran', 'meteran', '612194798088', '50000', '10', 'Meteran Merk Shicibukai panjang 8 Meter', NULL, 1);
INSERT INTO `tbl_barang_temp` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `gambar`, `is_active`) VALUES ('2', '0', '1', 'BRG-000005', 'Batu Zimbawe', 'batu-zimbawe', '613751313163', '10000', '5', 'Merk Zimbabwe', NULL, 1);


#
# TABLE STRUCTURE FOR: tbl_customer
#

DROP TABLE IF EXISTS `tbl_customer`;

CREATE TABLE `tbl_customer` (
  `id_customer` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `hp` varchar(50) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  PRIMARY KEY (`id_customer`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_customer` (`id_customer`, `nama`, `email`, `hp`, `password`, `user_input`, `user_edit`, `created_at`, `updated_at`, `is_active`) VALUES ('1', 'Dhika', 'dhika@gmail.com', '6287770062252', '$2y$10$cN9tigbSGv4BU.li/HSejuKIcrr6gkYhdVh9LKaG5rkPsnKN8jPBe', 'Dhika', 'Dhika', '2023-12-26 12:55:27', '2023-12-26 12:55:27', 1);


#
# TABLE STRUCTURE FOR: tbl_diskon
#

DROP TABLE IF EXISTS `tbl_diskon`;

CREATE TABLE `tbl_diskon` (
  `id_diskon` bigint(20) NOT NULL AUTO_INCREMENT,
  `harga_id` bigint(20) DEFAULT NULL,
  `nama_diskon` varchar(100) DEFAULT NULL,
  `harga_potongan` double DEFAULT NULL,
  `tgl_mulai` date DEFAULT NULL,
  `tgl_akhir` date DEFAULT NULL,
  `minimal_beli` bigint(20) DEFAULT 1,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_active` int(11) DEFAULT 1,
  PRIMARY KEY (`id_diskon`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_diskon` (`id_diskon`, `harga_id`, `nama_diskon`, `harga_potongan`, `tgl_mulai`, `tgl_akhir`, `minimal_beli`, `user_input`, `user_edit`, `created_at`, `updated_at`, `is_active`) VALUES ('3', '1', '12.12', '1000', '2023-12-22', '2024-01-05', '2', 'Sinyo', 'Kasir bunda', '2023-12-22 01:46:47', '2023-12-22 23:00:14', 1);
INSERT INTO `tbl_diskon` (`id_diskon`, `harga_id`, `nama_diskon`, `harga_potongan`, `tgl_mulai`, `tgl_akhir`, `minimal_beli`, `user_input`, `user_edit`, `created_at`, `updated_at`, `is_active`) VALUES ('4', '3', 'Diskon baru', '2000', '2023-12-26', '2023-12-30', '1', 'Sinyo', NULL, '2023-12-26 04:46:20', NULL, 1);


#
# TABLE STRUCTURE FOR: tbl_harga
#

DROP TABLE IF EXISTS `tbl_harga`;

CREATE TABLE `tbl_harga` (
  `id_harga` bigint(20) NOT NULL AUTO_INCREMENT,
  `barang_id` bigint(20) DEFAULT NULL,
  `toko_id` bigint(20) DEFAULT NULL,
  `stok_toko` bigint(20) DEFAULT NULL,
  `harga_jual` double DEFAULT NULL,
  `is_active` int(11) DEFAULT NULL,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_harga`),
  KEY `index_harga` (`id_harga`,`barang_id`,`toko_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '2', '2', '6994', '2222', 1, NULL, 'Sinyo', '2023-12-22 01:45:08', '2023-12-26 03:43:59');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', '2', '1', '32', '2', 1, NULL, 'Usopp', '2023-12-22 03:16:55', '2023-12-22 21:03:33');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', '1', '1', '12', '1', 1, NULL, NULL, '2023-12-22 03:19:17', NULL);


#
# TABLE STRUCTURE FOR: tbl_harga_toko_history
#

DROP TABLE IF EXISTS `tbl_harga_toko_history`;

CREATE TABLE `tbl_harga_toko_history` (
  `id_harga_toko_history` bigint(20) NOT NULL AUTO_INCREMENT,
  `harga_id` bigint(20) NOT NULL,
  `harga_jual` double DEFAULT NULL,
  `is_active` int(11) DEFAULT NULL,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_harga_toko_history`) USING BTREE,
  KEY `index_harga` (`harga_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_karyawan_toko
#

DROP TABLE IF EXISTS `tbl_karyawan_toko`;

CREATE TABLE `tbl_karyawan_toko` (
  `id_karyawan` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_user',
  `toko_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_toko',
  `nama_karyawan` varchar(100) DEFAULT NULL,
  `hp_karyawan` varchar(100) DEFAULT NULL,
  `alamat_karyawan` text DEFAULT NULL,
  `bagian` varchar(100) DEFAULT NULL,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_karyawan`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('1', '29', '2', 'Bule', '123456789012', 'nslkanlkcnlaknlnlknasklnsawe', 'tetap', 'sistem', 'sistem', '2023-12-22 01:27:10', '2023-12-22 01:28:17');
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', '23', '2', 'wikiwk', '12345678909', 'nslkanlkcnlaknlnlknasklnvnv', 'tetap', 'sistem', 'sistem', '2023-12-22 01:28:58', '2023-12-22 01:28:58');
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('3', '4', '2', 'Luffy', '12313478990', 'mslamlkamlmalkma', 'kontrak', 'sistem', 'sistem', '2023-12-22 23:04:40', '2023-12-22 23:04:40');
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('4', '35', '1', 'SakuraXNaruto', '0317874535', 'Sepanjangann', 'tetap', 'sistem', 'sistem', '2023-12-23 00:15:31', '2023-12-23 00:15:31');
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('5', '36', '1', 'Hidup bersamamu', '0317874555', 'Sepanjanganae', 'kontrak', 'sistem', 'sistem', '2023-12-23 00:17:10', '2023-12-23 01:08:22');
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('7', '39', '1', 'Fulan rohman', '62317874511', NULL, NULL, 'Sinyo', NULL, '2023-12-23 12:26:07', NULL);
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('8', '40', '1', 'Fulano ', '62317874511', NULL, NULL, 'Sinyo', NULL, '2023-12-23 12:26:08', NULL);
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('9', '41', '1', 'Fulan rohmantroll', '62317874511', NULL, NULL, 'Sinyo', NULL, '2023-12-23 12:29:57', NULL);
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('10', '42', '1', 'Fulanotroll ', '62317874511', NULL, NULL, 'Sinyo', NULL, '2023-12-23 12:29:57', NULL);
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('11', '43', '1', 'Fulan rohmantrolljing', '62317874511', NULL, NULL, 'Sinyo', NULL, '2023-12-23 12:31:05', NULL);
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('12', '44', '1', 'Fulanotrolljing ', '62317874511', NULL, NULL, 'Sinyo', NULL, '2023-12-23 12:31:06', NULL);


#
# TABLE STRUCTURE FOR: tbl_karyawan_toko_temp
#

DROP TABLE IF EXISTS `tbl_karyawan_toko_temp`;

CREATE TABLE `tbl_karyawan_toko_temp` (
  `role_id` varchar(255) DEFAULT NULL,
  `toko_id` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `nama_karyawan` varchar(100) DEFAULT NULL,
  `hp_karyawan` varchar(100) DEFAULT NULL,
  `alamat_karyawan` text DEFAULT NULL,
  `bagian` varchar(100) DEFAULT NULL,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_kategori
#

DROP TABLE IF EXISTS `tbl_kategori`;

CREATE TABLE `tbl_kategori` (
  `id_kategori` bigint(20) NOT NULL AUTO_INCREMENT,
  `kode_kategori` varchar(255) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL,
  `slug_kategori` text NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_kategori`),
  KEY `index_kategori` (`id_kategori`,`kode_kategori`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('1', 'Sembarang', 'Berat', 'berat', 1, 'sistem', 'sistem', '2023-12-22 01:30:01', '2023-12-22 01:30:01');
INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', 'Mbuh', 'Ringan Sekali Berat', 'ringan-sekali-berat', 1, 'sistem', 'sistem', '2023-12-22 01:30:29', '2023-12-22 01:30:46');


#
# TABLE STRUCTURE FOR: tbl_menu
#

DROP TABLE IF EXISTS `tbl_menu`;

CREATE TABLE `tbl_menu` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(100) NOT NULL,
  `icon` varchar(155) NOT NULL,
  `is_active` int(2) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_menu`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (1, 'Dashboard', 'menu-icon tf-icons bx bx-home-circle', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (2, 'Management Akses', 'menu-icon tf-icons bx bx-lock-open', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (3, 'Toko', 'menu-icon tf-icons bx bxs-store', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (4, 'Barang', 'menu-icon tf-icons bx bxs-buildings', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (5, 'Kasir', 'menu-icon tf-icons bx bxs-wallet', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (6, 'Laporan', 'menu-icon tf-icons bx bxs-report', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (7, 'Setting', 'menu-icon tf-icons bx bxs-cog', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (10, 'tes', 'bx bxl-flask', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (9, 'Marketplace', 'menu-icon tf-icons bx bx-store', 1);


#
# TABLE STRUCTURE FOR: tbl_order
#

DROP TABLE IF EXISTS `tbl_order`;

CREATE TABLE `tbl_order` (
  `id_order` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Opsional berlaku pada marketplace',
  `toko_id` bigint(20) NOT NULL,
  `kode_order` longtext NOT NULL,
  `nama_cust` varchar(100) DEFAULT NULL,
  `hp_cust` varchar(100) DEFAULT NULL,
  `alamat_cust` text DEFAULT NULL,
  `tipe_order` enum('Marketplace','Kasir') NOT NULL,
  `tipe_pengiriman` text NOT NULL,
  `biaya_kirim` decimal(10,0) NOT NULL,
  `bukti_kirim` text DEFAULT NULL,
  `total_order` decimal(16,0) NOT NULL,
  `paidst` int(11) NOT NULL DEFAULT 0,
  `status` int(11) DEFAULT 1 COMMENT '1 = belum konfirmasi, 2 = sudah konfirmasi, 3 = dikemas, 4 = dikirim, 5 = selesai, 99 = dibatalkan',
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_edit` varchar(100) DEFAULT NULL,
  `user_input` varchar(100) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_order`),
  KEY `index_order` (`id_order`,`user_id`,`toko_id`),
  FULLTEXT KEY `kode_order_index` (`kode_order`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('1', NULL, '2', 'cc3713aae52e4dfe8e8296b04afd2272', '', '0', '', 'Kasir', '', '0', NULL, '4444', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 01:55:19');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('2', NULL, '2', '77c1650a15914446965302f1c197a997', '', '0', '', 'Kasir', '', '0', NULL, '2222', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 01:57:17');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('3', NULL, '2', 'cb6bf803c6b04929a8772c86fd367ad1', 'rama', '+6212345678890', 'aaa', 'Kasir', 'jne', '200', NULL, '2222', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 02:00:07');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('4', NULL, '2', '924737237f4f4ccaaba39970b0d304c3', 'lonte', '+621254565689', 'ndoli', 'Kasir', 'JNE', '2000', NULL, '4444', 1, 5, 1, 'robby@ardhacodes.com', 'Kasir bunda', '2023-12-22 02:05:20', '2023-12-22 02:01:18');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('6', NULL, '2', 'da0e766fb54b44bc8c83f7f02a342e3f', 'tes', '+62087645', '0987654', 'Kasir', 'ok', '52', NULL, '4444', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 20:45:54');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('7', NULL, '2', '5cddfb2e24114e1b8c4dc65df96d2ad1', '', '0', '', 'Kasir', '', '0', NULL, '2222', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 21:33:14');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('8', NULL, '2', '34fb109a686448eca686fd1efd0e4155', '', '0', '', 'Kasir', '', '0', NULL, '2222', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 21:33:24');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('9', NULL, '2', 'f1ffe92898504fe6bbeebd25b586ff55', '', '0', '', 'Kasir', '', '0', NULL, '2222', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 21:34:00');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('10', NULL, '2', 'ba5e44ad1fb341368c6b22ce101222a3', '', '0', '', 'Kasir', '', '0', NULL, '2222', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 21:36:31');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('11', NULL, '2', '397389783c0a46a7a3ce6810dee84d09', '', '0', '', 'Kasir', '', '0', NULL, '2222', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 21:36:47');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('12', NULL, '2', '3eb435571387467e818b03863bfe218f', '', '0', '', 'Kasir', '', '0', NULL, '2222', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 21:37:19');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('13', NULL, '2', '00cd517c27ee43c89e928d1acf44a4d6', '', '0', '', 'Kasir', '', '0', NULL, '2222', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 21:38:40');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('14', NULL, '2', 'a6bf313df4b14b2da0cb0612f34c20e9', '', '0', '', 'Kasir', '', '0', NULL, '2222', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 22:38:59');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('15', NULL, '2', '7609c3678dd548f5b46bedb3259572fd', '', '0', '', 'Kasir', '', '0', NULL, '5666', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 23:00:56');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('16', NULL, '2', 'cd5b2363c759444db86beef8619abaa2', 'Gyuuuu', '+62567898', 'skdjkasd', 'Kasir', 'JNE', '15000', NULL, '5666', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-22 23:04:54');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('70', '1', '1', '31c85726566f441db5924c9303ebb2ab', 'Dhika', '6287770062252', 'Bali, Kab.Badung. Alamat rumah : hhh', 'Marketplace', '', '0', NULL, '-1997', 0, 1, 1, NULL, 'Dhika', NULL, '2023-12-26 13:08:13');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('61', '1', '1', 'df442d815c9f4313b501485c6a171fec', 'Dhika', '6287770062252', 'Bali, Kab.Badung. Alamat rumah : hhh', 'Marketplace', '', '0', NULL, '-1997', 0, 1, 1, NULL, 'Dhika', NULL, '2023-12-26 12:57:08');


#
# TABLE STRUCTURE FOR: tbl_order_detail
#

DROP TABLE IF EXISTS `tbl_order_detail`;

CREATE TABLE `tbl_order_detail` (
  `id_order_detail` bigint(20) NOT NULL AUTO_INCREMENT,
  `harga_id` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `qty` bigint(20) DEFAULT NULL,
  `harga_total` double DEFAULT NULL,
  `harga_potongan` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`harga_potongan`)),
  `user_edit` varchar(100) DEFAULT NULL,
  `user_input` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_order_detail`),
  KEY `index_order_detail` (`id_order_detail`,`harga_id`,`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('1', '1', '1', '2', '4444', '[]', NULL, 'Kasir bunda', '2023-12-22 01:55:19', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('2', '1', '2', '1', '2222', '[]', NULL, 'Kasir bunda', '2023-12-22 01:57:17', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('3', '1', '3', '1', '2222', '[]', NULL, 'Kasir bunda', '2023-12-22 02:00:07', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('5', '1', '4', '2', '4444', '[]', NULL, 'robby@ardhacodes.com', '2023-12-22 02:04:04', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('6', '3', '5', '1', '1', '[]', NULL, 'dhika', '2023-12-21 20:25:15', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('7', '1', '6', '2', '4444', '[]', NULL, 'Kasir bunda', '2023-12-22 20:45:54', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('8', '1', '7', '1', '2222', '[]', NULL, 'Kasir bunda', '2023-12-22 21:33:14', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('9', '1', '9', '1', '2222', '[]', NULL, 'Kasir bunda', '2023-12-22 21:34:00', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('10', '1', '11', '1', '2222', '[]', NULL, 'Kasir bunda', '2023-12-22 21:36:47', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('11', '1', '12', '1', '2222', '[]', NULL, 'Kasir bunda', '2023-12-22 21:37:19', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('12', '1', '13', '1', '2222', '[]', NULL, 'Kasir bunda', '2023-12-22 21:38:40', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('13', '1', '14', '1', '2222', '[]', NULL, 'Kasir bunda', '2023-12-22 22:38:59', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('14', '1', '15', '3', '6666', '[{\"id_diskon\":\"3\",\"nama_diskon\":\"12.12\",\"harga_potongan\":\"1000\"}]', NULL, 'Kasir bunda', '2023-12-22 23:00:56', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('15', '1', '16', '3', '6666', '[{\"id_diskon\":\"3\",\"nama_diskon\":\"12.12\",\"harga_potongan\":\"1000\"}]', NULL, 'Kasir bunda', '2023-12-22 23:04:54', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('16', '3', '17', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:22:33', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('17', '2', '17', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:22:33', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('18', '3', '18', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:23:53', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('19', '2', '18', '2', '4', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:23:53', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('20', '2', '19', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:25:12', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('21', '3', '19', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:25:12', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('22', '3', '20', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:29:24', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('23', '2', '20', '2', '4', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:29:24', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('24', '3', '21', '2', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:30:44', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('25', '2', '21', '3', '6', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:30:44', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('26', '3', '22', '3', '3', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:49:31', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('27', '3', '23', '3', '3', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:50:28', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('28', '2', '24', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:51:10', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('29', '3', '24', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:51:10', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('30', '2', '25', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:53:39', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('31', '3', '25', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:53:39', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('32', '3', '26', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:54:44', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('33', '2', '26', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 06:54:44', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('34', '3', '27', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 07:59:53', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('35', '2', '27', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 07:59:53', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('36', '3', '28', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:00:03', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('37', '2', '28', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:00:03', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('38', '2', '29', '3', '6', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:01:32', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('39', '2', '30', '3', '6', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:02:18', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('40', '3', '31', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:07:06', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('41', '3', '32', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:23:49', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('42', '3', '33', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:24:02', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('43', '3', '34', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:27:31', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('44', '2', '35', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:27:55', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('45', '3', '36', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:28:36', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('46', '3', '37', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:28:57', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('47', '2', '38', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:29:16', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('48', '2', '39', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:29:44', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('49', '2', '40', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:30:20', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('50', '2', '41', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:31:42', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('51', '2', '42', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:32:35', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('52', '2', '43', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:33:35', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('53', '2', '44', '5', '10', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:34:22', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('54', '2', '45', '6', '12', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:39:49', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('55', '2', '46', '6', '12', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:40:15', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('56', '2', '47', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:57:45', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('57', '3', '47', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 08:57:45', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('58', '3', '48', '2', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:02:11', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('59', '2', '49', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:06:01', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('60', '2', '50', '3', '6', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:06:33', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('61', '3', '50', '3', '3', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:06:33', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('62', '2', '51', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:17:01', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('63', '3', '51', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:17:01', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('64', '2', '52', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:21:56', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('65', '3', '52', '4', '4', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:21:56', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('66', '3', '53', '3', '3', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:22:55', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('67', '2', '54', '2', '4', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:23:21', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('68', '3', '55', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:23:47', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('69', '2', '55', '1', '2', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:23:47', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('70', '3', '56', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 09:35:15', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('71', '3', '57', '6', '6', '[]', NULL, 'dhika', '2023-12-25 11:02:08', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('72', '3', '58', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 11:29:27', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('73', '3', '59', '1', '1', '[]', NULL, 'Aut aspernatur cupid', '2023-12-25 11:34:24', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('74', '2', '60', '1', '2', '[]', NULL, 'dhika', '2023-12-26 10:10:46', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('75', '3', '60', '1', '1', '[{\"id_diskon\":\"4\",\"nama_diskon\":\"Diskon baru\",\"harga_potongan\":\"2000\"}]', NULL, 'dhika', '2023-12-26 10:10:46', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('76', '2', '61', '1', '2', '[]', NULL, 'Dhika', '2023-12-26 12:57:08', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('77', '3', '61', '1', '1', '[{\"id_diskon\":\"4\",\"nama_diskon\":\"Diskon baru\",\"harga_potongan\":\"2000\"}]', NULL, 'Dhika', '2023-12-26 12:57:08', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('94', '2', '70', '1', '2', '[]', NULL, 'Dhika', '2023-12-26 13:08:13', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('95', '3', '70', '1', '1', '[{\"id_diskon\":\"4\",\"nama_diskon\":\"Diskon baru\",\"harga_potongan\":\"2000\"}]', NULL, 'Dhika', '2023-12-26 13:08:13', NULL);


#
# TABLE STRUCTURE FOR: tbl_order_marketplace
#

DROP TABLE IF EXISTS `tbl_order_marketplace`;

CREATE TABLE `tbl_order_marketplace` (
  `id_order_marketplace` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id_order_marketplace`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_privilege_menu
#

DROP TABLE IF EXISTS `tbl_privilege_menu`;

CREATE TABLE `tbl_privilege_menu` (
  `id_privilege` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`id_privilege`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (1, 1, 1);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (2, 1, 2);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (3, 1, 3);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (4, 1, 4);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (5, 1, 5);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (57, 1, 6);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (7, 1, 7);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (8, 3, 1);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (9, 3, 5);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (10, 3, 4);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (11, 3, 3);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (12, 8, 1);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (13, 8, 2);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (14, 9, 1);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (15, 9, 2);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (16, 9, 3);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (17, 9, 4);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (18, 9, 5);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (19, 9, 6);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (20, 9, 7);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (21, 1, 9);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (22, 8, 3);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (23, 8, 4);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (50, 8, 5);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (58, 1, 10);


#
# TABLE STRUCTURE FOR: tbl_privilege_submenu
#

DROP TABLE IF EXISTS `tbl_privilege_submenu`;

CREATE TABLE `tbl_privilege_submenu` (
  `id_privilege_submenu` int(11) NOT NULL AUTO_INCREMENT,
  `privilege_id` int(11) NOT NULL,
  `submenu_id` int(11) NOT NULL,
  PRIMARY KEY (`id_privilege_submenu`)
) ENGINE=MyISAM AUTO_INCREMENT=90 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (1, 1, 1);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (2, 2, 2);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (3, 2, 3);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (4, 2, 4);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (5, 3, 5);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (11, 3, 6);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (7, 7, 7);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (8, 7, 8);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (10, 2, 9);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (12, 4, 10);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (18, 4, 11);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (19, 5, 14);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (20, 4, 12);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (21, 4, 15);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (22, 3, 16);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (23, 4, 17);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (24, 3, 18);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (25, 5, 19);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (26, 8, 1);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (27, 9, 19);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (28, 9, 14);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (29, 4, 20);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (30, 5, 21);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (31, 5, 22);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (32, 10, 20);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (33, 11, 18);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (88, 57, 30);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (87, 57, 25);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (86, 57, 23);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (37, 12, 1);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (39, 10, 17);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (41, 10, 13);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (42, 14, 1);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (43, 15, 2);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (44, 15, 3);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (45, 15, 4);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (46, 15, 9);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (47, 16, 5);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (48, 16, 6);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (49, 16, 18);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (50, 17, 10);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (51, 21, 29);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (52, 13, 2);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (53, 13, 3);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (54, 13, 4);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (55, 13, 9);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (56, 22, 18);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (57, 22, 6);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (58, 22, 5);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (89, 57, 31);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (79, 50, 14);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (65, 23, 13);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (66, 23, 12);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (67, 23, 11);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (68, 23, 15);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (69, 23, 17);


#
# TABLE STRUCTURE FOR: tbl_request_toko
#

DROP TABLE IF EXISTS `tbl_request_toko`;

CREATE TABLE `tbl_request_toko` (
  `id_request` bigint(20) NOT NULL AUTO_INCREMENT,
  `kode_request` varchar(100) DEFAULT NULL,
  `request_toko_id` bigint(20) DEFAULT NULL,
  `penerima_toko_id` bigint(20) DEFAULT NULL,
  `atribut_barang` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`atribut_barang`)),
  `pengirim` varchar(100) DEFAULT NULL,
  `status` text DEFAULT NULL COMMENT '"proses","terkirim","draft"',
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_request`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_role
#

DROP TABLE IF EXISTS `tbl_role`;

CREATE TABLE `tbl_role` (
  `id_role` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(100) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_role`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (1, 'Administrator', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (2, 'Inventory', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (3, 'Kasir', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (4, 'Customer', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (5, 'coba 2', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (8, 'wikwikwik', 1);


#
# TABLE STRUCTURE FOR: tbl_satuan
#

DROP TABLE IF EXISTS `tbl_satuan`;

CREATE TABLE `tbl_satuan` (
  `id_satuan` bigint(20) NOT NULL AUTO_INCREMENT,
  `satuan` varchar(255) NOT NULL,
  `is_active` int(11) DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_satuan`),
  KEY `index_satuan` (`id_satuan`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('1', 'kg', 1, 'sistem', 'sistem', '2023-12-22 01:31:04', '2023-12-22 01:31:04');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', 'metersss', 1, 'sistem', 'sistem', '2023-12-22 01:31:24', '2023-12-22 01:31:33');


#
# TABLE STRUCTURE FOR: tbl_setting
#

DROP TABLE IF EXISTS `tbl_setting`;

CREATE TABLE `tbl_setting` (
  `id_setting` bigint(20) NOT NULL AUTO_INCREMENT,
  `instansi` varchar(255) NOT NULL,
  `kode_instansi` varchar(255) NOT NULL,
  `alamat_instansi` varchar(255) DEFAULT NULL,
  `owner` varchar(255) NOT NULL,
  `wa_instansi` varchar(255) NOT NULL COMMENT 'Untuk Terdaftar di WA API',
  `wa_admin` varchar(255) NOT NULL COMMENT 'Untuk menerima pesan notifikasi, ketika ada order baru',
  `tlp_instansi` varchar(255) NOT NULL COMMENT 'nomor office kantor\n',
  `ig_instansi` varchar(255) DEFAULT NULL,
  `fb_instansi` varchar(255) DEFAULT NULL,
  `email_instansi` varchar(255) DEFAULT NULL,
  `deskripsi_singkat` text DEFAULT NULL,
  `img_instansi` text DEFAULT NULL,
  PRIMARY KEY (`id_setting`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_setting` (`id_setting`, `instansi`, `kode_instansi`, `alamat_instansi`, `owner`, `wa_instansi`, `wa_admin`, `tlp_instansi`, `ig_instansi`, `fb_instansi`, `email_instansi`, `deskripsi_singkat`, `img_instansi`) VALUES ('1', 'ardhaPOS', 'ARDHAPOS', 'Sidoarjo', 'sembarang', '628787687682', '6281234567898', '2799896', 'wsss', 'ssdff', 'robby@ardhacodes.com', NULL, 'ARDHAPOS1703297315.PNG');


#
# TABLE STRUCTURE FOR: tbl_submenu
#

DROP TABLE IF EXISTS `tbl_submenu`;

CREATE TABLE `tbl_submenu` (
  `id_submenu` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_submenu`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (1, 1, 'Dashboard', 'dashboard', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (2, 2, 'Role', 'role_akses', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (3, 2, 'Menu', 'access/menu', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (4, 2, 'Sub Menu', 'access/submenu', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (5, 3, 'Management Toko', 'toko/store_management', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (6, 3, 'Karyawan Toko', 'toko/karyawan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (7, 7, 'Setting Instansi', 'setting', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (8, 7, 'Backup Database', 'setting/backupdb', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (9, 2, 'User', 'user/index', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (10, 4, 'Kategori', 'barang/kategori', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (11, 4, 'Satuan', 'barang/satuan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (12, 4, 'Barang', 'barang/index', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (13, 4, 'Barang', 'barang/list', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (14, 5, 'Order', 'kasir/order', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (15, 4, 'Barang Masuk', 'barang/masuk', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (17, 4, 'Barang Toko', 'barang/barang_toko', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (18, 3, 'Diskon', 'toko/diskon', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (19, 5, 'Scan', 'kasir/scan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (20, 4, 'Barang Keluar', 'barang/keluar', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (21, 5, 'Sales order', 'kasir/sales_order', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (22, 5, 'Transaksi', 'kasir/transaksi', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (23, 6, 'Laporan Penjualan', 'laporan/penjualan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (24, 6, 'Riwayat Transaksi', 'riwayat/transaksi', 0);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (25, 6, 'Laporan Transaksi', 'laporan/transaksi', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (26, 2, 'Ahhhyeah', 'ayeh', 0);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (27, 6, 'kentir', 'paijo', 0);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (28, 2, 'Dugem Malam', 'www.porn.com', 0);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (29, 9, 'Banner', 'marketplace/banner', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (30, 6, 'Laporan Pendapatan', 'laporan/pendapatan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (31, 6, 'Laporan Laba Rugi', 'laporan/laba_rugi', 1);


#
# TABLE STRUCTURE FOR: tbl_toko
#

DROP TABLE IF EXISTS `tbl_toko`;

CREATE TABLE `tbl_toko` (
  `id_toko` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama_toko` varchar(255) NOT NULL,
  `alamat_toko` text NOT NULL,
  `notelp_toko` varchar(15) NOT NULL,
  `jenis` varchar(255) NOT NULL COMMENT 'MARKETPLACE | TOKO',
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_edit` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_toko`),
  KEY `index_toko` (`id_toko`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', 'Marketplace', 'sdkjfsdkjfh', '9876', 'MARKETPLACE', 1, 'aa', 'ss', '2023-12-22 01:23:21', '2023-12-22 01:23:25');
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', 'Marketplace Shopee', 'shope', '987689792', 'TOKO', 1, '', 'ss', '2023-12-22 01:24:45', '2023-12-22 01:23:25');
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', 'Jarjit', 'hxjchsvjcv', '62812344556', 'TOKO', 1, 'Sinyo', NULL, '2023-12-22 23:06:04', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('4', 'laura', 'ahsjhsdsa', '628123445561313', 'TOKO', 1, 'Sinyo', NULL, '2023-12-22 23:07:00', NULL);


#
# TABLE STRUCTURE FOR: tbl_transaksi
#

DROP TABLE IF EXISTS `tbl_transaksi`;

CREATE TABLE `tbl_transaksi` (
  `id_transaksi` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) DEFAULT NULL,
  `kode_transaksi` text DEFAULT NULL,
  `terbayar` double DEFAULT 0 COMMENT 'Nominal Customer Membayar',
  `kembalian` double DEFAULT 0 COMMENT 'Nominal Kembalian Customer',
  `tagihan_cart` double DEFAULT NULL COMMENT 'Tagihan Keranjang',
  `total_diskon` double DEFAULT NULL COMMENT 'Jumlah Keseluruhan Diskon',
  `tagihan_after_diskon` double DEFAULT NULL COMMENT 'Tagihan Keranjang - Total Diskon',
  `total_biaya_kirim` double DEFAULT NULL COMMENT 'Jumlah Nominal Biaya Kirim',
  `total_tagihan` double DEFAULT NULL COMMENT 'Total Tagihan = Tagihan After Diskon + Biaya Kirim',
  `tipe_transaksi` varchar(255) DEFAULT NULL COMMENT '"TRANSFER","TUNAI"',
  `bukti_tf` text DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `index_kodetrans` (`kode_transaksi`(1000)),
  KEY `index_transaksi` (`id_transaksi`,`order_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '1', 'INV-2023120000000001', '4445', '1', '4444', '0', '4444', '0', '4444', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 01:55:19', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', '2', 'INV-2023120000000002', '3000', '778', '2222', '0', '2222', '0', '2222', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 01:57:17', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', '3', 'INV-2023120000000003', '3000', '578', '2222', '0', '2222', '200', '2422', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 02:00:07', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('4', '4', 'INV-2023120000000004', '4222', '0', '2222', '0', '2222', '2000', '4222', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 02:01:18', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('5', '4', 'INV-2023120000000005', '6444', '0', '4444', '0', '4444', '2000', '6444', 'transfer', 'bukti-bayar-2023-12-22-02-05-07.PNG', 1, 'Sinyo', NULL, '2023-12-22 02:05:07', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('6', '6', 'INV-2023120000000006', '4500', '4', '4444', '0', '4444', '52', '4496', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 20:45:54', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('7', '7', 'INV-2023120000000007', '2222', '0', '2222', '0', '2222', '0', '2222', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 21:33:14', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('8', '8', 'INV-2023120000000008', '2222', '0', '2222', '0', '2222', '0', '2222', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 21:33:24', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('9', '9', 'INV-2023120000000009', '2222', '0', '2222', '0', '2222', '0', '2222', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 21:34:00', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('10', '10', 'INV-2023120000000010', '2222', '0', '2222', '0', '2222', '0', '2222', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 21:36:31', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('11', '11', 'INV-2023120000000011', '2222', '0', '2222', '0', '2222', '0', '2222', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 21:36:47', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('12', '12', 'INV-2023120000000012', '2222', '0', '2222', '0', '2222', '0', '2222', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 21:37:19', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('13', '13', 'INV-2023120000000013', '2444', '222', '2222', '0', '2222', '0', '2222', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 21:38:40', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('14', '14', 'INV-2023120000000014', '2222', '0', '2222', '0', '2222', '0', '2222', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 22:38:59', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('15', '15', 'INV-2023120000000015', '7500', '1834', '6666', '1000', '5666', '0', '5666', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 23:00:56', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('16', '16', 'INV-2023120000000016', '25000', '4334', '6666', '1000', '5666', '15000', '20666', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-22 23:04:54', NULL);


#
# TABLE STRUCTURE FOR: tbl_user
#

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `nama_user` varchar(200) NOT NULL,
  `password` varchar(225) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (2, 'admin', 'Usopp', '$2y$10$WRUAaHL29AiW5ZM4mZE2zeKD7QMcCCaflL9RZsssmG8zy1PITaFPG', 1, 1, '2023-10-13 15:23:01', '2023-12-20 06:32:03');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (3, 'admin2', 'Admin', '$2y$10$wra8TkSEoRd5kgF2XkEZsO3axZZ1ojfazE9Q3z5z3S6pNUGIh7k6y', 1, 1, '2023-10-14 10:59:56', '2023-10-14 11:00:18');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (4, 'robby@ardhacodes.com', 'Sinyo', '$2y$10$LehzOBWPnnLpkjTMN4V3fON8golwh6AqGhS5EzLWZ1qLBeHqJwvPC', 1, 1, '2023-10-14 11:01:17', '2023-12-22 22:20:26');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (20, 'sincan', 'Sincan', '$2y$10$.nMGzeSIX1lN1BMWZ2MpgOUGzZljfQ7Iy.uPxH1n0J9yx7KLVHAd.', 4, 0, '2023-10-19 14:46:32', '2023-12-22 22:17:12');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (23, 'kasirbunda', 'Kasir bunda', '$2y$10$3hidutyU527IuhgfQlsC3OezDrzI2Ra9z4Zy3gMpZ3qi5IdA9cJAC', 3, 1, '2023-11-16 07:23:21', '2023-12-22 23:29:54');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (29, 'luffy', 'Luffy Senpai', '$2y$10$.zLH48W8CFzOAr3YH/zdL.05Aa4.jKCwLtm0.gH7DQP9QLaNeP2V2', 3, 1, '2023-12-21 22:27:24', '2023-12-22 23:20:00');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (31, 'meimeijing', 'Meimei', '$2y$10$QyG8oAMpIuq69mRIj92LiOsezSzEvXyOuDUgOZefhMgdAM/GNmM6e', 2, 0, '2023-12-23 00:05:11', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (32, 'Meimei', 'Meimei', '$2y$10$FWfk61qMqQY6oxKDxkJuzellOphholJK20nflsuFqxL6V36OILxn.', 2, 0, '2023-12-23 00:06:28', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (33, 'ntnt', 'ntnt', '$2y$10$/eh/o4UWk3U6IzLEaFxB5.jvWRBz7etXpfq9FpGe8qhEbG1.2UpCK', 1, 0, '2023-12-23 00:09:08', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (34, 'kontolkontolkontolll', 'kontolkontolkontolll', '$2y$10$s6IljosOhrKXI2117hDHXed7xXtI2HarLvCcEqs38RH8xYTWQFarK', 1, 0, '2023-12-23 00:14:33', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (35, 'SakuraXNaruto', 'SakuraXNaruto', '$2y$10$5IEp6MgqAhpYz0i5m6rjiePIvzZ8tgJJN6DHEdJf39oguokSX1y42', 2, 1, '2023-12-23 00:15:31', '2023-12-23 00:16:04');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (36, 'Hidup bersamamu', 'Hidup bersamamu', '$2y$10$acH.P2QE0/DXylhZUwetZ.PGV0luJmx.M8wPdpGiCx5xfWISTDIy6', 2, 1, '2023-12-23 00:17:10', '2023-12-23 01:08:22');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (40, 'Fulano123', 'Fulano ', '$2y$10$9x45/EJEgSEQtKL.4t/XMuJimwvFDFxQ0AUqWgGkXuqNHcs19Z9um', 1, 1, '2023-12-23 12:26:07', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (39, 'Fulan123', 'Fulan rohman', '$2y$10$EqMZ6OkpwXUw/.p5b6lWDeuStM6DDn5pjgXBOisEbdby4.gxjQ5ka', 1, 1, '2023-12-23 12:26:07', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (41, 'Fulan1235', 'Fulan rohmantroll', '$2y$10$u08YGvEz/PTo.nZXfVKuHOVQ0TmR37ql/LpWkStg78d7uxSLd17Hu', 1, 1, '2023-12-23 12:29:57', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (42, 'Fulano1235', 'Fulanotroll ', '$2y$10$hOPvl82gIF8sksM6Fv61sephdtUMIgHogbSqfM7D2jAvPZrMlKUfS', 1, 1, '2023-12-23 12:29:57', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (43, 'Fulan12356', 'Fulan rohmantrolljing', '$2y$10$QoFjp5KDuzDWs1QTztoEcO8HlipVR8XYVpvMk96bXtchquxA8U71q', 2, 1, '2023-12-23 12:31:05', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (44, 'Fulano12356', 'Fulanotrolljing ', '$2y$10$B25BuTdFEn0/0QZN1hSRs.XTiponq6S/ClEMn1RjBxkzWbnEfcUeu', 3, 1, '2023-12-23 12:31:06', NULL);


