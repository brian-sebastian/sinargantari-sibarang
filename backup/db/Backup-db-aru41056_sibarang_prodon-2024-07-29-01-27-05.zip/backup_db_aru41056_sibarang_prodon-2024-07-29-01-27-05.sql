#
# TABLE STRUCTURE FOR: log_import
#

DROP TABLE IF EXISTS `log_import`;

CREATE TABLE `log_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` text DEFAULT NULL,
  `file` text DEFAULT NULL,
  `wk_input` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (1, '/tmp/phpvJhsuJ', 'format_barang_toko_import_2.xlsx', '2024-07-07 19:54:54');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (2, '/tmp/php7kRNS3', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:08:06');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (3, '/tmp/phpyCjnxL', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:08:26');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (4, '/tmp/phpDxnTTh', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:09:02');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (5, '/tmp/phpMHmhpj', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:09:19');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (6, '/tmp/phpI82mjN', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:10:32');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (7, '/tmp/phpwjtCf0', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:11:51');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (8, '/tmp/phpRcRtAf', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:12:42');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (9, '/tmp/php8okAye', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:14:29');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (10, '/tmp/php9rvXGP', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:15:34');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (11, '/tmp/phpK3tuaa', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:16:07');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (12, '/tmp/phpc86Ux6', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:16:10');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (13, '/tmp/phpMN6CuM', 'format_barang_toko_import_2 (5).xlsx', '2024-07-07 20:16:44');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (14, '/tmp/phpvPDeNG', 'format_barang_toko_import_2.xlsx', '2024-07-08 19:50:44');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (15, '/tmp/phpOF0Ei6', 'format_barang_toko_import_2.xlsx', '2024-07-14 11:44:33');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (16, '/tmp/phpIZksQT', 'format_barang_toko_import_2.xlsx', '2024-07-14 11:45:15');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (17, '/tmp/phpkGlOoM', 'format_barang_toko_import_2 (6).xlsx', '2024-07-14 12:17:18');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (18, '/tmp/phpnTp6ld', 'format_barang_toko_import_2 (6).xlsx', '2024-07-14 12:18:56');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (19, '/tmp/php9HfBuH', 'format_barang_toko_import_2 (6).xlsx', '2024-07-14 12:19:58');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (20, '/tmp/phpSfFexN', 'format_barang_toko_import.xlsx', '2024-07-14 12:57:31');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (21, '/tmp/php3Dq6TL', 'format_barang_toko_import.xlsx', '2024-07-14 13:09:54');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (22, '/tmp/phpn89bDc', 'format_barang_toko_import.xlsx', '2024-07-14 13:11:23');


#
# TABLE STRUCTURE FOR: tbl_alamat_customer
#

DROP TABLE IF EXISTS `tbl_alamat_customer`;

CREATE TABLE `tbl_alamat_customer` (
  `id_alamat` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `provinsi_id` bigint(20) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `kabupaten_id` bigint(20) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  `is_default` int(11) DEFAULT 0,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_alamat`),
  KEY `FK_alamat_customer` (`customer_id`),
  CONSTRAINT `FK_alamat_customer` FOREIGN KEY (`customer_id`) REFERENCES `tbl_customer` (`id_customer`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_bank
#

DROP TABLE IF EXISTS `tbl_bank`;

CREATE TABLE `tbl_bank` (
  `id_bank` bigint(20) NOT NULL AUTO_INCREMENT,
  `bank` varchar(255) DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_bank`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_bank` (`id_bank`, `bank`, `is_active`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES ('3', 'BCA', 1, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_bank` (`id_bank`, `bank`, `is_active`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES ('2', 'Muamalat', 1, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_bank` (`id_bank`, `bank`, `is_active`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES ('4', 'BNI', 1, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tbl_banner
#

DROP TABLE IF EXISTS `tbl_banner`;

CREATE TABLE `tbl_banner` (
  `id_banner` bigint(20) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `gambar` text NOT NULL,
  `is_active` int(11) DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `user_input` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user_edit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_banner`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_barang
#

DROP TABLE IF EXISTS `tbl_barang`;

CREATE TABLE `tbl_barang` (
  `id_barang` bigint(20) NOT NULL AUTO_INCREMENT,
  `kategori_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_kategori',
  `satuan_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_satuan',
  `kode_barang` varchar(255) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `slug_barang` text NOT NULL,
  `barcode_barang` text NOT NULL,
  `harga_pokok` decimal(65,0) NOT NULL,
  `berat_barang` double NOT NULL,
  `deskripsi` text NOT NULL,
  `informasi` text DEFAULT NULL,
  `gambar` text DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_barang`),
  KEY `INDEX_BRG` (`id_barang`),
  KEY `INDEX_KODE_BRG` (`kode_barang`),
  KEY `INDEX_BARCODE` (`barcode_barang`(3072))
) ENGINE=InnoDB AUTO_INCREMENT=352 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('104', '6', '24', 'BRG-000001', 'Cuci Piring Standart 600 ML', 'cuci-piring-standart-600-ml', '099539762291', '5500', '600', 'Cuci Piring 600 Ml', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('105', '6', '24', 'BRG-000002', 'Cuci Piring Standart 1500 ML', 'cuci-piring-standart-1500-ml', '774024827453', '13000', '1500', 'Cuci Piring 1500Ml', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('106', '6', '1', 'BRG-000003', 'Cuci Piring Standart 5 kg', 'cuci-piring-standart-5-kg', '775423189755', '41500', '5', 'Cuci piring 5kg', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('107', '6', '1', 'BRG-000004', 'Cuci Piring Standart 5 kg Isi Ulang', 'cuci-piring-standart-5-kg-isi-ulang', '254924305424', '35500', '5', 'Cuci Piring Standart 5 kg Isi Ulang', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('108', '6', '24', 'BRG-000005', 'Cuci Piring Premium 600 ml', 'cuci-piring-premium-600-ml', '663572024648', '7500', '600', 'Cuci Piring premium 600ml', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('109', '6', '24', 'BRG-000006', 'Cuci Piring Premium 1500 ml', 'cuci-piring-premium-1500-ml', '922575880750', '14000', '1500', 'Cuci Piring premium 1500ml', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('110', '6', '1', 'BRG-000007', 'Cuci Piring Premium 5 kg', 'cuci-piring-premium-5-kg', '968274120104', '47500', '5', 'Cuci Piring premium 5kg', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('111', '6', '1', 'BRG-000008', 'Cuci Piring Premium 5 kg Isi Ulang', 'cuci-piring-premium-5-kg-isi-ulang', '062929938109', '41500', '5', 'Cuci Piring premium isi ulang', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('112', '6', '24', 'BRG-000009', 'Softener 600ML   Exotic', 'softener-600ml-exotic', '423939549603', '8500', '600', 'Softener 600ML exotic', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('113', '6', '24', 'BRG-000010', 'Softener 600ML Sakura', 'softener-600ml-sakura', '551243985348', '8500', '600', 'Softener 600ML sakura', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('114', '6', '24', 'BRG-000011', 'Softener 600ML Downy Black', 'softener-600ml-downy-black', '459502193884', '8500', '600', 'Softener 600ML downy black', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('115', '6', '24', 'BRG-000012', 'Softener 600ML  Akasia', 'softener-600ml-akasia', '286573435702', '8500', '600', 'Softener 600ML  Akasia', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('116', '6', '24', 'BRG-000013', 'Softener 600ML  Snapy', 'softener-600ml-snapy', '197911057731', '8500', '600', 'Softener 600ML  Snapy', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('117', '6', '24', 'BRG-000014', 'Softener 600ML Summerday', 'softener-600ml-summerday', '515457703806', '8500', '600', 'Softener 600ML Summerday', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('118', '6', '24', 'BRG-000015', 'Softener 1500ML Downy Black', 'softener-1500ml-downy-black', '698123536300', '18000', '1500', 'Softener 1500ML Downy Black', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('119', '6', '24', 'BRG-000016', 'Softener 1500ML Summerday', 'softener-1500ml-summerday', '230812809797', '18000', '1500', 'Softener 1500ML Summerday', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('120', '6', '24', 'BRG-000017', 'Softener 1500ML Snapy', 'softener-1500ml-snapy', '101345990276', '18000', '1500', 'Softener 1500ML Snapy', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('121', '6', '24', 'BRG-000018', 'Softener 1500ML Sakura', 'softener-1500ml-sakura', '537136346636', '18000', '1500', 'Softener 1500ML Sakura', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('122', '6', '24', 'BRG-000019', 'Softener 1500ML  Exotic', 'softener-1500ml-exotic', '812051865880', '18000', '1500', 'Softener 1500ML  Exotic', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('123', '6', '24', 'BRG-000020', 'Softener 1500ML  Akasia', 'softener-1500ml-akasia', '786764476465', '18000', '1500', 'Softener 1500ML  Akasia', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('124', '6', '1', 'BRG-000021', 'Softener 5KG  Akasia', 'softener-5kg-akasia', '452013871939', '56200', '5', 'Softener 5KG  Akasia', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('125', '6', '1', 'BRG-000022', 'Softener 5KG  Exotic', 'softener-5kg-exotic', '746181067270', '56200', '5', 'Softener 5KG  Exotic', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('126', '6', '1', 'BRG-000023', 'Softener 5KG Summerday', 'softener-5kg-summerday', '949445234396', '56200', '5', 'Softener 5KG Summerday', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('127', '6', '1', 'BRG-000024', 'Softener 5KG  Sakura', 'softener-5kg-sakura', '142509030080', '56200', '5', 'Softener 5KG  Sakura', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('128', '6', '1', 'BRG-000025', 'Softener 5KG  Downy Black', 'softener-5kg-downy-black', '841939365637', '56200', '5', 'Softener 5KG  Downy Black', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('129', '6', '24', 'BRG-000026', 'Softener Royal 330ML  Sakura', 'softener-royal-330ml-sakura', '815093373244', '5100', '330', 'Softener Royal 330ML  Sakura', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('130', '6', '24', 'BRG-000027', 'Softener Royal 330ML Snapy', 'softener-royal-330ml-snapy', '290115466211', '5100', '330', 'Softener Royal 330ML Snapy', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('131', '6', '24', 'BRG-000028', 'Softener Royal 1000ML Sakura', 'softener-royal-1000ml-sakura', '578650931990', '14500', '1000', 'Softener Royal 1000ML Sakura', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('132', '6', '24', 'BRG-000029', 'Softener Royal 1000ML Snapy', 'softener-royal-1000ml-snapy', '976872999124', '14500', '1000', 'Softener Royal 1000ML Snapy', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('133', '6', '1', 'BRG-000030', 'Softener Royal 5KG Sakura', 'softener-royal-5kg-sakura', '484200091438', '65000', '5', 'Softener Royal 5KG Sakura', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('134', '6', '1', 'BRG-000031', 'Softener Royal 5KG Snapy', 'softener-royal-5kg-snapy', '280356884797', '65000', '5', 'Softener Royal 5KG Snapy', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('135', '6', '1', 'BRG-000032', 'Softener Royal 5KG Isi Ulang', 'softener-royal-5kg-isi-ulang', '421061562498', '59000', '5', 'Softener Royal 5KG Isi Ulang', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('136', '6', '24', 'BRG-000033', 'Deterjen Premium 600ML', 'deterjen-premium-600ml', '416819403194', '5500', '600', 'Deterjen Premium 600ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('137', '6', '24', 'BRG-000034', 'Deterjen Premium 1500ML', 'deterjen-premium-1500ml', '617729322424', '13000', '1500', 'Deterjen Premium 1500ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('138', '6', '1', 'BRG-000035', 'Deterjen Premium 5KG', 'deterjen-premium-5kg', '588382889833', '42500', '5', 'Deterjen Premium 5KG', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('139', '6', '1', 'BRG-000036', 'Deterjen Premium 5KG  Isi Ulang', 'deterjen-premium-5kg-isi-ulang', '458194806170', '36500', '5', 'Deterjen Premium 5KG  Isi Ulang', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('140', '6', '24', 'BRG-000037', 'Deterjen Standar 600ML Akasia', 'deterjen-standar-600ml-akasia', '791929437933', '5500', '600', 'Deterjen Standar 600ML Akasia', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('141', '6', '24', 'BRG-000038', 'Deterjen Standar 1500ML Akasia', 'deterjen-standar-1500ml-akasia', '939644571905', '12000', '1500', 'Deterjen Standar 1500ML Akasia', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('142', '6', '24', 'BRG-000039', 'Pelicin setrika 250ML  Spray', 'pelicin-setrika-250ml-spray', '634978852762', '5750', '250', 'Pelicin setrika 250ML  Spray', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('143', '6', '24', 'BRG-000040', 'Pelicin setrika 600ML', 'pelicin-setrika-600ml', '406148577893', '5500', '600', 'Pelicin setrika 600ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('144', '6', '24', 'BRG-000041', 'Pelicin setrika 1500ML', 'pelicin-setrika-1500ml', '560040524352', '11500', '1500', 'Pelicin setrika 1500ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('145', '6', '1', 'BRG-000042', 'Pelicin setrika 5KG', 'pelicin-setrika-5kg', '928659330849', '36000', '5', 'Pelicin setrika 5KG', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('146', '6', '1', 'BRG-000043', 'Pelicin setrika 5KG Isi Ulang', 'pelicin-setrika-5kg-isi-ulang', '989386352110', '30000', '5', 'Pelicin setrika 5KG Isi Ulang', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('147', '6', '24', 'BRG-000044', 'Parfum Laundry 600ML Snapy', 'parfum-laundry-600ml-snapy', '377058736513', '16000', '600', 'Parfum Laundry 600ML Snapy', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('148', '6', '24', 'BRG-000045', 'Parfum Laundry 600ML Summer Day', 'parfum-laundry-600ml-summer-day', '504055257524', '16000', '600', 'Parfum Laundry 600ML Summer Day', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('149', '6', '24', 'BRG-000046', 'Parfum Laundry 600ML  Sakura', 'parfum-laundry-600ml-sakura', '999089828913', '16000', '600', 'Parfum Laundry 600ML  Sakura', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('150', '6', '24', 'BRG-000047', 'Parfum Laundry 600ML Exotic', 'parfum-laundry-600ml-exotic', '237657314899', '16000', '600', 'Parfum Laundry 600ML Exotic', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('151', '6', '24', 'BRG-000048', 'Parfum Laundry 600ML Downy Black', 'parfum-laundry-600ml-downy-black', '742587306295', '16000', '600', 'Parfum Laundry 600ML Downy Black', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('152', '6', '24', 'BRG-000049', 'Parfum Laundry 600ML Akasia', 'parfum-laundry-600ml-akasia', '698222313002', '16000', '600', 'Parfum Laundry 600ML Akasia', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('153', '6', '24', 'BRG-000050', 'Parfum Laundry 1500ML  Snapy', 'parfum-laundry-1500ml-snapy', '252345529612', '37000', '1500', 'Parfum Laundry 1500ML  Snapy', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('154', '6', '24', 'BRG-000051', 'Parfum Laundry 1500ML Exotic', 'parfum-laundry-1500ml-exotic', '826881607224', '37000', '1500', 'Parfum Laundry 1500ML Exotic', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('155', '6', '24', 'BRG-000052', 'Parfum Laundry 1500ML  Sakura', 'parfum-laundry-1500ml-sakura', '930160447796', '37000', '1500', 'Parfum Laundry 1500ML  Sakura', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('156', '6', '24', 'BRG-000053', 'Parfum Laundry 1500ML  Akasia', 'parfum-laundry-1500ml-akasia', '634347274926', '37000', '1500', 'Parfum Laundry 1500ML  Akasia', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('157', '6', '24', 'BRG-000054', 'Parfum Laundry 1500ML Summerday', 'parfum-laundry-1500ml-summerday', '021822847261', '37000', '1500', 'Parfum Laundry 1500ML Summerday', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('158', '6', '24', 'BRG-000055', 'Parfum Laundry 1500ML  Downy Black', 'parfum-laundry-1500ml-downy-black', '239747167806', '37000', '1500', 'Parfum Laundry 1500ML  Downy Black', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('159', '6', '1', 'BRG-000056', 'Parfum Laundry 5KG Summer Day', 'parfum-laundry-5kg-summer-day', '674262004027', '129000', '5', 'Parfum Laundry 5KG Summer Day', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('160', '6', '1', 'BRG-000057', 'Parfum Laundry 5KG  Sakura', 'parfum-laundry-5kg-sakura', '963897314486', '129000', '5', 'Parfum Laundry 5KG  Sakura', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('161', '6', '1', 'BRG-000058', 'Parfum Laundry 5KG Exotic', 'parfum-laundry-5kg-exotic', '974027534290', '129000', '5', 'Parfum Laundry 5KG Exotic', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('162', '6', '1', 'BRG-000059', 'Parfum Laundry 5KG  Snapy', 'parfum-laundry-5kg-snapy', '824026571210', '129000', '5', 'Parfum Laundry 5KG  Snapy', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('163', '6', '1', 'BRG-000060', 'Parfum Laundry 5KG Downy Black', 'parfum-laundry-5kg-downy-black', '304102216035', '129000', '5', 'Parfum Laundry 5KG Downy Black', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('164', '6', '1', 'BRG-000061', 'Parfum Laundry 5KG  Isi Ulang', 'parfum-laundry-5kg-isi-ulang', '480387659938', '123000', '5', 'Parfum Laundry 5KG  Isi Ulang', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('165', '6', '24', 'BRG-000062', 'Karbol Cemara 600ML', 'karbol-cemara-600ml', '633283052090', '5500', '600', 'Karbol Cemara 600ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('166', '6', '24', 'BRG-000063', 'Karbol Cemara 1500ML', 'karbol-cemara-1500ml', '334585979920', '12500', '1500', 'Karbol Cemara 1500ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('167', '6', '1', 'BRG-000064', 'Karbol Cemara 5KG', 'karbol-cemara-5kg', '361281729466', '40000', '5', 'Karbol Cemara 5KG', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('168', '6', '1', 'BRG-000065', 'Karbol Cemara 5KG  Isi Ulang', 'karbol-cemara-5kg-isi-ulang', '283552013706', '34000', '5', 'Karbol Cemara 5KG  Isi Ulang', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('169', '6', '24', 'BRG-000066', 'Karbol Sereh 330ML', 'karbol-sereh-330ml', '207483447538', '4700', '330', 'Karbol Sereh 330ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('170', '6', '24', 'BRG-000067', 'Karbol Sereh 1000ML', 'karbol-sereh-1000ml', '717400085706', '11300', '1000', 'Karbol Sereh 1000ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('171', '6', '1', 'BRG-000068', 'Karbol Sereh 5KG', 'karbol-sereh-5kg', '917703466065', '51000', '5', 'Karbol Sereh 5KG', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('172', '6', '1', 'BRG-000069', 'Karbol Sereh 5KG Isi Ulang', 'karbol-sereh-5kg-isi-ulang', '653107596344', '45000', '5', 'Karbol Sereh 5KG Isi Ulang', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('173', '6', '24', 'BRG-000070', 'Ceratex 330ML', 'ceratex-330ml', '363033579638', '3500', '330', 'Ceratex 330ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('174', '6', '25', 'BRG-000071', 'Ceratex 1 Liter', 'ceratex-1-liter', '865828311026', '9000', '1', 'Ceratex 1 Liter', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('175', '6', '1', 'BRG-000072', 'Ceratex 5KG', 'ceratex-5kg', '240736526540', '40000', '5', 'Ceratex 5KG', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('176', '6', '1', 'BRG-000073', 'Ceratex 5KG  Isi Ulang', 'ceratex-5kg-isi-ulang', '504559127534', '34000', '5', 'Ceratex 5KG  Isi Ulang', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('177', '6', '24', 'BRG-000074', 'Porselen 600ML', 'porselen-600ml', '895137822130', '5500', '600', 'Porselen 600ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('178', '6', '24', 'BRG-000075', 'Porcelen 1500ML', 'porcelen-1500ml', '761535203794', '10500', '1500', 'Porcelen 1500ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('179', '6', '24', 'BRG-000076', 'Pembersih Lantai 600ML  Hijau', 'pembersih-lantai-600ml-hijau', '390896377478', '5500', '600', 'Pembersih Lantai 600ML  Hijau', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('180', '6', '24', 'BRG-000077', 'Pembersih Lantai 600ML  Biru', 'pembersih-lantai-600ml-biru', '281647923691', '5500', '600', 'Pembersih Lantai 600ML  Biru', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('181', '6', '24', 'BRG-000078', 'Pembersih Lantai 1500ML Hijau', 'pembersih-lantai-1500ml-hijau', '761182052352', '12500', '1500', 'Pembersih Lantai 1500ML Hijau', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('182', '6', '24', 'BRG-000079', 'Pembersih Lantai 1500ML Biru', 'pembersih-lantai-1500ml-biru', '796762037635', '12500', '1500', 'Pembersih Lantai 1500ML Biru', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('183', '6', '1', 'BRG-000080', 'Pembersih Lantai 5KG Hijau', 'pembersih-lantai-5kg-hijau', '378639360847', '40000', '5', 'Pembersih Lantai 5KG Hijau', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('184', '6', '1', 'BRG-000081', 'Pembersih Lantai 5KG  Ungu', 'pembersih-lantai-5kg-ungu', '063033578399', '40000', '5', 'Pembersih Lantai 5KG  Ungu', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('185', '6', '1', 'BRG-000082', 'Pembersih Lantai 5KG Isi Ulang', 'pembersih-lantai-5kg-isi-ulang', '113945150105', '34000', '5', 'Pembersih Lantai 5KG Isi Ulang', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('186', '6', '24', 'BRG-000083', 'Shampo Mobil 100ML', 'shampo-mobil-100ml', '429757441916', '1800', '100', 'Shampo Mobil 100ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('187', '6', '24', 'BRG-000084', 'Shampo Mobil 600ML', 'shampo-mobil-600ml', '125824354838', '5500', '600', 'Shampo Mobil 600ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('188', '6', '24', 'BRG-000085', 'Shampo Mobil 1500ML', 'shampo-mobil-1500ml', '022673909894', '12500', '1500', 'Shampo Mobil 1500ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('189', '6', '24', 'BRG-000086', 'Handsoap Botol Fliptop 60 Merah', 'handsoap-botol-fliptop-60-merah', '018195038756', '2300', '60', 'Handsoap Botol Fliptop 60 Merah', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('190', '6', '24', 'BRG-000087', 'Handsoap Botol Fliptop 60 Hijau', 'handsoap-botol-fliptop-60-hijau', '529529051375', '2300', '60', 'Handsoap Botol Fliptop 60 Hijau', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('191', '6', '24', 'BRG-000088', 'Handsoap Botol Fliptop 60 Kuning', 'handsoap-botol-fliptop-60-kuning', '028876893365', '2300', '60', 'Handsoap Botol Fliptop 60 Kuning', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('192', '6', '24', 'BRG-000089', 'Handsoap Botol Fliptop 60 Biru', 'handsoap-botol-fliptop-60-biru', '121458707051', '2300', '60', 'Handsoap Botol Fliptop 60 Biru', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('193', '6', '24', 'BRG-000090', 'Handsoap 100ML Merah', 'handsoap-100ml-merah', '116776722649', '2300', '100', 'Handsoap 100ML Merah', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('194', '6', '24', 'BRG-000091', 'Handsoap 100ML Hijau', 'handsoap-100ml-hijau', '729046001927', '2300', '100', 'Handsoap 100ML Hijau', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('195', '6', '24', 'BRG-000092', 'Handsoap 100ML Kuning', 'handsoap-100ml-kuning', '845535017671', '2300', '100', 'Handsoap 100ML Kuning', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('196', '6', '24', 'BRG-000093', 'Handsoap 100ML Biru', 'handsoap-100ml-biru', '477784593826', '2300', '100', 'Handsoap 100ML Biru', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('197', '6', '24', 'BRG-000094', 'Handsoap 600ML Merah', 'handsoap-600ml-merah', '693716766727', '5800', '600', 'Handsoap 600ML Merah', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('198', '6', '24', 'BRG-000095', 'Handsoap 600ML  Kuning', 'handsoap-600ml-kuning', '456260750008', '5800', '600', 'Handsoap 600ML  Kuning', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('199', '6', '24', 'BRG-000096', 'Handsoap 600ML Hijau', 'handsoap-600ml-hijau', '311286766072', '5800', '600', 'Handsoap 600ML Hijau', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('200', '6', '24', 'BRG-000097', 'Handsoap 600ML Biru', 'handsoap-600ml-biru', '022597483666', '5800', '600', 'Handsoap 600ML Biru', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('201', '6', '24', 'BRG-000098', 'Handsoap 1500ML Merah', 'handsoap-1500ml-merah', '144844621418', '13500', '1500', 'Handsoap 1500ML Merah', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('202', '6', '24', 'BRG-000099', 'Handsoap 1500ML Hijau', 'handsoap-1500ml-hijau', '564958292275', '13500', '1500', 'Handsoap 1500ML Hijau', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('203', '6', '24', 'BRG-000100', 'Handsoap 1500ML Kuning', 'handsoap-1500ml-kuning', '094244803872', '13500', '1500', 'Handsoap 1500ML Kuning', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('204', '6', '24', 'BRG-000101', 'Handsoap 1500ML Biru', 'handsoap-1500ml-biru', '398734832954', '13500', '1500', 'Handsoap 1500ML Biru', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('205', '6', '1', 'BRG-000102', 'Handsoap 5KG Hijau', 'handsoap-5kg-hijau', '936955781159', '40000', '5', 'Handsoap 5KG Hijau', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('206', '6', '1', 'BRG-000103', 'Handsoap 5KG Biru', 'handsoap-5kg-biru', '928317750534', '40000', '5', 'Handsoap 5KG Biru', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('207', '6', '1', 'BRG-000104', 'Handsoap 5KG Merah', 'handsoap-5kg-merah', '832242673980', '40000', '5', 'Handsoap 5KG Merah', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('208', '6', '1', 'BRG-000105', 'Handsoap 5KG Kuning', 'handsoap-5kg-kuning', '228792062682', '40000', '5', 'Handsoap 5KG Kuning', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('209', '6', '1', 'BRG-000106', 'Handsoap 5KG  Isi Ulang', 'handsoap-5kg-isi-ulang', '150591315188', '34000', '5', 'Handsoap 5KG  Isi Ulang', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('210', '6', '24', 'BRG-000107', 'Pembersih Kaca 250ML  kemasan Botol Spray', 'pembersih-kaca-250ml-kemasan-botol-spray', '182810591461', '5600', '250', 'Pembersih Kaca 250ML  kemasan Botol Spray', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('211', '6', '24', 'BRG-000108', 'Pembersih Kaca 600ML', 'pembersih-kaca-600ml', '639641882134', '5500', '600', 'Pembersih Kaca 600ML', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('212', '6', '24', 'BRG-000109', 'Cuci Piring  Pump 500ML', 'cuci-piring--pump-500ml', 'BRG-000109', '12750', '500', '&lt;p&gt;Cuci Piring Standar&lt;/p&gt;\r\n', NULL, NULL, 1, 'owner', 'owner', '2024-07-09 20:06:26', '2024-07-09 20:14:14');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('213', '6', '24', 'BRG-000110', 'Handsoap 500Ml Pump Merah', 'handsoap-500ml-pump-merah', 'BRG-000110', '12000', '500', '&lt;p&gt;Handsoap 500ml Pump&lt;/p&gt;\r\n', NULL, NULL, 1, 'owner', 'owner', '2024-07-09 20:13:16', '2024-07-09 20:14:30');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('214', '6', '24', 'BRG-000111', 'Handsoap 500 Ml Pump Kuning', 'handsoap-500-ml-pump-kuning', 'BRG-000111', '12000', '500', '&lt;p&gt;Handsoap 500Ml Pump Kuning&lt;/p&gt;\r\n', NULL, NULL, 1, 'owner', NULL, '2024-07-09 20:15:24', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('215', '6', '24', 'BRG-000112', 'Handsoap 500Ml Pump Hijau', 'handsoap-500ml-pump-hijau', 'BRG-000112', '12000', '500', '&lt;p&gt;Handsoap 500ml Pumo Hijau&lt;/p&gt;\r\n', NULL, NULL, 1, 'owner', NULL, '2024-07-09 20:16:15', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('216', '6', '24', 'BRG-000113', 'Handsoap 500Ml Pump Biru', 'handsoap-500ml-pump-biru', 'BRG-000113', '12000', '500', '&lt;p&gt;Handsoap 500Ml Pump Biru&lt;/p&gt;\r\n', NULL, NULL, 1, 'owner', NULL, '2024-07-09 20:16:58', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('219', '8', '26', 'BRG-000114', 'MAKUKU COMFORT FIT S 30', 'makuku-comfort-fit-s-30', '592306601581', '44000', '1', 'MAKUKU COMFORT FIT S 30', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('220', '8', '26', 'BRG-000115', 'MAKUKU COMFORT FIT M 28', 'makuku-comfort-fit-m-28', '078159061600', '47000', '1', 'MAKUKU COMFORT FIT M 28', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('221', '8', '26', 'BRG-000116', 'MAKUKU COMFORT FIT XL 24', 'makuku-comfort-fit-xl-24', '330696814599', '56000', '1', 'MAKUKU COMFORT FIT XL 24', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('222', '8', '26', 'BRG-000117', 'MAKUKU DRY CARE M 30', 'makuku-dry-care-m-30', '062924919794', '41000', '1', 'MAKUKU DRY CARE M 30', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('223', '8', '26', 'BRG-000118', 'MAKUKU DRY CARE L 28', 'makuku-dry-care-l-28', '399302112466', '41000', '1', 'MAKUKU DRY CARE L 28', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('224', '8', '26', 'BRG-000119', 'MAKUKU DRY CARE XL 24', 'makuku-dry-care-xl-24', '717024185714', '51000', '1', '&lt;p&gt;MAKUKU DRY CARE XL 24&lt;/p&gt;\r\n', NULL, NULL, 1, 'Owner Toko', 'owner', '2024-07-10 23:26:10', '2024-07-14 13:03:11');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('225', '8', '10', 'BRG-000120', 'MAKUKU FIT PANTS M 1', 'makuku-fit-pants-m-1', '036652104713', '1744', '1', 'MAKUKU FIT PANTS M 1', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('226', '8', '17', 'BRG-000121', 'MAKUKU FIT PANTS M 1 Renceng', 'makuku-fit-pants-m-1-renceng', '191331419035', '10463', '6', 'MAKUKU FIT PANTS M 1 Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('227', '8', '27', 'BRG-000122', 'MAKUKU FIT PANTS M 1 Karton', 'makuku-fit-pants-m-1-karton', '645972465443', '167400', '1', 'MAKUKU FIT PANTS M 1 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('228', '8', '10', 'BRG-000123', 'MAKUKU FIT PANTS L 1', 'makuku-fit-pants-l-1', '234767622745', '1740', '1', 'MAKUKU FIT PANTS L 1', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('229', '8', '17', 'BRG-000124', 'MAKUKU FIT PANTS L 1 Renceng', 'makuku-fit-pants-l-1-renceng', '163415746963', '10438', '6', 'MAKUKU FIT PANTS L 1 Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('230', '8', '27', 'BRG-000125', 'MAKUKU FIT PANTS L 1 Karton', 'makuku-fit-pants-l-1-karton', '811612554171', '167000', '1', 'MAKUKU FIT PANTS L 1 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('231', '8', '10', 'BRG-000126', 'MAKUKU DRYCARE PANTS XL 1', 'makuku-drycare-pants-xl-1', '084546386119', '2175', '1', 'MAKUKU DRYCARE PANTS XL 1', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('232', '8', '17', 'BRG-000127', 'MAKUKU DRYCARE PANTS XL 1 Renceng', 'makuku-drycare-pants-xl-1-renceng', '706981412123', '11125', '6', 'MAKUKU DRYCARE PANTS XL 1 Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('233', '8', '27', 'BRG-000128', 'MAKUKU DRYCARE PANTS XL 1 Karton', 'makuku-drycare-pants-xl-1-karton', '167421223175', '258000', '1', 'MAKUKU DRYCARE PANTS XL 1 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('234', '8', '26', 'BRG-000129', 'MAKUKU DRY CARE PANTS L 44', 'makuku-dry-care-pants-l-44', '347412604812', '66000', '1', 'MAKUKU DRY CARE PANTS L 44', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('235', '8', '26', 'BRG-000130', 'MAKUKU DRY CARE PANTS XL 36', 'makuku-dry-care-pants-xl-36', '062192185306', '69500', '1', 'MAKUKU DRY CARE PANTS XL 36', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('236', '8', '26', 'BRG-000131', 'MAKUKU DRY CARE PANTS XXL 34', 'makuku-dry-care-pants-xxl-34', '435466618103', '69500', '1', 'MAKUKU DRY CARE PANTS XXL 34', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('237', '8', '26', 'BRG-000132', 'MAKUKU AIR DIAPER PRO CARE PANTS', 'makuku-air-diaper-pro-care-pants', '848253058869', '104918', '1', 'MAKUKU AIR DIAPER PRO CARE PANTS', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('238', '8', '10', 'BRG-000133', 'LADIS M', 'ladis-m', '619701325721', '9000', '1', 'LADIS M', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('239', '8', '10', 'BRG-000134', 'LADIS L', 'ladis-l', '020404263425', '9000', '1', 'LADIS L', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('240', '8', '26', 'BRG-000135', 'MAMY POKO PANTS BOY L 34', 'mamy-poko-pants-boy-l-34', '435247982326', '75500', '1', 'MAMY POKO PANTS BOY L 34', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('241', '8', '26', 'BRG-000136', 'MAMY POKO PANTS GIRL L 34', 'mamy-poko-pants-girl-l-34', '104900541366', '75500', '1', 'MAMY POKO PANTS GIRL L 34', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('242', '8', '26', 'BRG-000137', 'MAMY POKO PANTS BOY XL 30', 'mamy-poko-pants-boy-xl-30', '459636582147', '77910', '1', 'MAMY POKO PANTS BOY XL 30', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('243', '8', '26', 'BRG-000138', 'MAMY POKO PANTS GIRL XL 30', 'mamy-poko-pants-girl-xl-30', '787863284568', '77910', '1', 'MAMY POKO PANTS GIRL XL 30', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('244', '8', '26', 'BRG-000139', 'MAMY POKO PANTS BOY XXL 24', 'mamy-poko-pants-boy-xxl-24', '417007753944', '106820', '1', 'MAMY POKO PANTS BOY XXL 24', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('245', '8', '26', 'BRG-000140', 'MAMY POKO PANTS GIRL XXL 24', 'mamy-poko-pants-girl-xxl-24', '995953218343', '106820', '1', 'MAMY POKO PANTS GIRL XXL 24', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('246', '8', '26', 'BRG-000141', 'MAMYPOKO PANTS M 32', 'mamypoko-pants-m-32', '628290349289', '44000', '1', 'MAMYPOKO PANTS M 32', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('247', '8', '26', 'BRG-000142', 'MAMY POKO PANTS L 28', 'mamy-poko-pants-l-28', '112710368791', '44000', '1', 'MAMY POKO PANTS L 28', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('248', '8', '26', 'BRG-000143', 'MAMY POKO PANTS L 42', 'mamy-poko-pants-l-42', '984352977816', '73990', '1', 'MAMY POKO PANTS L 42', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('249', '8', '26', 'BRG-000144', 'MAMY POKO PANTS XL 26', 'mamy-poko-pants-xl-26', '763739277314', '53410', '1', 'MAMY POKO PANTS XL 26', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('250', '8', '26', 'BRG-000145', 'MAMY POKO PANTS XL 38', 'mamy-poko-pants-xl-38', '456432158205', '77420', '1', 'MAMY POKO PANTS XL 38', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('251', '8', '26', 'BRG-000146', 'MAMY POKO PANTS XXL 34', 'mamy-poko-pants-xxl-34', '277110178471', '77420', '1', 'MAMY POKO PANTS XXL 34', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('252', '8', '26', 'BRG-000147', 'MAMY POKO PANTS XXL 24', 'mamy-poko-pants-xxl-24', '805584531091', '58310', '1', 'MAMY POKO PANTS XXL 24', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('253', '8', '10', 'BRG-000148', 'MAMYPOKO S', 'mamypoko-s', '800692259214', '1650', '1', 'MAMYPOKO S', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('254', '8', '17', 'BRG-000149', 'MAMYPOKO S Renceng', 'mamypoko-s-renceng', '633707708628', '16500', '10', 'MAMYPOKO S Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('255', '8', '27', 'BRG-000150', 'MAMYPOKO S Karton', 'mamypoko-s-karton', '403352398220', '198000', '1', 'MAMYPOKO S Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('256', '8', '10', 'BRG-000151', 'MAMYPOKO M', 'mamypoko-m', '995775961249', '1750', '1', 'MAMYPOKO M', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('257', '8', '17', 'BRG-000152', 'MAMYPOKO M Renceng', 'mamypoko-m-renceng', '655724816881', '17500', '10', 'MAMYPOKO M Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('258', '8', '27', 'BRG-000153', 'MAMYPOKO M Karton', 'mamypoko-m-karton', '654460677081', '210000', '1', 'MAMYPOKO M Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('259', '8', '10', 'BRG-000154', 'MAMYPOKO L', 'mamypoko-l', '8993189270819', '1750', '1', 'MAMYPOKO L', NULL, NULL, 1, 'Owner Toko', 'robby@ardhacodes.com', '2024-07-10 23:26:10', '2024-07-27 15:22:35');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('260', '8', '17', 'BRG-000155', 'MAMYPOKO L Renceng', 'mamypoko-l-renceng', '304055300574', '17500', '10', 'MAMYPOKO L Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('261', '8', '27', 'BRG-000156', 'MAMYPOKO L Karton', 'mamypoko-l-karton', '813038762605', '210000', '1', 'MAMYPOKO L Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('262', '8', '10', 'BRG-000157', 'MAMYPOKO XL', 'mamypoko-xl', '445464976437', '2188', '1', 'MAMYPOKO XL', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('263', '8', '17', 'BRG-000158', 'MAMYPOKO XL Renceng', 'mamypoko-xl-renceng', '591089335586', '21880', '10', 'MAMYPOKO XL Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('264', '8', '27', 'BRG-000159', 'MAMYPOKO XL Karton', 'mamypoko-xl-karton', '189302296054', '262500', '1', 'MAMYPOKO XL Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('265', '8', '10', 'BRG-000160', 'MAMYPOKO XXL', 'mamypoko-xxl', '134281011542', '2538', '1', 'MAMYPOKO XXL', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('266', '8', '17', 'BRG-000161', 'MAMYPOKO XXL Renceng', 'mamypoko-xxl-renceng', '192355517346', '25380', '10', 'MAMYPOKO XXL Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('267', '8', '27', 'BRG-000162', 'MAMYPOKO XXL Karton', 'mamypoko-xxl-karton', '322538860466', '304500', '1', 'MAMYPOKO XXL Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('268', '8', '10', 'BRG-000163', 'CHARM 29 Cm', 'charm-29-cm', '072311697308', '2450', '1', 'CHARM 29 Cm', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('269', '8', '17', 'BRG-000164', 'CHARM 29 Cm Renceng', 'charm-29-cm-renceng', '235080147919', '24500', '10', 'CHARM 29 Cm Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('270', '8', '27', 'BRG-000165', 'CHARM 29 Cm Karton', 'charm-29-cm-karton', '522008106286', '588000', '1', 'CHARM 29 Cm Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('271', '8', '10', 'BRG-000166', 'CHARM 35 Cm', 'charm-35-cm', '639827612190', '3000', '1', 'CHARM 35 Cm', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('272', '8', '17', 'BRG-000167', 'CHARM 35 Cm Renceng', 'charm-35-cm-renceng', '687735183924', '30000', '10', 'CHARM 35 Cm Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('273', '8', '27', 'BRG-000168', 'CHARM 35 Cm Karton', 'charm-35-cm-karton', '464483191292', '720000', '1', 'CHARM 35 Cm Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('274', '8', '10', 'BRG-000169', 'CHARM 42 cm NIGHT', 'charm-42-cm-night', '036560250773', '2450', '1', 'CHARM 42 cm NIGHT', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('275', '8', '17', 'BRG-000170', 'CHARM 42 cm NIGHT Renceng', 'charm-42-cm-night-renceng', '879057697951', '24500', '10', 'CHARM 42 cm NIGHT Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('276', '8', '27', 'BRG-000171', 'CHARM 42 cm NIGHT Karton', 'charm-42-cm-night-karton', '448536981072', '588000', '1', 'CHARM 42 cm NIGHT Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('277', '8', '10', 'BRG-000172', 'CHARM Orange extra maxi 23cm 8Play', 'charm-orange-extra-maxi-23cm-8play', '210199930082', '4700', '1', 'CHARM Orange extra maxi 23cm 8Play', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('278', '8', '27', 'BRG-000174', 'CHARM Orange extra maxi 23cm 8Play Karton', 'charm-orange-extra-maxi-23cm-8play-karton', '217059884106', '282000', '1', 'CHARM Orange extra maxi 23cm 8Play Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('279', '8', '10', 'BRG-000175', 'CHARM Orange Extra Maxi 23 cm Wings 7Play', 'charm-orange-extra-maxi-23-cm-wings-7play', '936458940079', '5700', '1', 'CHARM Orange Extra Maxi 23 cm Wings 7Play', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('280', '8', '27', 'BRG-000177', 'CHARM Orange Extra Maxi 23 cm Wings 7Play Karton', 'charm-orange-extra-maxi-23-cm-wings-7play-karton', '997251359966', '342000', '1', 'CHARM Orange Extra Maxi 23 cm Wings 7Play Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('281', '8', '10', 'BRG-000178', 'SWEETY BRONZE PANTS DRY X-PERT S 1', 'sweety-bronze-pants-dry-x-pert-s-1', '417879584212', '1373', '1', 'SWEETY BRONZE PANTS DRY X-PERT S 1 Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('282', '8', '17', 'BRG-000179', 'SWEETY BRONZE PANTS DRY X-PERT S 1 Renceng', 'sweety-bronze-pants-dry-x-pert-s-1-renceng', '462775241360', '8238', '1', 'SWEETY BRONZE PANTS DRY X-PERT S 1 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('283', '8', '27', 'BRG-000180', 'SWEETY BRONZE PANTS DRY X-PERT S 1 Karton', 'sweety-bronze-pants-dry-x-pert-s-1-karton', '811405365695', '163060', '1', 'SWEETY BRONZE PANTS DRY X-PERT M 1', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('284', '8', '10', 'BRG-000181', 'SWEETY BRONZE PANTS DRY X-PERT M 1', 'sweety-bronze-pants-dry-x-pert-m-1', '744801628109', '1536', '1', 'SWEETY BRONZE PANTS DRY X-PERT M 1 Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('285', '8', '17', 'BRG-000182', 'SWEETY BRONZE PANTS DRY X-PERT M 1 Renceng', 'sweety-bronze-pants-dry-x-pert-m-1-renceng', '571787847175', '9216', '1', 'SWEETY BRONZE PANTS DRY X-PERT M 1 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('286', '8', '27', 'BRG-000183', 'SWEETY BRONZE PANTS DRY X-PERT M 1 Karton', 'sweety-bronze-pants-dry-x-pert-m-1-karton', '093939008304', '163384', '1', 'SWEETY BRONZE PANTS DRY X-PERT L 1', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('287', '8', '10', 'BRG-000184', 'SWEETY BRONZE PANTS DRY X-PERT L 1', 'sweety-bronze-pants-dry-x-pert-l-1', '518896435973', '1536', '1', 'SWEETY BRONZE PANTS DRY X-PERT L 1 Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('288', '8', '17', 'BRG-000185', 'SWEETY BRONZE PANTS DRY X-PERT L 1 Renceng', 'sweety-bronze-pants-dry-x-pert-l-1-renceng', '768292368196', '9215', '1', 'SWEETY BRONZE PANTS DRY X-PERT L 1 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('289', '8', '27', 'BRG-000186', 'SWEETY BRONZE PANTS DRY X-PERT L 1 Karton', 'sweety-bronze-pants-dry-x-pert-l-1-karton', '980492596877', '163384', '1', 'SWEETY BRONZE PANTS DRY X-PERT XL 1', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('290', '8', '10', 'BRG-000187', 'SWEETY BRONZE PANTS DRY X-PERT XL 1', 'sweety-bronze-pants-dry-x-pert-xl-1', '838608755660', '1928', '1', 'SWEETY BRONZE PANTS DRY X-PERT XL 1 Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('291', '8', '17', 'BRG-000188', 'SWEETY BRONZE PANTS DRY X-PERT XL 1 Renceng', 'sweety-bronze-pants-dry-x-pert-xl-1-renceng', '180039529565', '11568', '1', 'SWEETY BRONZE PANTS DRY X-PERT XL 1 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('292', '8', '27', 'BRG-000189', 'SWEETY BRONZE PANTS DRY X-PERT XL 1 Karton', 'sweety-bronze-pants-dry-x-pert-xl-1-karton', '405733154462', '195219', '1', 'SWEETY BRONZE PANTS DRY X-PERT XXL 1', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('293', '8', '10', 'BRG-000190', 'SWEETY BRONZE PANTS DRY X-PERT XXL 1', 'sweety-bronze-pants-dry-x-pert-xxl-1', '370229006004', '2000', '1', '&lt;p&gt;SWEETY BRONZE PANTS DRY X-PERT XXL 1 Renceng&lt;/p&gt;\r\n', NULL, NULL, 1, 'Owner Toko', 'owner', '2024-07-10 23:26:10', '2024-07-14 13:04:11');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('294', '8', '17', 'BRG-000191', 'SWEETY BRONZE PANTS DRY X-PERT XXL 1 Renceng', 'sweety-bronze-pants-dry-x-pert-xxl-1-renceng', '032776035287', '8000', '1', '&lt;p&gt;SWEETY BRONZE PANTS DRY X-PERT XXL 1 Karton&lt;/p&gt;\r\n', NULL, NULL, 1, 'Owner Toko', 'owner', '2024-07-10 23:26:10', '2024-07-14 13:04:53');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('295', '8', '27', 'BRG-000192', 'SWEETY BRONZE PANTS DRY X-PERT XXL 1 Karton', 'sweety-bronze-pants-dry-x-pert-xxl-1-karton', '822624813058', '161208', '1', 'SWEETY BRONZE PANTS DRY X-PERT M 5', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('296', '8', '10', 'BRG-000193', 'SWEETY BRONZE PANTS DRY X-PERT M 5', 'sweety-bronze-pants-dry-x-pert-m-5', '575920102300', '1444', '1', 'SWEETY BRONZE PANTS DRY X-PERT M 5 Paket', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('297', '8', '17', 'BRG-000194', 'SWEETY BRONZE PANTS DRY X-PERT M 5 Paket', 'sweety-bronze-pants-dry-x-pert-m-5-paket', '244247046952', '8664', '1', 'SWEETY BRONZE PANTS DRY X-PERT M 5 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('298', '8', '27', 'BRG-000195', 'SWEETY BRONZE PANTS DRY X-PERT M 5 Karton', 'sweety-bronze-pants-dry-x-pert-m-5-karton', '443495995147', '173261', '1', 'SWEETY BRONZE PANTS DRY X-PERT L 5', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('299', '8', '10', 'BRG-000196', 'SWEETY BRONZE PANTS DRY X-PERT L 5', 'sweety-bronze-pants-dry-x-pert-l-5', '147638495708', '1444', '1', 'SWEETY BRONZE PANTS DRY X-PERT L 5 Paket', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('300', '8', '17', 'BRG-000197', 'SWEETY BRONZE PANTS DRY X-PERT L 5 Paket', 'sweety-bronze-pants-dry-x-pert-l-5-paket', '721297088511', '8664', '1', 'SWEETY BRONZE PANTS DRY X-PERT L 5 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('301', '8', '27', 'BRG-000198', 'SWEETY BRONZE PANTS DRY X-PERT L 5 Karton', 'sweety-bronze-pants-dry-x-pert-l-5-karton', '158919125511', '173261', '1', 'SWEETY BRONZE PANTS DRY X-PERT XL 4', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('302', '8', '10', 'BRG-000199', 'SWEETY BRONZE PANTS DRY X-PERT XL 4', 'sweety-bronze-pants-dry-x-pert-xl-4', '709945180878', '1444', '1', 'SWEETY BRONZE PANTS DRY X-PERT XL 4 Paket', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('303', '8', '17', 'BRG-000200', 'SWEETY BRONZE PANTS DRY X-PERT XL 4 Paket', 'sweety-bronze-pants-dry-x-pert-xl-4-paket', '784041064339', '8664', '1', 'SWEETY BRONZE PANTS DRY X-PERT XL 4 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('304', '8', '27', 'BRG-000201', 'SWEETY BRONZE PANTS DRY X-PERT XL 4 Karton', 'sweety-bronze-pants-dry-x-pert-xl-4-karton', '365859902040', '173261', '1', 'SWEETY BRONZE PANTS DRY X-PERT XXL 5', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('305', '8', '10', 'BRG-000202', 'SWEETY BRONZE PANTS DRY X-PERT XXL 5', 'sweety-bronze-pants-dry-x-pert-xxl-5', '164756117791', '1904', '1', 'SWEETY BRONZE PANTS DRY X-PERT XXL 5 Paket', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('306', '8', '17', 'BRG-000203', 'SWEETY BRONZE PANTS DRY X-PERT XXL 5 Paket', 'sweety-bronze-pants-dry-x-pert-xxl-5-paket', '614406000502', '11424', '1', 'SWEETY BRONZE PANTS DRY X-PERT XXL 5 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('307', '8', '27', 'BRG-000204', 'SWEETY BRONZE PANTS DRY X-PERT XXL 5 Karton', 'sweety-bronze-pants-dry-x-pert-xxl-5-karton', '304445231693', '173261', '1', 'SWEETY BRONZE PANTS L 42', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('308', '8', '26', 'BRG-000205', 'SWEETY BRONZE PANTS L 42', 'sweety-bronze-pants-l-42', '789346794104', '64190', '1', 'SWEETY BRONZE PANTS XL 38', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('309', '8', '26', 'BRG-000206', 'SWEETY BRONZE PANTS XL 38', 'sweety-bronze-pants-xl-38', '384355165414', '66640', '1', 'SWEETY BRONZE PANTS DRY XPERT L 28', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('310', '8', '26', 'BRG-000207', 'SWEETY BRONZE PANTS DRY XPERT L 28', 'sweety-bronze-pants-dry-xpert-l-28', '685760255833', '44000', '1', 'SWEETY BRONZE PANTS DRY XPERT M 32', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('311', '8', '26', 'BRG-000208', 'SWEETY BRONZE PANTS DRY XPERT M 32', 'sweety-bronze-pants-dry-xpert-m-32', '876742907056', '44000', '1', 'SWEETY BRONZE PANTS DRY XZONE XL 24', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('312', '8', '26', 'BRG-000209', 'SWEETY BRONZE PANTS DRY XZONE XL 24', 'sweety-bronze-pants-dry-xzone-xl-24', '546624431294', '54618', '1', 'SWEETY BRONZE PANTS DRY XPERT XXL 24', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('313', '8', '26', 'BRG-000210', 'SWEETY BRONZE PANTS DRY XPERT XXL 24', 'sweety-bronze-pants-dry-xpert-xxl-24', '697493059770', '57387', '1', 'SWEETY SILVER PANTS M1', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('314', '8', '10', 'BRG-000211', 'SWEETY SILVER PANTS M1', 'sweety-silver-pants-m1', '393632334561', '1777', '1', 'SWEETY SILVER PANTS M1 Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('315', '8', '17', 'BRG-000212', 'SWEETY SILVER PANTS M1 Renceng', 'sweety-silver-pants-m1-renceng', '281259847495', '10662', '1', 'SWEETY SILVER PANTS M1 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('316', '8', '27', 'BRG-000213', 'SWEETY SILVER PANTS M1 Karton', 'sweety-silver-pants-m1-karton', '256502448405', '170554', '1', 'SWEETY SILVER PANTS L1', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('317', '8', '10', 'BRG-000214', 'SWEETY SILVER PANTS L1', 'sweety-silver-pants-l1', '405154269101', '1777', '1', 'SWEETY SILVER PANTS L1 Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('318', '8', '17', 'BRG-000215', 'SWEETY SILVER PANTS L1 Renceng', 'sweety-silver-pants-l1-renceng', '402049239375', '10662', '1', 'SWEETY SILVER PANTS L1 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('319', '8', '27', 'BRG-000216', 'SWEETY SILVER PANTS L1 Karton', 'sweety-silver-pants-l1-karton', '369558142958', '170554', '1', 'SWEETY SILVER PANTS XL1', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('320', '8', '10', 'BRG-000217', 'SWEETY SILVER PANTS XL1', 'sweety-silver-pants-xl1', '984064625376', '2022', '1', 'SWEETY SILVER PANTS XL1 Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('321', '8', '17', 'BRG-000218', 'SWEETY SILVER PANTS XL1 Renceng', 'sweety-silver-pants-xl1-renceng', '376472472644', '12132', '1', 'SWEETY SILVER PANTS XL1 Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('322', '8', '27', 'BRG-000219', 'SWEETY SILVER PANTS XL1 Karton', 'sweety-silver-pants-xl1-karton', '873015952139', '194141', '1', 'SWEETY SILVER PANTS M 18', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('323', '8', '26', 'BRG-000220', 'SWEETY SILVER PANTS M 18', 'sweety-silver-pants-m-18', '546247086988', '48000', '1', '&lt;p&gt;SWEETY SILVER PANTS M 28&lt;/p&gt;\r\n', NULL, NULL, 1, 'Owner Toko', 'owner', '2024-07-10 23:26:10', '2024-07-14 13:06:13');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('324', '8', '26', 'BRG-000221', 'SWEETY SILVER PANTS M 28', 'sweety-silver-pants-m-28', '897661331210', '48000', '1', '&lt;p&gt;SWEETY SILVER PANTS L 26&lt;/p&gt;\r\n', NULL, NULL, 1, 'Owner Toko', 'owner', '2024-07-10 23:26:10', '2024-07-14 13:05:25');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('325', '8', '26', 'BRG-000222', 'SWEETY SILVER PANTS L 26', 'sweety-silver-pants-l-26', '788965113842', '48000', '1', '&lt;p&gt;SWEETY SILVER PANTS L 18&lt;/p&gt;\r\n', NULL, NULL, 1, 'Owner Toko', 'owner', '2024-07-10 23:26:10', '2024-07-14 13:10:45');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('326', '8', '26', 'BRG-000223', 'SWEETY SILVER PANTS L 18', 'sweety-silver-pants-l-18', '530726857256', '27647', '1', 'SWEETY SILVER PANTS XL 18', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('327', '8', '26', 'BRG-000224', 'SWEETY SILVER PANTS XL 18', 'sweety-silver-pants-xl-18', '146742584724', '46307', '1', 'SWEETY SILVER PANTS XL 24', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('328', '8', '26', 'BRG-000225', 'SWEETY SILVER PANTS XL 24', 'sweety-silver-pants-xl-24', '198274552665', '50361', '1', '&lt;p&gt;CONFIDENCE PANTS TIPIS PAS M 1s&lt;/p&gt;\r\n', NULL, NULL, 1, 'Owner Toko', 'owner', '2024-07-10 23:26:10', '2024-07-14 13:06:46');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('329', '8', '10', 'BRG-000226', 'CONFIDENCE PANTS TIPIS PAS M 1s', 'confidence-pants-tipis-pas-m-1s', '160692317597', '4324', '1', 'CONFIDENCE PANTS TIPIS PAS M 1s Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('330', '8', '17', 'BRG-000227', 'CONFIDENCE PANTS TIPIS PAS M 1s Renceng', 'confidence-pants-tipis-pas-m-1s-renceng', '188957987157', '25944', '1', 'CONFIDENCE PANTS TIPIS PAS M 1s Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('331', '8', '27', 'BRG-000228', 'CONFIDENCE PANTS TIPIS PAS M 1s Karton', 'confidence-pants-tipis-pas-m-1s-karton', '288913779679', '207565', '1', 'CONFIDENCE PANTS TIPIS PAS XL 1s', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('332', '8', '10', 'BRG-000229', 'CONFIDENCE PANTS TIPIS PAS XL 1s', 'confidence-pants-tipis-pas-xl-1s', '024971706073', '6054', '1', 'CONFIDENCE PANTS TIPIS PAS XL 1s Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('333', '8', '17', 'BRG-000230', 'CONFIDENCE PANTS TIPIS PAS XL 1s Renceng', 'confidence-pants-tipis-pas-xl-1s-renceng', '972634295374', '36324', '1', 'CONFIDENCE PANTS TIPIS PAS XL 1s Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('334', '8', '27', 'BRG-000231', 'CONFIDENCE PANTS TIPIS PAS XL 1s Karton', 'confidence-pants-tipis-pas-xl-1s-karton', '292364435363', '290594', '1', 'SOFTEX DAUN SIRIH 23 CM', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('335', '8', '10', 'BRG-000232', 'SOFTEX DAUN SIRIH 23 CM', 'softex-daun-sirih-23-cm', '500672193446', '1000', '1', 'SOFTEX DAUN SIRIH 23 CM Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('336', '8', '17', 'BRG-000233', 'SOFTEX DAUN SIRIH 23 CM Renceng', 'softex-daun-sirih-23-cm-renceng', '624151023759', '9000', '1', 'SOFTEX DAUN SIRIH 23 CM Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('337', '8', '27', 'BRG-000234', 'SOFTEX DAUN SIRIH 23 CM Karton', 'softex-daun-sirih-23-cm-karton', '967178994206', '240000', '1', 'SOFTEX DAUN SIRIH 36 CM', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('338', '8', '10', 'BRG-000235', 'SOFTEX DAUN SIRIH 36 CM', 'softex-daun-sirih-36-cm', '778167951007', '1000', '1', 'SOFTEX DAUN SIRIH 36 CM Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('339', '8', '17', 'BRG-000236', 'SOFTEX DAUN SIRIH 36 CM Renceng', 'softex-daun-sirih-36-cm-renceng', '615764604225', '9000', '1', 'SOFTEX DAUN SIRIH 36 CM Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('340', '8', '27', 'BRG-000237', 'SOFTEX DAUN SIRIH 36 CM Karton', 'softex-daun-sirih-36-cm-karton', '202342288862', '240000', '1', 'SOFTEX DAUN SIRIH WINGS 29 CM', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('341', '8', '10', 'BRG-000238', 'SOFTEX DAUN SIRIH WINGS 29 CM', 'softex-daun-sirih-wings-29-cm', '300871629250', '1000', '1', 'SOFTEX DAUN SIRIH WINGS 29 CM Renceng', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('342', '8', '17', 'BRG-000239', 'SOFTEX DAUN SIRIH WINGS 29 CM Renceng', 'softex-daun-sirih-wings-29-cm-renceng', '792122262468', '9000', '1', 'SOFTEX DAUN SIRIH WINGS 29 CM Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('343', '8', '27', 'BRG-000240', 'SOFTEX DAUN SIRIH WINGS 29 CM Karton', 'softex-daun-sirih-wings-29-cm-karton', '483564673712', '240000', '1', 'SOFTEX DAUN SIRIH NON WING 23CM 8Pads', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('344', '8', '10', 'BRG-000241', 'SOFTEX DAUN SIRIH NON WING 23CM 8Pads', 'softex-daun-sirih-non-wing-23cm-8pads', '316415920434', '2000', '1', '&lt;p&gt;SOFTEX DAUN SIRIH NON WING 23CM 8Pads Paket&lt;/p&gt;\r\n', NULL, NULL, 1, 'Owner Toko', 'owner', '2024-07-10 23:26:10', '2024-07-14 13:08:11');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('345', '8', '27', 'BRG-000243', 'SOFTEX DAUN SIRIH NON WING 23CM 8Pads Karton', 'softex-daun-sirih-non-wing-23cm-8pads-karton', '854212480225', '252000', '1', 'SOFTEX DAUN SIRIH REGULER WING 23 CM 8Pads', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('346', '8', '10', 'BRG-000244', 'SOFTEX DAUN SIRIH REGULER WING 23 CM 8Pads', 'softex-daun-sirih-reguler-wing-23-cm-8pads', '776677095262', '2000', '1', '&lt;p&gt;SOFTEX DAUN SIRIH REGULER WING 23 CM 8Pads Paket&lt;/p&gt;\r\n', NULL, NULL, 1, 'Owner Toko', 'owner', '2024-07-10 23:26:10', '2024-07-14 13:08:55');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('347', '8', '27', 'BRG-000246', 'SOFTEX DAUN SIRIH REGULER WING 23 CM 8Pads Karton', 'softex-daun-sirih-reguler-wing-23-cm-8pads-karton', '250132900113', '252000', '1', 'SOFTEX DAUN SIRIH REGULER WING 23 CM 8Pads Karton', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('348', '8', '28', 'BRG-000306', 'CHARM Orange extra maxi 23cm 8Play Paket', 'charm-orange-extra-maxi-23cm-8play-paket', '255796212572', '28200', '6', 'CHARM Orange extra maxi 23cm 8Play Paket', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:39', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('349', '8', '28', 'BRG-000309', 'CHARM Orange Extra Maxi 23 cm Wings 7Play Paket', 'charm-orange-extra-maxi-23-cm-wings-7play-paket', '577097483488', '34200', '1', 'CHARM Orange Extra Maxi 23 cm Wings 7Play Paket', NULL, NULL, 1, 'Owner Toko', NULL, '2024-07-10 23:26:39', NULL);
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('350', '8', '28', 'BRG-000375', 'SOFTEX DAUN SIRIH NON WING 23CM 8Pads Paket', 'softex-daun-sirih-non-wing-23cm-8pads-paket', '181729127743', '25200', '1', '&lt;p&gt;SOFTEX DAUN SIRIH NON WING 23CM 8Pads Karton&lt;/p&gt;\r\n', NULL, NULL, 1, 'Owner Toko', 'owner', '2024-07-10 23:26:39', '2024-07-14 13:07:38');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('351', '8', '28', 'BRG-000378', 'SOFTEX DAUN SIRIH REGULER WING 23 CM 8Pads Paket', 'softex-daun-sirih-reguler-wing-23-cm-8pads-paket', '458272136286', '25200', '1', '&lt;p&gt;SOFTEX DAUN SIRIH REGULER WING 23 CM 8Pads Karton&lt;/p&gt;\r\n', NULL, NULL, 1, 'Owner Toko', 'owner', '2024-07-10 23:26:39', '2024-07-14 13:09:29');


#
# TABLE STRUCTURE FOR: tbl_barang_cacat
#

DROP TABLE IF EXISTS `tbl_barang_cacat`;

CREATE TABLE `tbl_barang_cacat` (
  `id_barang_cacat` bigint(20) NOT NULL AUTO_INCREMENT,
  `barang_id` bigint(20) NOT NULL,
  `toko_id` bigint(20) NOT NULL,
  `kd_barang_cacat` varchar(255) NOT NULL,
  `stok_cacat` bigint(20) NOT NULL,
  `harga_jual_cacat` double DEFAULT NULL,
  `status` int(11) NOT NULL,
  `user_input` varchar(100) NOT NULL,
  `user_edit` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id_barang_cacat`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_barang_harga_history
#

DROP TABLE IF EXISTS `tbl_barang_harga_history`;

CREATE TABLE `tbl_barang_harga_history` (
  `id_barang_history` bigint(20) NOT NULL AUTO_INCREMENT,
  `barang_id` bigint(20) NOT NULL,
  `kategori_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_kategori',
  `satuan_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_satuan',
  `harga_pokok` decimal(65,0) NOT NULL,
  `berat_barang` double NOT NULL,
  `tanggal_perubahan` datetime NOT NULL,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_barang_history`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=368 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('1', '1', '2', '1', '1000', '1', '2024-07-07 15:21:01', 'robby@ardhacodes.com', NULL, '2024-07-07 15:21:01', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', '2', '2', '1', '10000', '1', '2024-07-07 18:25:41', 'owner', NULL, '2024-07-07 18:25:41', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('3', '3', '1', '3', '50000', '10', '2024-07-07 18:38:40', 'Owner Toko', NULL, '2024-07-07 18:38:40', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('4', '4', '1', '1', '10000', '5', '2024-07-07 18:38:40', 'Owner Toko', NULL, '2024-07-07 18:38:40', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('5', '5', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('6', '6', '6', '24', '13', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('7', '7', '6', '1', '41', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('8', '8', '6', '1', '35', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('9', '9', '6', '24', '7', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('10', '10', '6', '24', '14', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('11', '11', '6', '1', '47', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('12', '12', '6', '1', '41', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('13', '13', '6', '24', '8', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('14', '14', '6', '24', '8', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('15', '15', '6', '24', '8', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('16', '16', '6', '24', '8', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('17', '17', '6', '24', '8', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('18', '18', '6', '24', '8', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('19', '19', '6', '24', '18', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('20', '20', '6', '24', '18', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('21', '21', '6', '24', '18', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('22', '22', '6', '24', '18', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('23', '23', '6', '24', '18', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('24', '24', '6', '1', '56', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('25', '25', '6', '1', '56', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('26', '26', '6', '1', '56', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('27', '27', '6', '1', '56', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('28', '28', '6', '1', '56', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('29', '29', '6', '24', '5', '330', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('30', '30', '6', '24', '5', '330', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('31', '31', '6', '24', '14', '1000', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('32', '32', '6', '24', '14', '1000', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('33', '33', '6', '1', '65', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('34', '34', '6', '1', '65', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('35', '35', '6', '1', '59', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('36', '36', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('37', '37', '6', '24', '13', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('38', '38', '6', '1', '42', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('39', '39', '6', '1', '36', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('40', '40', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('41', '41', '6', '24', '12', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('42', '42', '6', '24', '5', '250', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('43', '43', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('44', '44', '6', '24', '11', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('45', '45', '6', '1', '36', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('46', '46', '6', '1', '30', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('47', '47', '6', '24', '16', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('48', '48', '6', '24', '16', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('49', '49', '6', '24', '16', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('50', '50', '6', '24', '16', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('51', '51', '6', '24', '16', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('52', '52', '6', '24', '16', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('53', '53', '6', '24', '37', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('54', '54', '6', '24', '37', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('55', '55', '6', '24', '37', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('56', '56', '6', '24', '37', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('57', '57', '6', '24', '37', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('58', '58', '6', '24', '37', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('59', '59', '6', '1', '129', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('60', '60', '6', '1', '129', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('61', '61', '6', '1', '129', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('62', '62', '6', '1', '129', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('63', '63', '6', '1', '129', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('64', '64', '6', '1', '123', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('65', '65', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('66', '66', '6', '24', '12', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('67', '67', '6', '1', '40', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('68', '68', '6', '1', '34', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('69', '69', '6', '24', '4', '330', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('70', '70', '6', '24', '11', '1000', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('71', '71', '6', '1', '51', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('72', '72', '6', '1', '45', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('73', '73', '6', '24', '3', '330', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('74', '74', '6', '25', '9', '1', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('75', '75', '6', '1', '40', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('76', '76', '6', '1', '34', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('77', '77', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('78', '78', '6', '24', '10', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('79', '79', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('80', '80', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('81', '81', '6', '24', '12', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('82', '82', '6', '24', '12', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('83', '83', '6', '1', '40', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('84', '84', '6', '1', '40', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('85', '85', '6', '1', '34', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('86', '86', '6', '24', '1', '100', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('87', '87', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('88', '88', '6', '24', '12', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('89', '89', '6', '24', '2', '60', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('90', '90', '6', '24', '2', '100', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('91', '91', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('92', '92', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('93', '93', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('94', '94', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('95', '95', '6', '24', '13', '1500', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('96', '96', '6', '1', '40', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('97', '97', '6', '1', '40', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('98', '98', '6', '1', '40', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('99', '99', '6', '1', '40', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('100', '100', '6', '1', '34', '5', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('101', '101', '6', '24', '5', '250', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('102', '102', '6', '24', '5', '600', '2024-07-07 19:43:17', 'Owner Toko', NULL, '2024-07-07 19:43:17', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('103', '103', '6', '24', '5', '600', '2024-07-07 20:24:57', 'SINYO', NULL, '2024-07-07 20:24:57', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('104', '104', '6', '24', '5500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('105', '105', '6', '24', '13000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('106', '106', '6', '1', '41500', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('107', '107', '6', '1', '35500', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('108', '108', '6', '24', '7500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('109', '109', '6', '24', '14000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('110', '110', '6', '1', '47500', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('111', '111', '6', '1', '41500', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('112', '112', '6', '24', '8500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('113', '113', '6', '24', '8500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('114', '114', '6', '24', '8500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('115', '115', '6', '24', '8500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('116', '116', '6', '24', '8500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('117', '117', '6', '24', '8500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('118', '118', '6', '24', '18000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('119', '119', '6', '24', '18000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('120', '120', '6', '24', '18000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('121', '121', '6', '24', '18000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('122', '122', '6', '24', '18000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('123', '123', '6', '24', '18000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('124', '124', '6', '1', '56200', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('125', '125', '6', '1', '56200', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('126', '126', '6', '1', '56200', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('127', '127', '6', '1', '56200', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('128', '128', '6', '1', '56200', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('129', '129', '6', '24', '5100', '330', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('130', '130', '6', '24', '5100', '330', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('131', '131', '6', '24', '14500', '1000', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('132', '132', '6', '24', '14500', '1000', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('133', '133', '6', '1', '65000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('134', '134', '6', '1', '65000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('135', '135', '6', '1', '59000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('136', '136', '6', '24', '5500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('137', '137', '6', '24', '13000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('138', '138', '6', '1', '42500', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('139', '139', '6', '1', '36500', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('140', '140', '6', '24', '5500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('141', '141', '6', '24', '12000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('142', '142', '6', '24', '5750', '250', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('143', '143', '6', '24', '5500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('144', '144', '6', '24', '11500', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('145', '145', '6', '1', '36000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('146', '146', '6', '1', '30000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('147', '147', '6', '24', '16000', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('148', '148', '6', '24', '16000', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('149', '149', '6', '24', '16000', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('150', '150', '6', '24', '16000', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('151', '151', '6', '24', '16000', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('152', '152', '6', '24', '16000', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('153', '153', '6', '24', '37000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('154', '154', '6', '24', '37000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('155', '155', '6', '24', '37000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('156', '156', '6', '24', '37000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('157', '157', '6', '24', '37000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('158', '158', '6', '24', '37000', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('159', '159', '6', '1', '129000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('160', '160', '6', '1', '129000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('161', '161', '6', '1', '129000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('162', '162', '6', '1', '129000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('163', '163', '6', '1', '129000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('164', '164', '6', '1', '123000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('165', '165', '6', '24', '5500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('166', '166', '6', '24', '12500', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('167', '167', '6', '1', '40000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('168', '168', '6', '1', '34000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('169', '169', '6', '24', '4700', '330', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('170', '170', '6', '24', '11300', '1000', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('171', '171', '6', '1', '51000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('172', '172', '6', '1', '45000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('173', '173', '6', '24', '3500', '330', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('174', '174', '6', '25', '9000', '1', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('175', '175', '6', '1', '40000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('176', '176', '6', '1', '34000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('177', '177', '6', '24', '5500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('178', '178', '6', '24', '10500', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('179', '179', '6', '24', '5500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('180', '180', '6', '24', '5500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('181', '181', '6', '24', '12500', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('182', '182', '6', '24', '12500', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('183', '183', '6', '1', '40000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('184', '184', '6', '1', '40000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('185', '185', '6', '1', '34000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('186', '186', '6', '24', '1800', '100', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('187', '187', '6', '24', '5500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('188', '188', '6', '24', '12500', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('189', '189', '6', '24', '2300', '60', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('190', '190', '6', '24', '2300', '60', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('191', '191', '6', '24', '2300', '60', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('192', '192', '6', '24', '2300', '60', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('193', '193', '6', '24', '2300', '100', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('194', '194', '6', '24', '2300', '100', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('195', '195', '6', '24', '2300', '100', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('196', '196', '6', '24', '2300', '100', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('197', '197', '6', '24', '5800', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('198', '198', '6', '24', '5800', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('199', '199', '6', '24', '5800', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('200', '200', '6', '24', '5800', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('201', '201', '6', '24', '13500', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('202', '202', '6', '24', '13500', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('203', '203', '6', '24', '13500', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('204', '204', '6', '24', '13500', '1500', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('205', '205', '6', '1', '40000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('206', '206', '6', '1', '40000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('207', '207', '6', '1', '40000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('208', '208', '6', '1', '40000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('209', '209', '6', '1', '34000', '5', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('210', '210', '6', '24', '5600', '250', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('211', '211', '6', '24', '5500', '600', '2024-07-08 19:15:03', 'Owner Toko', NULL, '2024-07-08 19:15:03', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('212', '212', '6', '24', '12750', '500', '2024-07-09 20:06:26', 'owner', NULL, '2024-07-09 20:06:27', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('213', '213', '6', '10', '12000', '5', '2024-07-09 20:13:16', 'owner', NULL, '2024-07-09 20:13:16', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('214', '212', '6', '24', '12750', '5', '2024-07-09 20:13:47', 'owner', NULL, '2024-07-09 20:13:47', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('215', '212', '6', '24', '12750', '500', '2024-07-09 20:14:14', 'owner', NULL, '2024-07-09 20:14:14', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('216', '213', '6', '24', '12000', '500', '2024-07-09 20:14:30', 'owner', NULL, '2024-07-09 20:14:30', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('217', '214', '6', '24', '12000', '500', '2024-07-09 20:15:24', 'owner', NULL, '2024-07-09 20:15:24', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('218', '215', '6', '24', '12000', '500', '2024-07-09 20:16:15', 'owner', NULL, '2024-07-09 20:16:15', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('219', '216', '6', '24', '12000', '500', '2024-07-09 20:16:58', 'owner', NULL, '2024-07-09 20:16:58', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('220', '217', '1', '3', '20000', '1', '2024-07-09 21:25:36', 'owner', NULL, '2024-07-09 21:25:36', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('221', '218', '1', '3', '25000', '1', '2024-07-09 21:26:38', 'owner', NULL, '2024-07-09 21:26:38', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('222', '219', '8', '26', '44000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('223', '220', '8', '26', '47000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('224', '221', '8', '26', '56000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('225', '222', '8', '26', '41000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('226', '223', '8', '26', '41000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('227', '224', '8', '26', '56000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('228', '225', '8', '10', '1744', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('229', '226', '8', '17', '10463', '6', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('230', '227', '8', '27', '167400', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('231', '228', '8', '10', '1740', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('232', '229', '8', '17', '10438', '6', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('233', '230', '8', '27', '167000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('234', '231', '8', '10', '2175', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('235', '232', '8', '17', '11125', '6', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('236', '233', '8', '27', '258000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('237', '234', '8', '26', '66000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('238', '235', '8', '26', '69500', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('239', '236', '8', '26', '69500', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('240', '237', '8', '26', '104918', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('241', '238', '8', '10', '9000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('242', '239', '8', '10', '9000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('243', '240', '8', '26', '75500', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('244', '241', '8', '26', '75500', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('245', '242', '8', '26', '77910', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('246', '243', '8', '26', '77910', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('247', '244', '8', '26', '106820', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('248', '245', '8', '26', '106820', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('249', '246', '8', '26', '44000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('250', '247', '8', '26', '44000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('251', '248', '8', '26', '73990', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('252', '249', '8', '26', '53410', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('253', '250', '8', '26', '77420', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('254', '251', '8', '26', '77420', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('255', '252', '8', '26', '58310', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('256', '253', '8', '10', '1650', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('257', '254', '8', '17', '16500', '10', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('258', '255', '8', '27', '198000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('259', '256', '8', '10', '1750', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('260', '257', '8', '17', '17500', '10', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('261', '258', '8', '27', '210000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('262', '259', '8', '10', '1750', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('263', '260', '8', '17', '17500', '10', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('264', '261', '8', '27', '210000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('265', '262', '8', '10', '2188', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('266', '263', '8', '17', '21880', '10', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('267', '264', '8', '27', '262500', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('268', '265', '8', '10', '2538', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('269', '266', '8', '17', '25380', '10', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('270', '267', '8', '27', '304500', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('271', '268', '8', '10', '2450', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('272', '269', '8', '17', '24500', '10', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('273', '270', '8', '27', '588000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('274', '271', '8', '10', '3000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('275', '272', '8', '17', '30000', '10', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('276', '273', '8', '27', '720000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('277', '274', '8', '10', '2450', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('278', '275', '8', '17', '24500', '10', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('279', '276', '8', '27', '588000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('280', '277', '8', '10', '4700', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('281', '278', '8', '27', '282000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('282', '279', '8', '10', '5700', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('283', '280', '8', '27', '342000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('284', '281', '8', '10', '1373', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('285', '282', '8', '17', '8238', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('286', '283', '8', '27', '163060', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('287', '284', '8', '10', '1536', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('288', '285', '8', '17', '9216', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('289', '286', '8', '27', '163384', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('290', '287', '8', '10', '1536', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('291', '288', '8', '17', '9215', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('292', '289', '8', '27', '163384', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('293', '290', '8', '10', '1928', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('294', '291', '8', '17', '11568', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('295', '292', '8', '27', '195219', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('296', '293', '8', '10', '13333', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('297', '294', '8', '17', '79998', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('298', '295', '8', '27', '161208', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('299', '296', '8', '10', '1444', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('300', '297', '8', '17', '8664', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('301', '298', '8', '27', '173261', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('302', '299', '8', '10', '1444', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('303', '300', '8', '17', '8664', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('304', '301', '8', '27', '173261', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('305', '302', '8', '10', '1444', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('306', '303', '8', '17', '8664', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('307', '304', '8', '27', '173261', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('308', '305', '8', '10', '1904', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('309', '306', '8', '17', '11424', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('310', '307', '8', '27', '173261', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('311', '308', '8', '26', '64190', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('312', '309', '8', '26', '66640', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('313', '310', '8', '26', '44000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('314', '311', '8', '26', '44000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('315', '312', '8', '26', '54618', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('316', '313', '8', '26', '57387', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('317', '314', '8', '10', '1777', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('318', '315', '8', '17', '10662', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('319', '316', '8', '27', '170554', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('320', '317', '8', '10', '1777', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('321', '318', '8', '17', '10662', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('322', '319', '8', '27', '170554', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('323', '320', '8', '10', '2022', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('324', '321', '8', '17', '12132', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('325', '322', '8', '27', '194141', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('326', '323', '8', '26', '27647', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('327', '324', '8', '26', '72841', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('328', '325', '8', '26', '80631', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('329', '326', '8', '26', '27647', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('330', '327', '8', '26', '46307', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('331', '328', '8', '26', '60361', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('332', '329', '8', '10', '4324', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('333', '330', '8', '17', '25944', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('334', '331', '8', '27', '207565', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('335', '332', '8', '10', '6054', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('336', '333', '8', '17', '36324', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('337', '334', '8', '27', '290594', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('338', '335', '8', '10', '1000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('339', '336', '8', '17', '9000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('340', '337', '8', '27', '240000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('341', '338', '8', '10', '1000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('342', '339', '8', '17', '9000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('343', '340', '8', '27', '240000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('344', '341', '8', '10', '1000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('345', '342', '8', '17', '9000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('346', '343', '8', '27', '240000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('347', '344', '8', '10', '4200', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('348', '345', '8', '27', '252000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('349', '346', '8', '10', '4200', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('350', '347', '8', '27', '252000', '1', '2024-07-10 23:26:10', 'Owner Toko', NULL, '2024-07-10 23:26:10', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('351', '348', '8', '28', '28200', '6', '2024-07-10 23:26:39', 'Owner Toko', NULL, '2024-07-10 23:26:39', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('352', '349', '8', '28', '34200', '1', '2024-07-10 23:26:39', 'Owner Toko', NULL, '2024-07-10 23:26:39', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('353', '350', '8', '28', '25200', '1', '2024-07-10 23:26:39', 'Owner Toko', NULL, '2024-07-10 23:26:39', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('354', '351', '8', '28', '25200', '1', '2024-07-10 23:26:39', 'Owner Toko', NULL, '2024-07-10 23:26:39', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('355', '351', '8', '28', '242000', '1', '2024-07-14 11:28:50', 'owner', NULL, '2024-07-14 11:28:50', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('356', '350', '8', '28', '242000', '1', '2024-07-14 11:29:08', 'owner', NULL, '2024-07-14 11:29:08', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('357', '224', '8', '26', '51000', '1', '2024-07-14 13:03:11', 'owner', NULL, '2024-07-14 13:03:11', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('358', '293', '8', '10', '2000', '1', '2024-07-14 13:04:11', 'owner', NULL, '2024-07-14 13:04:11', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('359', '294', '8', '17', '8000', '1', '2024-07-14 13:04:53', 'owner', NULL, '2024-07-14 13:04:53', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('360', '324', '8', '26', '48000', '1', '2024-07-14 13:05:25', 'owner', NULL, '2024-07-14 13:05:25', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('361', '323', '8', '26', '48000', '1', '2024-07-14 13:06:13', 'owner', NULL, '2024-07-14 13:06:13', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('362', '328', '8', '26', '50361', '1', '2024-07-14 13:06:46', 'owner', NULL, '2024-07-14 13:06:46', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('363', '350', '8', '28', '25200', '1', '2024-07-14 13:07:38', 'owner', NULL, '2024-07-14 13:07:38', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('364', '344', '8', '10', '2000', '1', '2024-07-14 13:08:11', 'owner', NULL, '2024-07-14 13:08:11', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('365', '346', '8', '10', '2000', '1', '2024-07-14 13:08:55', 'owner', NULL, '2024-07-14 13:08:55', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('366', '351', '8', '28', '25200', '1', '2024-07-14 13:09:29', 'owner', NULL, '2024-07-14 13:09:29', NULL);
INSERT INTO `tbl_barang_harga_history` (`id_barang_history`, `barang_id`, `kategori_id`, `satuan_id`, `harga_pokok`, `berat_barang`, `tanggal_perubahan`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('367', '325', '8', '26', '48000', '1', '2024-07-14 13:10:45', 'owner', NULL, '2024-07-14 13:10:45', NULL);


#
# TABLE STRUCTURE FOR: tbl_barang_keluar
#

DROP TABLE IF EXISTS `tbl_barang_keluar`;

CREATE TABLE `tbl_barang_keluar` (
  `id_barang_keluar` bigint(20) NOT NULL AUTO_INCREMENT,
  `toko_id` bigint(20) DEFAULT NULL COMMENT 'TERJUAL DISTRIBUSI',
  `order_detail_id` bigint(20) DEFAULT NULL,
  `harga_id` bigint(20) NOT NULL,
  `request_id` bigint(20) DEFAULT 0 COMMENT 'TERJUAL DISTRIBUSI',
  `jenis_keluar` varchar(100) NOT NULL COMMENT 'TERJUAL DISTRIBUSI',
  `jml_keluar` bigint(20) NOT NULL,
  `bukti_keluar` text NOT NULL,
  `tanggal_barang_keluar` datetime DEFAULT NULL COMMENT 'TERJUAL DISTRIBUSI',
  `is_rollback` int(11) DEFAULT 0,
  `user_input` varchar(100) NOT NULL,
  `user_edit` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_barang_keluar`),
  KEY `FK_barkel_toko` (`toko_id`),
  KEY `FK_barkel_orderdetail` (`order_detail_id`),
  KEY `FK_barkel_harga` (`harga_id`),
  CONSTRAINT `FK_barkel_harga` FOREIGN KEY (`harga_id`) REFERENCES `tbl_harga` (`id_harga`) ON UPDATE CASCADE,
  CONSTRAINT `FK_barkel_orderdetail` FOREIGN KEY (`order_detail_id`) REFERENCES `tbl_order_detail` (`id_order_detail`) ON UPDATE CASCADE,
  CONSTRAINT `FK_barkel_toko` FOREIGN KEY (`toko_id`) REFERENCES `tbl_toko` (`id_toko`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', NULL, '1', '118', '0', 'TERJUAL', '1', '', NULL, 0, 'FANDY', '', '2024-07-09 21:30:48', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', NULL, '2', '119', '0', 'TERJUAL', '1', '', NULL, 0, 'FANDY', '', '2024-07-09 21:41:03', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', NULL, '3', '118', '0', 'TERJUAL', '1', '', NULL, 0, 'FANDY', '', '2024-07-09 21:48:15', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('4', NULL, '4', '119', '0', 'TERJUAL', '1', '', NULL, 0, 'FANDY', '', '2024-07-09 21:48:15', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('5', NULL, '5', '118', '0', 'TERJUAL', '1', '', NULL, 0, 'FANDY', '', '2024-07-09 22:13:52', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('6', NULL, '6', '118', '0', 'TERJUAL', '1', '', NULL, 0, 'FANDY', '', '2024-07-10 09:36:26', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('7', NULL, '7', '119', '0', 'TERJUAL', '1', '', NULL, 0, 'FANDY', '', '2024-07-10 09:36:26', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('8', NULL, '8', '118', '0', 'TERJUAL', '1', '', NULL, 0, 'FANDY', '', '2024-07-10 09:43:57', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('9', NULL, '9', '118', '0', 'TERJUAL', '1', '', NULL, 0, 'FANDY', '', '2024-07-10 09:48:30', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('10', NULL, '10', '118', '0', 'TERJUAL', '1', '', NULL, 0, 'FANDY', '', '2024-07-10 09:51:10', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('11', NULL, '11', '119', '0', 'TERJUAL', '1', '', NULL, 0, 'FANDY', '', '2024-07-10 09:52:24', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('12', NULL, '12', '12', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-14 13:55:41', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('13', NULL, '13', '26', '0', 'TERJUAL', '1', '', NULL, 1, 'BELDA', '', '2024-07-14 15:31:52', '2024-07-22 16:57:18');
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('14', NULL, '14', '36', '0', 'TERJUAL', '1', '', NULL, 1, 'BELDA', '', '2024-07-14 15:34:25', '2024-07-17 00:16:00');
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('15', NULL, '15', '113', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-15 18:14:37', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('16', NULL, '16', '23', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-15 18:14:37', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('17', NULL, '17', '51', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-15 18:19:47', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('18', NULL, '18', '43', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-15 18:19:47', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('19', NULL, '19', '42', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-15 18:19:47', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('20', NULL, '20', '23', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-15 18:19:47', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('21', NULL, '21', '71', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-15 18:20:57', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('22', NULL, '22', '42', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-20 15:54:02', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('23', NULL, '23', '23', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-20 15:54:02', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('24', NULL, '24', '80', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-20 15:57:54', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('25', NULL, '25', '117', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-20 15:57:54', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('26', NULL, '26', '23', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-20 16:00:04', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('27', NULL, '27', '149', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-21 10:53:51', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('28', NULL, '28', '26', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-23 09:13:48', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('29', NULL, '29', '23', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-23 09:13:48', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('30', NULL, '30', '25', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-23 09:13:48', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('31', NULL, '31', '22', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-23 09:13:48', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('32', NULL, '32', '10', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-23 09:14:51', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('33', NULL, '33', '23', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-24 08:27:08', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('34', NULL, '34', '42', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-24 14:20:09', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('35', NULL, '35', '237', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-25 11:55:18', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('36', NULL, '36', '26', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-25 11:56:21', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('37', NULL, '37', '159', '0', 'TERJUAL', '1', '', NULL, 1, 'BELDA', '', '2024-07-27 15:23:37', '2024-07-27 16:06:15');
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('38', NULL, '38', '159', '0', 'TERJUAL', '1', '', NULL, 1, 'BELDA', '', '2024-07-27 15:40:21', '2024-07-27 16:05:55');
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('39', NULL, '39', '159', '0', 'TERJUAL', '1', '', NULL, 1, 'BELDA', '', '2024-07-27 15:41:33', '2024-07-27 16:05:43');
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `toko_id`, `order_detail_id`, `harga_id`, `request_id`, `jenis_keluar`, `jml_keluar`, `bukti_keluar`, `tanggal_barang_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('40', NULL, '40', '42', '0', 'TERJUAL', '1', '', NULL, 0, 'BELDA', '', '2024-07-28 11:43:27', NULL);


#
# TABLE STRUCTURE FOR: tbl_barang_masuk
#

DROP TABLE IF EXISTS `tbl_barang_masuk`;

CREATE TABLE `tbl_barang_masuk` (
  `id_barang_masuk` bigint(20) NOT NULL AUTO_INCREMENT,
  `harga_id` bigint(20) DEFAULT NULL,
  `jml_masuk` bigint(20) DEFAULT NULL,
  `bukti_beli` text DEFAULT NULL,
  `tipe` varchar(100) DEFAULT NULL COMMENT '''toko_luar'',''gudang'', ''antar_toko''',
  `tanggal_barang_masuk` datetime DEFAULT NULL,
  `nama_sales` varchar(255) DEFAULT NULL,
  `nomor_supplier` varchar(255) DEFAULT NULL,
  `nama_toko_beli` varchar(100) DEFAULT NULL COMMENT 'kusus untuk beli dari toko luar',
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_barang_masuk`),
  KEY `FK_bar_masuk_harga` (`harga_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang_masuk` (`id_barang_masuk`, `harga_id`, `jml_masuk`, `bukti_beli`, `tipe`, `tanggal_barang_masuk`, `nama_sales`, `nomor_supplier`, `nama_toko_beli`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '1', '1', '', 'antar_toko', '0000-00-00 00:00:00', NULL, NULL, NULL, 'owner', NULL, '2024-07-07 18:36:17', NULL);
INSERT INTO `tbl_barang_masuk` (`id_barang_masuk`, `harga_id`, `jml_masuk`, `bukti_beli`, `tipe`, `tanggal_barang_masuk`, `nama_sales`, `nomor_supplier`, `nama_toko_beli`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', '141', '4', '', 'toko_luar', '2024-07-27 00:00:00', NULL, NULL, 'Indomaret', 'owner', NULL, '2024-07-27 16:01:58', NULL);


#
# TABLE STRUCTURE FOR: tbl_barang_musnah
#

DROP TABLE IF EXISTS `tbl_barang_musnah`;

CREATE TABLE `tbl_barang_musnah` (
  `id_musnah` bigint(20) NOT NULL AUTO_INCREMENT,
  `barang_id` bigint(20) DEFAULT NULL,
  `toko_id` bigint(20) DEFAULT NULL,
  `qty_sampah` bigint(20) DEFAULT NULL,
  `tgl_musnah` datetime DEFAULT NULL,
  `bukti_musnah` blob DEFAULT NULL,
  `is_rollback` int(11) DEFAULT 0,
  `is_proses` varchar(100) DEFAULT NULL COMMENT 'barang_masuk, barang_toko, barang_cacat',
  `user_input` varchar(100) NOT NULL,
  `user_edit` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_musnah`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_barang_temp
#

DROP TABLE IF EXISTS `tbl_barang_temp`;

CREATE TABLE `tbl_barang_temp` (
  `id_barang_temp` bigint(20) NOT NULL AUTO_INCREMENT,
  `kategori_id` text NOT NULL COMMENT 'relasi ke tbl_kategori',
  `satuan_id` text NOT NULL COMMENT 'relasi ke tbl_satuan',
  `kode_barang` text NOT NULL,
  `nama_barang` text NOT NULL,
  `slug_barang` text NOT NULL,
  `barcode_barang` text NOT NULL,
  `harga_pokok` text NOT NULL,
  `berat_barang` text NOT NULL,
  `deskripsi` text NOT NULL,
  `gambar` text DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_barang_temp`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=134 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_card_temporary
#

DROP TABLE IF EXISTS `tbl_card_temporary`;

CREATE TABLE `tbl_card_temporary` (
  `id_card_temporary` bigint(20) NOT NULL AUTO_INCREMENT,
  `barang_cacat_id` bigint(20) DEFAULT NULL,
  `qty_card` bigint(20) DEFAULT NULL,
  `price_card` bigint(20) DEFAULT NULL,
  `name_card` text DEFAULT NULL,
  `option_card` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`option_card`)),
  PRIMARY KEY (`id_card_temporary`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_customer
#

DROP TABLE IF EXISTS `tbl_customer`;

CREATE TABLE `tbl_customer` (
  `id_customer` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `hp` varchar(50) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  PRIMARY KEY (`id_customer`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_diskon
#

DROP TABLE IF EXISTS `tbl_diskon`;

CREATE TABLE `tbl_diskon` (
  `id_diskon` bigint(20) NOT NULL AUTO_INCREMENT,
  `harga_id` bigint(20) DEFAULT NULL,
  `nama_diskon` varchar(100) DEFAULT NULL,
  `harga_potongan` double DEFAULT NULL,
  `tgl_mulai` date DEFAULT NULL,
  `tgl_akhir` date DEFAULT NULL,
  `minimal_beli` bigint(20) DEFAULT 1,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_active` int(11) DEFAULT 1,
  PRIMARY KEY (`id_diskon`),
  KEY `FK_diskon_harga` (`harga_id`),
  CONSTRAINT `FK_diskon_harga` FOREIGN KEY (`harga_id`) REFERENCES `tbl_harga` (`id_harga`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_harga
#

DROP TABLE IF EXISTS `tbl_harga`;

CREATE TABLE `tbl_harga` (
  `id_harga` bigint(20) NOT NULL AUTO_INCREMENT,
  `barang_id` bigint(20) DEFAULT NULL,
  `toko_id` bigint(20) DEFAULT NULL,
  `stok_toko` bigint(20) DEFAULT NULL,
  `harga_jual` double DEFAULT NULL,
  `is_active` int(11) DEFAULT NULL,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_harga`),
  KEY `index_harga` (`id_harga`,`barang_id`,`toko_id`),
  KEY `FK_harga_barang` (`barang_id`),
  KEY `FK_harga_toko` (`toko_id`)
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('5', '104', '11', '20', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('6', '105', '11', '12', '16000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('7', '106', '11', '6', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('8', '107', '11', '4', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('9', '108', '11', '22', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('10', '109', '11', '11', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('11', '110', '11', '10', '55000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('12', '111', '11', '0', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('13', '112', '11', '24', '10000', 1, 'owner', 'Owner Toko', '2024-07-08 19:50:44', '2024-07-09 19:27:39');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('14', '113', '11', '4', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('15', '114', '11', '4', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('16', '115', '11', '4', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('17', '116', '11', '4', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('18', '117', '11', '4', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('19', '118', '11', '3', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('20', '119', '11', '2', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('21', '120', '11', '2', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('22', '121', '11', '2', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('23', '122', '11', '5', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('24', '123', '11', '2', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('25', '124', '11', '4', '67000', 1, 'owner', 'Owner Toko', '2024-07-08 19:50:44', '2024-07-22 11:25:18');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('26', '125', '11', '2', '67000', 1, 'owner', 'Owner Toko', '2024-07-08 19:50:44', '2024-07-22 11:25:00');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('27', '126', '11', '4', '67000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('28', '127', '11', '2', '67000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('29', '128', '11', '4', '67000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('30', '129', '11', '6', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('31', '130', '11', '3', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('32', '131', '11', '6', '17000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('33', '132', '11', '5', '17000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('34', '133', '11', '4', '75000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('35', '134', '11', '6', '75000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('36', '135', '11', '1', '70000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('37', '136', '11', '22', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('38', '137', '11', '10', '17000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('39', '138', '11', '3', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('40', '139', '11', '4', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('41', '140', '11', '12', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('42', '141', '11', '8', '15000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('43', '142', '11', '39', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('44', '143', '11', '24', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('45', '144', '11', '12', '16000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('46', '145', '11', '10', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('47', '146', '11', '1', '40000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('48', '147', '11', '4', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('49', '148', '11', '4', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('50', '149', '11', '3', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('51', '150', '11', '3', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('52', '151', '11', '4', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('53', '152', '11', '3', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('54', '153', '11', '2', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('55', '154', '11', '2', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('56', '155', '11', '2', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('57', '156', '11', '2', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('58', '157', '11', '1', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('59', '158', '11', '2', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('60', '159', '11', '1', '147000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('61', '160', '11', '1', '147000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('62', '161', '11', '1', '147000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('63', '162', '11', '1', '147000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('64', '163', '11', '1', '147000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('65', '164', '11', '1', '142000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('66', '165', '11', '24', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('67', '166', '11', '10', '17000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('68', '167', '11', '10', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('69', '168', '11', '1', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('70', '169', '11', '55', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('71', '170', '11', '10', '15000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('72', '171', '11', '9', '58000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('73', '172', '11', '1', '52000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('74', '173', '11', '54', '6000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('75', '174', '11', '22', '12000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('76', '175', '11', '10', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('77', '176', '11', '1', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('78', '177', '11', '12', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('79', '178', '11', '12', '14000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('80', '179', '11', '8', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('81', '180', '11', '10', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('82', '181', '11', '5', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('83', '182', '11', '5', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('84', '183', '11', '5', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('85', '184', '11', '5', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('86', '185', '11', '1', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('87', '186', '11', '14', '3000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('88', '187', '11', '24', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('89', '188', '11', '13', '17000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('90', '189', '11', '8', '3000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('91', '190', '11', '7', '3000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('92', '191', '11', '7', '3000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('93', '192', '11', '7', '3000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('94', '193', '11', '4', '4000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('95', '194', '11', '5', '4000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('96', '195', '11', '5', '4000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('97', '196', '11', '5', '4000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('98', '197', '11', '6', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('99', '198', '11', '6', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('100', '199', '11', '6', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('101', '200', '11', '6', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('102', '201', '11', '3', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('103', '202', '11', '3', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('104', '203', '11', '3', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('105', '204', '11', '7', '18000', 1, 'owner', 'Owner Toko', '2024-07-08 19:50:44', '2024-07-22 11:25:57');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('106', '205', '11', '1', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('107', '206', '11', '3', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('108', '207', '11', '3', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('109', '208', '11', '2', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('110', '209', '11', '1', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('111', '210', '11', '37', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('112', '211', '11', '23', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('113', '212', '11', '4', '15000', 1, NULL, NULL, '2024-07-09 20:09:25', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('114', '213', '11', '5', '15000', 1, NULL, NULL, '2024-07-09 20:18:04', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('115', '214', '11', '5', '15000', 1, NULL, NULL, '2024-07-09 20:18:14', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('116', '215', '11', '5', '15000', 1, NULL, NULL, '2024-07-09 20:18:35', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('117', '216', '11', '4', '15000', 1, NULL, NULL, '2024-07-09 20:18:47', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('118', '217', '8', '3', '25000', 1, NULL, NULL, '2024-07-09 21:28:09', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('119', '218', '8', '6', '30000', 1, NULL, NULL, '2024-07-09 21:28:32', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('120', '219', '11', '3', '45000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('121', '220', '11', '3', '48000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('122', '221', '11', '3', '57000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('123', '222', '11', '3', '42000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('124', '223', '11', '3', '42000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('125', '225', '11', '96', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('126', '226', '11', '96', '12000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('127', '227', '11', '96', '172800', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('128', '228', '11', '96', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('129', '229', '11', '96', '12000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('130', '230', '11', '96', '172800', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('131', '231', '11', '120', '3000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('132', '232', '11', '120', '15000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('133', '233', '11', '120', '264000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('134', '234', '11', '2', '67000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('135', '235', '11', '2', '71000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('136', '236', '11', '4', '71000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('137', '237', '11', '8', '110000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('138', '238', '11', '5', '9500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('139', '239', '11', '13', '9500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('140', '240', '11', '1', '79000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('141', '241', '11', '5', '79000', 1, 'robby@ardhacodes.com', 'Owner Toko', '2024-07-14 12:19:58', '2024-07-27 16:01:58');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('142', '242', '11', '1', '79000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('143', '243', '11', '1', '79000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('144', '244', '11', '1', '108000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('145', '245', '11', '1', '108000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('146', '246', '11', '8', '45000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('147', '247', '11', '6', '46000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('148', '248', '11', '2', '75000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('149', '249', '11', '1', '54500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('150', '250', '11', '3', '78000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('151', '251', '11', '3', '78000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('152', '252', '11', '3', '59000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('153', '253', '11', '120', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('154', '254', '11', '120', '22000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('155', '255', '11', '120', '228000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('156', '256', '11', '120', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('157', '257', '11', '120', '23000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('158', '258', '11', '120', '240000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('159', '259', '11', '120', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('160', '260', '11', '120', '23000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('161', '261', '11', '120', '240000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('162', '262', '11', '120', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('163', '263', '11', '120', '24000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('164', '264', '11', '120', '270000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('165', '265', '11', '120', '3000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('166', '266', '11', '120', '27000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('167', '267', '11', '120', '318000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('168', '268', '11', '240', '3000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('169', '269', '11', '240', '27000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('170', '270', '11', '240', '648000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('171', '271', '11', '240', '3500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('172', '272', '11', '240', '32000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('173', '273', '11', '240', '744000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('174', '274', '11', '300', '3000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('175', '275', '11', '300', '27000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('176', '276', '11', '300', '648000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('177', '277', '11', '60', '5500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('178', '348', '11', '60', '30000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('179', '278', '11', '60', '294000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('180', '279', '11', '60', '6500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('181', '349', '11', '60', '36000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('182', '280', '11', '60', '354000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('183', '281', '11', '120', '2000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('184', '282', '11', '120', '11500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('185', '283', '11', '120', '168000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('186', '284', '11', '840', '2000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('187', '285', '11', '840', '11500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('188', '286', '11', '840', '170000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('189', '287', '11', '1560', '2000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('190', '288', '11', '1560', '11500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('191', '289', '11', '1560', '173000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('192', '290', '11', '720', '2000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('193', '292', '11', '720', '206500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('194', '295', '11', '180', '206500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('195', '296', '11', '2040', '11000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('196', '297', '11', '2040', '54000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('197', '298', '11', '2040', '178000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('198', '299', '11', '2880', '11000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('199', '300', '11', '2880', '54000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('200', '301', '11', '2880', '178000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('201', '302', '11', '1080', '11000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('202', '303', '11', '1080', '54000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('203', '304', '11', '1080', '178000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('204', '305', '11', '120', '13000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('205', '306', '11', '120', '72000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('206', '307', '11', '120', '178000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('207', '308', '11', '6', '66500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('208', '309', '11', '6', '68500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('209', '310', '11', '16', '47000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('210', '311', '11', '16', '45000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('211', '312', '11', '22', '55000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('212', '313', '11', '8', '58000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('213', '314', '11', '96', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('214', '315', '11', '96', '12000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('215', '316', '11', '96', '175000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('216', '317', '11', '96', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('217', '318', '11', '96', '12000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('218', '319', '11', '96', '175000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('219', '320', '11', '96', '3000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('220', '321', '11', '96', '15000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('221', '322', '11', '96', '196000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('222', '323', '11', '16', '39000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('223', '326', '11', '16', '39000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('224', '327', '11', '16', '50000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('225', '329', '11', '48', '7000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('226', '330', '11', '48', '33000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('227', '331', '11', '48', '216000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('228', '332', '11', '48', '8000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('229', '333', '11', '48', '42000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('230', '334', '11', '48', '315000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('231', '335', '11', '240', '2000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('232', '336', '11', '240', '13500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('233', '337', '11', '240', '260000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('234', '338', '11', '120', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('235', '339', '11', '120', '9500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('236', '340', '11', '120', '250000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('237', '341', '11', '119', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('238', '342', '11', '120', '9500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('239', '343', '11', '120', '250000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('240', '345', '11', '60', '252000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('241', '347', '11', '60', '252000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('242', '224', '11', '3', '52500', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('243', '291', '11', '720', '12000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('244', '293', '11', '180', '2500', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('245', '294', '11', '180', '13000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('246', '324', '11', '8', '51000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('247', '328', '11', '8', '56000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('248', '344', '11', '60', '2500', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('249', '350', '11', '60', '27000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('250', '346', '11', '60', '2500', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('251', '351', '11', '60', '27000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('252', '325', '11', '8', '50000', 1, 'owner', NULL, '2024-07-14 13:11:23', NULL);


#
# TABLE STRUCTURE FOR: tbl_harga_temp
#

DROP TABLE IF EXISTS `tbl_harga_temp`;

CREATE TABLE `tbl_harga_temp` (
  `id_harga` bigint(20) NOT NULL AUTO_INCREMENT,
  `barang_id` text DEFAULT NULL,
  `toko_id` text DEFAULT NULL,
  `stok_toko` text DEFAULT NULL,
  `harga_jual` text DEFAULT NULL,
  `is_active` int(11) DEFAULT NULL,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_harga`),
  KEY `index_name` (`id_harga`) USING BTREE,
  FULLTEXT KEY `index_name2` (`barang_id`,`toko_id`,`stok_toko`)
) ENGINE=MyISAM AUTO_INCREMENT=122 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_harga_toko_history
#

DROP TABLE IF EXISTS `tbl_harga_toko_history`;

CREATE TABLE `tbl_harga_toko_history` (
  `id_harga_toko_history` bigint(20) NOT NULL AUTO_INCREMENT,
  `harga_id` bigint(20) NOT NULL,
  `harga_jual` double DEFAULT NULL,
  `is_active` int(11) DEFAULT NULL,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_harga_toko_history`) USING BTREE,
  KEY `index_harga` (`harga_id`)
) ENGINE=MyISAM AUTO_INCREMENT=252 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '1', '2000', 1, 'owner', NULL, '2024-07-07 18:28:29', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', '3', '10000', 1, 'PUTRI_01', NULL, '2024-07-07 18:36:49', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', '4', '15000', 1, 'BELDA_01', NULL, '2024-07-07 20:18:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('4', '5', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('5', '6', '16000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('6', '7', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('7', '8', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('8', '9', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('9', '10', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('10', '11', '55000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('11', '12', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('12', '13', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('13', '14', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('14', '15', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('15', '16', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('16', '17', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('17', '18', '10000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('18', '19', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('19', '20', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('20', '21', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('21', '22', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('22', '23', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('23', '24', '22000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('24', '25', '67000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('25', '26', '67000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('26', '27', '67000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('27', '28', '67000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('28', '29', '67000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('29', '30', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('30', '31', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('31', '32', '17000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('32', '33', '17000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('33', '34', '75000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('34', '35', '75000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('35', '36', '70000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('36', '37', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('37', '38', '17000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('38', '39', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('39', '40', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('40', '41', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('41', '42', '15000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('42', '43', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('43', '44', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('44', '45', '16000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('45', '46', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('46', '47', '40000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('47', '48', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('48', '49', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('49', '50', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('50', '51', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('51', '52', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('52', '53', '20000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('53', '54', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('54', '55', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('55', '56', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('56', '57', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('57', '58', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('58', '59', '43000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('59', '60', '147000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('60', '61', '147000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('61', '62', '147000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('62', '63', '147000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('63', '64', '147000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('64', '65', '142000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('65', '66', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('66', '67', '17000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('67', '68', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('68', '69', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('69', '70', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('70', '71', '15000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('71', '72', '58000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('72', '73', '52000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('73', '74', '6000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('74', '75', '12000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('75', '76', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('76', '77', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('77', '78', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('78', '79', '14000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('79', '80', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('80', '81', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('81', '82', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('82', '83', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('83', '84', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('84', '85', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('85', '86', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('86', '87', '3000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('87', '88', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('88', '89', '17000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('89', '90', '3000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('90', '91', '3000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('91', '92', '3000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('92', '93', '3000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('93', '94', '4000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('94', '95', '4000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('95', '96', '4000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('96', '97', '4000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('97', '98', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('98', '99', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('99', '100', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('100', '101', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('101', '102', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('102', '103', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('103', '104', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('104', '105', '18000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('105', '106', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('106', '107', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('107', '108', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('108', '109', '50000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('109', '110', '45000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('110', '111', '7000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('111', '112', '8000', 1, 'owner', NULL, '2024-07-08 19:50:44', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('112', '113', '15000', 1, 'owner', NULL, '2024-07-09 20:09:25', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('113', '114', '15000', 1, 'owner', NULL, '2024-07-09 20:18:04', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('114', '115', '15000', 1, 'owner', NULL, '2024-07-09 20:18:14', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('115', '116', '15000', 1, 'owner', NULL, '2024-07-09 20:18:35', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('116', '117', '15000', 1, 'owner', NULL, '2024-07-09 20:18:47', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('117', '118', '25000', 1, 'owner', NULL, '2024-07-09 21:28:09', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('118', '119', '30000', 1, 'owner', NULL, '2024-07-09 21:28:32', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('119', '120', '45000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('120', '121', '48000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('121', '122', '57000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('122', '123', '42000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('123', '124', '42000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('124', '125', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('125', '126', '12000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('126', '127', '172800', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('127', '128', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('128', '129', '12000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('129', '130', '172800', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('130', '131', '3000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('131', '132', '15000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('132', '133', '264000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('133', '134', '67000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('134', '135', '71000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('135', '136', '71000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('136', '137', '110000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('137', '138', '9500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('138', '139', '9500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('139', '140', '79000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('140', '141', '79000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('141', '142', '79000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('142', '143', '79000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('143', '144', '108000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('144', '145', '108000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('145', '146', '45000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('146', '147', '46000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('147', '148', '75000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('148', '149', '54500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('149', '150', '78000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('150', '151', '78000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('151', '152', '59000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('152', '153', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('153', '154', '22000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('154', '155', '228000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('155', '156', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('156', '157', '23000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('157', '158', '240000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('158', '159', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('159', '160', '23000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('160', '161', '240000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('161', '162', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('162', '163', '24000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('163', '164', '270000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('164', '165', '3000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('165', '166', '27000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('166', '167', '318000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('167', '168', '3000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('168', '169', '27000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('169', '170', '648000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('170', '171', '3500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('171', '172', '32000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('172', '173', '744000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('173', '174', '3000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('174', '175', '27000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('175', '176', '648000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('176', '177', '5500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('177', '178', '30000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('178', '179', '294000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('179', '180', '6500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('180', '181', '36000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('181', '182', '354000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('182', '183', '2000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('183', '184', '11500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('184', '185', '168000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('185', '186', '2000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('186', '187', '11500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('187', '188', '170000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('188', '189', '2000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('189', '190', '11500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('190', '191', '173000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('191', '192', '2000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('192', '193', '206500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('193', '194', '206500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('194', '195', '11000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('195', '196', '54000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('196', '197', '178000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('197', '198', '11000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('198', '199', '54000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('199', '200', '178000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('200', '201', '11000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('201', '202', '54000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('202', '203', '178000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('203', '204', '13000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('204', '205', '72000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('205', '206', '178000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('206', '207', '66500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('207', '208', '68500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('208', '209', '47000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('209', '210', '45000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('210', '211', '55000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('211', '212', '58000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('212', '213', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('213', '214', '12000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('214', '215', '175000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('215', '216', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('216', '217', '12000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('217', '218', '175000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('218', '219', '3000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('219', '220', '15000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('220', '221', '196000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('221', '222', '39000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('222', '223', '39000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('223', '224', '50000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('224', '225', '7000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('225', '226', '33000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('226', '227', '216000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('227', '228', '8000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('228', '229', '42000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('229', '230', '315000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('230', '231', '2000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('231', '232', '13500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('232', '233', '260000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('233', '234', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('234', '235', '9500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('235', '236', '250000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('236', '237', '2500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('237', '238', '9500', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('238', '239', '250000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('239', '240', '252000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('240', '241', '252000', 1, 'robby@ardhacodes.com', NULL, '2024-07-14 12:19:58', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('241', '242', '52500', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('242', '243', '12000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('243', '244', '2500', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('244', '245', '13000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('245', '246', '51000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('246', '247', '56000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('247', '248', '2500', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('248', '249', '27000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('249', '250', '2500', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('250', '251', '27000', 1, 'owner', NULL, '2024-07-14 13:09:54', NULL);
INSERT INTO `tbl_harga_toko_history` (`id_harga_toko_history`, `harga_id`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('251', '252', '50000', 1, 'owner', NULL, '2024-07-14 13:11:23', NULL);


#
# TABLE STRUCTURE FOR: tbl_karyawan_toko
#

DROP TABLE IF EXISTS `tbl_karyawan_toko`;

CREATE TABLE `tbl_karyawan_toko` (
  `id_karyawan` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_user',
  `toko_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_toko',
  `nama_karyawan` varchar(100) DEFAULT NULL,
  `hp_karyawan` varchar(100) DEFAULT NULL,
  `alamat_karyawan` text DEFAULT NULL,
  `bagian` varchar(100) DEFAULT NULL,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_karyawan`),
  KEY `FK_karyawan_user` (`user_id`),
  KEY `FK_karyawan_toko` (`toko_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('4', '23', '8', 'PUTRI', '087803214452', 'Sambikerep', 'tetap', 'sistem', 'sistem', '2024-07-14 15:57:42', '2024-07-14 15:57:42');
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', '20', '8', 'FANDY', '085850250677', 'JOMBANG', 'tetap', 'sistem', 'sistem', '2024-07-06 20:42:28', '2024-07-06 20:42:28');
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('3', '21', '11', 'BELDA', '085704752548', 'LAKARSANTRI', 'tetap', 'sistem', 'sistem', '2024-07-06 20:44:15', '2024-07-06 20:44:15');
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('5', '24', '11', 'PUTRI', '087803214452', 'Sambikerep', 'tetap', 'sistem', 'sistem', '2024-07-14 15:58:30', '2024-07-14 15:58:30');


#
# TABLE STRUCTURE FOR: tbl_karyawan_toko_temp
#

DROP TABLE IF EXISTS `tbl_karyawan_toko_temp`;

CREATE TABLE `tbl_karyawan_toko_temp` (
  `id_karyawan_toko_temp` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` text DEFAULT NULL,
  `toko_id` text DEFAULT NULL,
  `username` text DEFAULT NULL,
  `nama_karyawan` text DEFAULT NULL,
  `hp_karyawan` text DEFAULT NULL,
  `alamat_karyawan` text DEFAULT NULL,
  `bagian` text DEFAULT NULL,
  `is_sess_toko` int(11) DEFAULT NULL,
  `user_input` text NOT NULL,
  `user_update` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_karyawan_toko_temp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_kategori
#

DROP TABLE IF EXISTS `tbl_kategori`;

CREATE TABLE `tbl_kategori` (
  `id_kategori` bigint(20) NOT NULL AUTO_INCREMENT,
  `kode_kategori` varchar(255) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL,
  `slug_kategori` text NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_kategori`),
  KEY `index_kategori` (`id_kategori`,`kode_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('1', 'LISTRIK', 'Alat Listrik', 'alat-listrik', 1, 'sistem', 'sistem', '2023-12-22 01:30:01', '2024-01-03 14:01:14');
INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', 'BANGUNAN', 'Bangunan', 'bangunan', 1, 'sistem', 'sistem', '2023-12-22 01:30:29', '2024-01-03 14:01:41');
INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('3', 'PERKAKAS_DAPUR', 'Gerabah', 'gerabah', 1, 'sistem', 'sistem', '2024-01-01 13:14:23', '2024-01-03 14:01:52');
INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('4', 'ALAT TULIS', 'Alat Tulis', 'alat-tulis', 1, 'sistem', 'sistem', '2024-01-03 14:02:05', '2024-01-03 14:02:05');
INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('5', 'PERIKANAN', 'Perikanan', 'perikanan', 0, 'sistem', 'sistem', '2024-01-04 00:46:10', '2024-01-17 21:19:49');
INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('6', 'SABUN', 'sabun cuci', 'sabun-cuci', 1, 'sistem', 'sistem', '2024-01-17 21:22:09', '2024-01-17 21:22:44');
INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('7', '4545', '4545', '4545', 0, 'sistem', 'sistem', '2024-07-02 21:59:11', '2024-07-02 21:59:27');
INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('8', 'PAMPERS', 'Pampers', 'pampers', 1, 'sistem', 'sistem', '2024-07-06 20:13:39', '2024-07-10 23:25:49');


#
# TABLE STRUCTURE FOR: tbl_keluar_cacat
#

DROP TABLE IF EXISTS `tbl_keluar_cacat`;

CREATE TABLE `tbl_keluar_cacat` (
  `id_keluar_cacat` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_detail_cacat_id` bigint(20) DEFAULT NULL,
  `barang_cacat_id` bigint(20) NOT NULL,
  `jenis_keluar_cacat` varchar(100) NOT NULL COMMENT 'TERJUAL DIPAKAI',
  `jml_keluar_cacat` bigint(20) NOT NULL,
  `bukti_keluar_cacat` text NOT NULL,
  `tanggal_keluar_cacat` datetime DEFAULT NULL COMMENT 'TERJUAL DIPAKAI',
  `is_rollback` int(11) DEFAULT 0,
  `user_input` varchar(100) NOT NULL,
  `user_edit` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_keluar_cacat`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_masuk_cacat
#

DROP TABLE IF EXISTS `tbl_masuk_cacat`;

CREATE TABLE `tbl_masuk_cacat` (
  `id_masuk_cacat` bigint(20) NOT NULL AUTO_INCREMENT,
  `toko_id` bigint(20) DEFAULT NULL,
  `barang_id` bigint(20) DEFAULT NULL,
  `jumlah_masuk` bigint(20) DEFAULT NULL,
  `bukti_masuk` text DEFAULT NULL,
  `is_rollback` tinyint(4) DEFAULT NULL,
  `tgl_masuk` datetime DEFAULT NULL,
  `status_masuk` varchar(100) DEFAULT NULL,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id_masuk_cacat`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_menu
#

DROP TABLE IF EXISTS `tbl_menu`;

CREATE TABLE `tbl_menu` (
  `id_menu` bigint(20) NOT NULL AUTO_INCREMENT,
  `menu` varchar(100) NOT NULL,
  `icon` varchar(155) NOT NULL,
  `is_active` int(2) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('1', 'Dashboard', 'menu-icon tf-icons bx bx-home-circle', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('2', 'Management Akses', 'menu-icon tf-icons bx bx-lock-open', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('3', 'Toko', 'menu-icon tf-icons bx bxs-store', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('4', 'Barang', 'menu-icon tf-icons bx bxs-buildings', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('5', 'Kasir', 'menu-icon tf-icons bx bxs-wallet', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('6', 'Laporan', 'menu-icon tf-icons bx bxs-report', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('7', 'Setting', 'menu-icon tf-icons bx bxs-cog', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('8', 'Marketplace', 'menu-icon tf-icons bx bx-store', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('9', 'Barang Cacat', 'menu-icon tf-icons bx bxs-package', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('10', 'Utility', 'menu-icon tf-icons bx bxs-plane-take-off', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('11', 'Coba1', 'bx bxl-flask', 0);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES ('12', 'Gudang', 'menu-icon tf-icons bx bxs-buildings', 1);


#
# TABLE STRUCTURE FOR: tbl_menu_access
#

DROP TABLE IF EXISTS `tbl_menu_access`;

CREATE TABLE `tbl_menu_access` (
  `id_menu_access` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL,
  `menu_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id_menu_access`)
) ENGINE=MyISAM AUTO_INCREMENT=469 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('458', '1', '12');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('457', '1', '10');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('456', '1', '9');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('455', '1', '8');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('454', '1', '7');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('453', '1', '6');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('452', '1', '5');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('451', '1', '4');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('468', '2', '12');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('467', '2', '10');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('466', '2', '8');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('465', '2', '7');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('464', '2', '6');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('463', '2', '5');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('462', '2', '4');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('461', '2', '3');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('249', '8', '1');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('427', '3', '12');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('450', '1', '3');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('60', '5', '7');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('59', '5', '6');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('58', '5', '5');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('57', '5', '3');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('56', '5', '2');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('55', '5', '1');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('50', '17', '6');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('49', '17', '1');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('51', '17', '7');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('447', '18', '12');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('446', '18', '10');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('449', '1', '2');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('426', '3', '10');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('425', '3', '8');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('448', '1', '1');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('460', '2', '2');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('424', '3', '6');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('423', '3', '5');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('422', '3', '1');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('459', '2', '1');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('445', '18', '6');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('250', '8', '4');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('251', '8', '6');
INSERT INTO `tbl_menu_access` (`id_menu_access`, `role_id`, `menu_id`) VALUES ('444', '18', '1');


#
# TABLE STRUCTURE FOR: tbl_order
#

DROP TABLE IF EXISTS `tbl_order`;

CREATE TABLE `tbl_order` (
  `id_order` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Opsional berlaku pada marketplace',
  `toko_id` bigint(20) NOT NULL,
  `kode_order` longtext NOT NULL,
  `nama_cust` varchar(100) DEFAULT NULL,
  `hp_cust` varchar(100) DEFAULT NULL,
  `alamat_cust` text DEFAULT NULL,
  `tipe_order` enum('Marketplace','Kasir') NOT NULL,
  `tipe_pengiriman` text NOT NULL,
  `biaya_kirim` decimal(10,0) NOT NULL,
  `bukti_kirim` text DEFAULT NULL,
  `waktu_kirim` datetime DEFAULT NULL,
  `waktu_terima` datetime DEFAULT NULL,
  `alasan_batal` text DEFAULT NULL,
  `total_order` decimal(16,0) NOT NULL,
  `paidst` int(11) NOT NULL DEFAULT 0,
  `status` int(11) DEFAULT 1 COMMENT '1 = belum konfirmasi, 2 = sudah konfirmasi, 3 = dikemas, 4 = dikirim, 5 = selesai, 99 = dibatalkan',
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_edit` varchar(100) DEFAULT NULL,
  `user_input` varchar(100) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_order`),
  KEY `index_order` (`id_order`,`user_id`,`toko_id`),
  KEY `FK_order_user` (`user_id`),
  KEY `FK_order_toko` (`toko_id`),
  FULLTEXT KEY `kode_order_index` (`kode_order`),
  CONSTRAINT `FK_order_toko` FOREIGN KEY (`toko_id`) REFERENCES `tbl_toko` (`id_toko`) ON UPDATE CASCADE,
  CONSTRAINT `FK_order_user` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id_user`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('1', NULL, '8', '2ac214c6c9d74d31949b28481be2abf9', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '25000', 1, 5, 1, NULL, 'FANDY', NULL, '2024-07-09 21:30:48');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('2', NULL, '8', '5cef2827e20d4884a891d6031ede9c8a', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '30000', 1, 5, 1, NULL, 'FANDY', NULL, '2024-07-09 21:41:03');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('3', NULL, '8', '453e03fada53474086f3942ca78a0427', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '55000', 1, 5, 1, NULL, 'FANDY', NULL, '2024-07-09 21:48:15');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('4', NULL, '8', '631cdb0dc2874bd68444d060a7267257', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '25000', 1, 5, 1, NULL, 'FANDY', NULL, '2024-07-09 22:13:52');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('5', NULL, '8', '6e0ed3b853724068a876b09d05c5f3a3', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '55000', 1, 5, 1, NULL, 'FANDY', NULL, '2024-07-10 09:36:26');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('6', NULL, '8', 'b0e171dd5e4c469494c1cb334bedfcff', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '25000', 1, 5, 1, NULL, 'FANDY', NULL, '2024-07-10 09:43:57');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('7', NULL, '8', 'f94470e8d4854e348b91a235b42f1709', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '25000', 1, 5, 1, NULL, 'FANDY', NULL, '2024-07-10 09:48:30');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('8', NULL, '8', 'f44e42f694ac4e0fb692842e26a4c9ae', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '25000', 1, 5, 1, NULL, 'FANDY', NULL, '2024-07-10 09:51:10');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('9', NULL, '8', 'ad29f233102c482f9f6720a488ff6b0a', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '30000', 1, 5, 1, NULL, 'FANDY', NULL, '2024-07-10 09:52:24');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('11', NULL, '11', '7dffe2642cf34007a941401fcf2b870f', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '67000', 1, 99, 1, NULL, 'BELDA', '2024-07-22 16:57:18', '2024-07-14 15:31:52');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('12', NULL, '11', 'f4e8a88f32d54b30b05e64bb60502bc7', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '70000', 1, 99, 1, NULL, 'BELDA', '2024-07-17 00:16:00', '2024-07-14 15:34:25');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('13', NULL, '11', '019f853c3ccc40d48be29816be88228a', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '37000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-15 18:14:37');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('14', NULL, '11', '161985e61c7c402db1e9a66cfc51693f', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '64000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-15 18:19:47');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('15', NULL, '11', 'ffadea6f624146b39f42d1d616de694c', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '15000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-15 18:20:57');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('16', NULL, '11', '2b66c2b81f9c432ea76c7137af8ab4e6', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '37000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-20 15:54:02');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('17', NULL, '11', '176a5635aa274a33a36911ad603903bf', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '23000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-20 15:57:54');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('18', NULL, '11', '1250a0bee7a54fbe8980c55cc1e729a7', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '22000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-20 16:00:04');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('19', NULL, '11', 'a4a5016eac0743de9fa3c3bb237c74ee', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '54500', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-21 10:53:51');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('20', NULL, '11', '3853287701fc47beacc7d3d9fb2adb00', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '178000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-23 09:13:48');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('21', NULL, '11', 'c25d61cd52a64ef98c8ba63179b97cf2', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '18000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-23 09:14:51');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('22', NULL, '11', 'ffc2a2be848a400a853d713ab0104cb8', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '22000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-24 08:27:08');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('23', NULL, '11', '71fc8e910bed4cb2b897678763541a5d', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '15000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-24 14:20:09');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('24', NULL, '11', 'a02c59c325404d99b54337b576b0265a', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '2500', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-25 11:55:18');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('25', NULL, '11', 'dde162df7a3f4f079bdba12e9924e25c', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '67000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-25 11:56:21');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('26', NULL, '11', '7dd1714c1c474920abb825ed33b30d7e', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '2500', 1, 99, 1, NULL, 'BELDA', '2024-07-27 16:06:15', '2024-07-27 15:23:37');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('27', NULL, '11', '5d7c4b2d7ab14029b65b5b2ff863ec95', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '2500', 1, 99, 1, NULL, 'BELDA', '2024-07-27 16:05:55', '2024-07-27 15:40:21');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('30', NULL, '11', 'b1e397a298534ebfb2870aa5a0ea1705', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '2500', 1, 99, 1, NULL, 'BELDA', '2024-07-27 16:05:43', '2024-07-27 15:41:33');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `waktu_kirim`, `waktu_terima`, `alasan_batal`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('31', NULL, '11', 'e1534eef74b44bc7826a4c3a7317ea3e', '', '0', '', 'Kasir', '', '0', NULL, NULL, NULL, NULL, '15000', 1, 5, 1, NULL, 'BELDA', NULL, '2024-07-28 11:43:27');


#
# TABLE STRUCTURE FOR: tbl_order_cacat
#

DROP TABLE IF EXISTS `tbl_order_cacat`;

CREATE TABLE `tbl_order_cacat` (
  `id_order_cacat` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Opsional berlaku pada marketplace',
  `toko_id` bigint(20) NOT NULL,
  `kode_order` longtext NOT NULL,
  `nama_cust` varchar(100) DEFAULT NULL,
  `hp_cust` varchar(100) DEFAULT NULL,
  `alamat_cust` text DEFAULT NULL,
  `tipe_order` enum('Marketplace','Kasir') NOT NULL,
  `tipe_pengiriman` text NOT NULL,
  `biaya_kirim` decimal(10,0) NOT NULL,
  `bukti_kirim` text DEFAULT NULL,
  `waktu_kirim` datetime DEFAULT NULL,
  `waktu_terima` datetime DEFAULT NULL,
  `alasan_batal` text DEFAULT NULL,
  `total_order` decimal(16,0) NOT NULL,
  `paidst` int(11) NOT NULL DEFAULT 0,
  `status` int(11) DEFAULT 1 COMMENT '1 = belum konfirmasi, 2 = sudah konfirmasi, 3 = dikemas, 4 = dikirim, 5 = selesai, 99 = dibatalkan',
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_edit` varchar(100) DEFAULT NULL,
  `user_input` varchar(100) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_order_cacat`) USING BTREE,
  KEY `index_order` (`id_order_cacat`,`user_id`,`toko_id`),
  KEY `FK_order_user` (`user_id`),
  KEY `FK_order_toko` (`toko_id`),
  FULLTEXT KEY `kode_order_index` (`kode_order`),
  CONSTRAINT `tbl_order_cacat_ibfk_1` FOREIGN KEY (`toko_id`) REFERENCES `tbl_toko` (`id_toko`) ON UPDATE CASCADE,
  CONSTRAINT `tbl_order_cacat_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id_user`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_order_detail
#

DROP TABLE IF EXISTS `tbl_order_detail`;

CREATE TABLE `tbl_order_detail` (
  `id_order_detail` bigint(20) NOT NULL AUTO_INCREMENT,
  `harga_id` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `qty` bigint(20) DEFAULT NULL,
  `harga_total` double DEFAULT NULL,
  `harga_potongan` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`harga_potongan`)),
  `user_edit` varchar(100) DEFAULT NULL,
  `user_input` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_order_detail`),
  KEY `index_order_detail` (`id_order_detail`,`harga_id`,`order_id`),
  KEY `FK_ord_det_harga` (`harga_id`),
  KEY `FK_ord_det_order` (`order_id`),
  CONSTRAINT `FK_ord_det_harga` FOREIGN KEY (`harga_id`) REFERENCES `tbl_harga` (`id_harga`) ON UPDATE CASCADE,
  CONSTRAINT `FK_ord_det_order` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`id_order`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('1', '118', '1', '1', '25000', '[]', NULL, 'FANDY', '2024-07-09 21:30:48', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('2', '119', '2', '1', '30000', '[]', NULL, 'FANDY', '2024-07-09 21:41:03', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('3', '118', '3', '1', '25000', '[]', NULL, 'FANDY', '2024-07-09 21:48:15', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('4', '119', '3', '1', '30000', '[]', NULL, 'FANDY', '2024-07-09 21:48:15', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('5', '118', '4', '1', '25000', '[]', NULL, 'FANDY', '2024-07-09 22:13:52', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('6', '118', '5', '1', '25000', '[]', NULL, 'FANDY', '2024-07-10 09:36:26', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('7', '119', '5', '1', '30000', '[]', NULL, 'FANDY', '2024-07-10 09:36:26', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('8', '118', '6', '1', '25000', '[]', NULL, 'FANDY', '2024-07-10 09:43:57', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('9', '118', '7', '1', '25000', '[]', NULL, 'FANDY', '2024-07-10 09:48:30', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('10', '118', '8', '1', '25000', '[]', NULL, 'FANDY', '2024-07-10 09:51:10', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('11', '119', '9', '1', '30000', '[]', NULL, 'FANDY', '2024-07-10 09:52:24', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('12', '12', '10', '1', '50000', '[]', NULL, 'BELDA', '2024-07-14 13:55:41', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('13', '26', '11', '1', '67000', '[]', NULL, 'BELDA', '2024-07-14 15:31:52', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('14', '36', '12', '1', '70000', '[]', NULL, 'BELDA', '2024-07-14 15:34:25', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('15', '113', '13', '1', '15000', '[]', NULL, 'BELDA', '2024-07-15 18:14:37', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('16', '23', '13', '1', '22000', '[]', NULL, 'BELDA', '2024-07-15 18:14:37', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('17', '51', '14', '1', '20000', '[]', NULL, 'BELDA', '2024-07-15 18:19:47', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('18', '43', '14', '1', '7000', '[]', NULL, 'BELDA', '2024-07-15 18:19:47', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('19', '42', '14', '1', '15000', '[]', NULL, 'BELDA', '2024-07-15 18:19:47', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('20', '23', '14', '1', '22000', '[]', NULL, 'BELDA', '2024-07-15 18:19:47', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('21', '71', '15', '1', '15000', '[]', NULL, 'BELDA', '2024-07-15 18:20:57', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('22', '42', '16', '1', '15000', '[]', NULL, 'BELDA', '2024-07-20 15:54:02', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('23', '23', '16', '1', '22000', '[]', NULL, 'BELDA', '2024-07-20 15:54:02', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('24', '80', '17', '1', '8000', '[]', NULL, 'BELDA', '2024-07-20 15:57:54', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('25', '117', '17', '1', '15000', '[]', NULL, 'BELDA', '2024-07-20 15:57:54', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('26', '23', '18', '1', '22000', '[]', NULL, 'BELDA', '2024-07-20 16:00:04', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('27', '149', '19', '1', '54500', '[]', NULL, 'BELDA', '2024-07-21 10:53:51', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('28', '26', '20', '1', '67000', '[]', NULL, 'BELDA', '2024-07-23 09:13:48', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('29', '23', '20', '1', '22000', '[]', NULL, 'BELDA', '2024-07-23 09:13:48', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('30', '25', '20', '1', '67000', '[]', NULL, 'BELDA', '2024-07-23 09:13:48', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('31', '22', '20', '1', '22000', '[]', NULL, 'BELDA', '2024-07-23 09:13:48', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('32', '10', '21', '1', '18000', '[]', NULL, 'BELDA', '2024-07-23 09:14:51', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('33', '23', '22', '1', '22000', '[]', NULL, 'BELDA', '2024-07-24 08:27:08', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('34', '42', '23', '1', '15000', '[]', NULL, 'BELDA', '2024-07-24 14:20:09', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('35', '237', '24', '1', '2500', '[]', NULL, 'BELDA', '2024-07-25 11:55:18', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('36', '26', '25', '1', '67000', '[]', NULL, 'BELDA', '2024-07-25 11:56:21', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('37', '159', '26', '1', '2500', '[]', NULL, 'BELDA', '2024-07-27 15:23:37', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('38', '159', '27', '1', '2500', '[]', NULL, 'BELDA', '2024-07-27 15:40:21', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('39', '159', '30', '1', '2500', '[]', NULL, 'BELDA', '2024-07-27 15:41:33', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('40', '42', '31', '1', '15000', '[]', NULL, 'BELDA', '2024-07-28 11:43:27', NULL);


#
# TABLE STRUCTURE FOR: tbl_order_detail_cacat
#

DROP TABLE IF EXISTS `tbl_order_detail_cacat`;

CREATE TABLE `tbl_order_detail_cacat` (
  `id_order_detail_cacat` bigint(20) NOT NULL AUTO_INCREMENT,
  `barang_cacat_id` bigint(20) DEFAULT NULL,
  `order_cacat_id` bigint(20) DEFAULT NULL,
  `qty_cacat` bigint(20) DEFAULT NULL,
  `harga_detail_cacat` double DEFAULT NULL,
  `sub_total_cacat` double DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `user_input` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_order_detail_cacat`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_order_marketplace
#

DROP TABLE IF EXISTS `tbl_order_marketplace`;

CREATE TABLE `tbl_order_marketplace` (
  `id_order_marketplace` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id_order_marketplace`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_payment
#

DROP TABLE IF EXISTS `tbl_payment`;

CREATE TABLE `tbl_payment` (
  `id_payment` bigint(20) NOT NULL AUTO_INCREMENT,
  `bank_id` bigint(20) DEFAULT NULL,
  `rekening` varchar(255) DEFAULT NULL,
  `an_rekening` varchar(255) DEFAULT NULL,
  `no_kartu` varchar(255) DEFAULT NULL,
  `expired_date` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  PRIMARY KEY (`id_payment`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_privilege_menu
#

DROP TABLE IF EXISTS `tbl_privilege_menu`;

CREATE TABLE `tbl_privilege_menu` (
  `id_privilege` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`id_privilege`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (1, 1, 1);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (2, 1, 2);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (3, 1, 3);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (4, 1, 4);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (5, 1, 5);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (6, 1, 6);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (7, 1, 7);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (8, 1, 8);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (9, 2, 1);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (10, 2, 3);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (11, 2, 4);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (12, 2, 5);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (13, 2, 6);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (14, 2, 7);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (15, 2, 8);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (16, 3, 1);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (17, 3, 4);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (18, 3, 5);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (19, 3, 7);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (20, 3, 8);


#
# TABLE STRUCTURE FOR: tbl_privilege_submenu
#

DROP TABLE IF EXISTS `tbl_privilege_submenu`;

CREATE TABLE `tbl_privilege_submenu` (
  `id_privilege_submenu` int(11) NOT NULL AUTO_INCREMENT,
  `privilege_id` int(11) NOT NULL,
  `submenu_id` int(11) NOT NULL,
  PRIMARY KEY (`id_privilege_submenu`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (1, 1, 1);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (2, 2, 2);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (3, 2, 3);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (4, 2, 4);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (5, 2, 9);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (6, 3, 5);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (7, 3, 6);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (8, 3, 16);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (9, 4, 10);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (10, 4, 11);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (11, 4, 12);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (12, 4, 14);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (13, 4, 15);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (14, 4, 18);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (15, 4, 27);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (16, 5, 13);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (17, 5, 17);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (18, 5, 19);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (19, 5, 20);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (20, 6, 21);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (21, 6, 23);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (22, 6, 25);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (23, 6, 26);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (24, 7, 7);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (25, 7, 8);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (26, 9, 1);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (27, 10, 5);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (28, 10, 6);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (29, 10, 16);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (30, 11, 10);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (31, 11, 11);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (32, 11, 12);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (33, 11, 14);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (34, 11, 15);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (35, 11, 18);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (36, 11, 27);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (37, 12, 13);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (38, 12, 17);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (39, 12, 19);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (40, 12, 20);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (41, 13, 21);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (42, 13, 23);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (43, 13, 25);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (44, 13, 26);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (45, 14, 7);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (46, 14, 8);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (47, 16, 1);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (48, 17, 15);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (49, 18, 17);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (50, 18, 19);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (51, 18, 20);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (52, 19, 8);


#
# TABLE STRUCTURE FOR: tbl_report_penjualan
#

DROP TABLE IF EXISTS `tbl_report_penjualan`;

CREATE TABLE `tbl_report_penjualan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `toko_id` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `transaksi_id` bigint(20) DEFAULT NULL,
  `harga_id` bigint(20) DEFAULT NULL,
  `barang_id` bigint(20) DEFAULT NULL,
  `harga_satuan_pokok` double DEFAULT NULL,
  `harga_satuan_jual` double DEFAULT NULL,
  `qty` bigint(20) DEFAULT NULL,
  `total_harga_pokok` double DEFAULT NULL,
  `total_harga_jual` double DEFAULT NULL,
  `total_diskon` double DEFAULT NULL,
  `total_keuntungan` double DEFAULT NULL,
  `tanggal_beli` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `is_rollback` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('1', '8', '1', '1', '118', '217', '20000', '25000', '1', '20000', '25000', '3000', '2000', '2024-07-09 21:30:48', '2024-07-09 21:30:48', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('2', '8', '2', '2', '119', '218', '25000', '30000', '1', '25000', '30000', '5000', '0', '2024-07-09 21:41:03', '2024-07-09 21:41:03', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('3', '8', '3', '3', '118', '217', '20000', '25000', '1', '20000', '25000', '5000', '0', '2024-07-09 21:48:15', '2024-07-09 21:48:15', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('4', '8', '3', '3', '119', '218', '25000', '30000', '1', '25000', '30000', '10000', '-5000', '2024-07-09 21:48:15', '2024-07-09 21:48:15', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('5', '8', '4', '4', '118', '217', '20000', '25000', '1', '20000', '25000', '2000', '3000', '2024-07-09 22:13:52', '2024-07-09 22:13:52', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('6', '8', '5', '5', '118', '217', '20000', '25000', '1', '20000', '25000', '0', '5000', '2024-07-10 09:36:26', '2024-07-10 09:36:26', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('7', '8', '5', '5', '119', '218', '25000', '30000', '1', '25000', '30000', '0', '5000', '2024-07-10 09:36:26', '2024-07-10 09:36:26', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('8', '8', '6', '6', '118', '217', '20000', '25000', '1', '20000', '25000', '0', '5000', '2024-07-10 09:43:57', '2024-07-10 09:43:57', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('9', '8', '7', '7', '118', '217', '20000', '25000', '1', '20000', '25000', '0', '5000', '2024-07-10 09:48:30', '2024-07-10 09:48:30', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('10', '8', '8', '8', '118', '217', '20000', '25000', '1', '20000', '25000', '0', '5000', '2024-07-10 09:51:10', '2024-07-10 09:51:10', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('11', '8', '9', '9', '119', '218', '25000', '30000', '1', '25000', '30000', '0', '5000', '2024-07-10 09:52:24', '2024-07-10 09:52:24', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('12', '11', '10', '10', '12', '111', '41500', '50000', '1', '41500', '50000', '0', '8500', '2024-07-14 13:55:41', '2024-07-14 13:55:41', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('13', '11', '11', '11', '26', '125', '56200', '67000', '1', '56200', '67000', '0', '10800', '2024-07-14 15:31:52', '2024-07-14 15:31:52', 1);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('14', '11', '12', '12', '36', '135', '59000', '70000', '1', '59000', '70000', '0', '11000', '2024-07-14 15:34:25', '2024-07-14 15:34:25', 1);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('15', '11', '13', '13', '113', '212', '12750', '15000', '1', '12750', '15000', '0', '2250', '2024-07-15 18:14:37', '2024-07-15 18:14:37', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('16', '11', '13', '13', '23', '122', '18000', '22000', '1', '18000', '22000', '0', '4000', '2024-07-15 18:14:37', '2024-07-15 18:14:37', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('17', '11', '14', '14', '51', '150', '16000', '20000', '1', '16000', '20000', '0', '4000', '2024-07-15 18:19:47', '2024-07-15 18:19:47', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('18', '11', '14', '14', '43', '142', '5750', '7000', '1', '5750', '7000', '0', '1250', '2024-07-15 18:19:47', '2024-07-15 18:19:47', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('19', '11', '14', '14', '42', '141', '12000', '15000', '1', '12000', '15000', '0', '3000', '2024-07-15 18:19:47', '2024-07-15 18:19:47', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('20', '11', '14', '14', '23', '122', '18000', '22000', '1', '18000', '22000', '0', '4000', '2024-07-15 18:19:47', '2024-07-15 18:19:47', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('21', '11', '15', '15', '71', '170', '11300', '15000', '1', '11300', '15000', '0', '3700', '2024-07-15 18:20:57', '2024-07-15 18:20:57', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('22', '11', '16', '16', '42', '141', '12000', '15000', '1', '12000', '15000', '0', '3000', '2024-07-20 15:54:02', '2024-07-20 15:54:02', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('23', '11', '16', '16', '23', '122', '18000', '22000', '1', '18000', '22000', '0', '4000', '2024-07-20 15:54:02', '2024-07-20 15:54:02', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('24', '11', '17', '17', '80', '179', '5500', '8000', '1', '5500', '8000', '0', '2500', '2024-07-20 15:57:54', '2024-07-20 15:57:54', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('25', '11', '17', '17', '117', '216', '12000', '15000', '1', '12000', '15000', '0', '3000', '2024-07-20 15:57:54', '2024-07-20 15:57:54', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('26', '11', '18', '18', '23', '122', '18000', '22000', '1', '18000', '22000', '0', '4000', '2024-07-20 16:00:04', '2024-07-20 16:00:04', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('27', '11', '19', '19', '149', '249', '53410', '54500', '1', '53410', '54500', '0', '1090', '2024-07-21 10:53:51', '2024-07-21 10:53:51', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('28', '11', '20', '20', '26', '125', '56200', '67000', '1', '56200', '67000', '0', '10800', '2024-07-23 09:13:48', '2024-07-23 09:13:48', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('29', '11', '20', '20', '23', '122', '18000', '22000', '1', '18000', '22000', '0', '4000', '2024-07-23 09:13:48', '2024-07-23 09:13:48', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('30', '11', '20', '20', '25', '124', '56200', '67000', '1', '56200', '67000', '0', '10800', '2024-07-23 09:13:48', '2024-07-23 09:13:48', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('31', '11', '20', '20', '22', '121', '18000', '22000', '1', '18000', '22000', '0', '4000', '2024-07-23 09:13:48', '2024-07-23 09:13:48', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('32', '11', '21', '21', '10', '109', '14000', '18000', '1', '14000', '18000', '0', '4000', '2024-07-23 09:14:51', '2024-07-23 09:14:51', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('33', '11', '22', '22', '23', '122', '18000', '22000', '1', '18000', '22000', '0', '4000', '2024-07-24 08:27:08', '2024-07-24 08:27:08', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('34', '11', '23', '23', '42', '141', '12000', '15000', '1', '12000', '15000', '0', '3000', '2024-07-24 14:20:09', '2024-07-24 14:20:09', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('35', '11', '24', '24', '237', '341', '1000', '2500', '1', '1000', '2500', '0', '1500', '2024-07-25 11:55:18', '2024-07-25 11:55:18', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('36', '11', '25', '25', '26', '125', '56200', '67000', '1', '56200', '67000', '0', '10800', '2024-07-25 11:56:21', '2024-07-25 11:56:21', 0);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('37', '11', '26', '26', '159', '259', '1750', '2500', '1', '1750', '2500', '0', '750', '2024-07-27 15:23:37', '2024-07-27 15:23:37', 1);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('38', '11', '27', '27', '159', '259', '1750', '2500', '1', '1750', '2500', '0', '750', '2024-07-27 15:40:21', '2024-07-27 15:40:21', 1);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('39', '11', '30', '30', '159', '259', '1750', '2500', '1', '1750', '2500', '0', '750', '2024-07-27 15:41:33', '2024-07-27 15:41:33', 1);
INSERT INTO `tbl_report_penjualan` (`id`, `toko_id`, `order_id`, `transaksi_id`, `harga_id`, `barang_id`, `harga_satuan_pokok`, `harga_satuan_jual`, `qty`, `total_harga_pokok`, `total_harga_jual`, `total_diskon`, `total_keuntungan`, `tanggal_beli`, `created_at`, `is_rollback`) VALUES ('40', '11', '31', '31', '42', '141', '12000', '15000', '1', '12000', '15000', '0', '3000', '2024-07-28 11:43:27', '2024-07-28 11:43:27', 0);


#
# TABLE STRUCTURE FOR: tbl_report_penjualan_cacat
#

DROP TABLE IF EXISTS `tbl_report_penjualan_cacat`;

CREATE TABLE `tbl_report_penjualan_cacat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `toko_id` bigint(20) DEFAULT NULL,
  `order_cacat_id` bigint(20) DEFAULT NULL,
  `transaksi_cacat_id` bigint(20) DEFAULT NULL,
  `barang_cacat_id` bigint(20) DEFAULT NULL,
  `barang_id` bigint(20) DEFAULT NULL,
  `harga_satuan_pokok` double DEFAULT NULL,
  `harga_satuan_jual` double DEFAULT NULL,
  `qty` bigint(20) DEFAULT NULL,
  `total_harga_pokok` double DEFAULT NULL,
  `total_harga_jual` double DEFAULT NULL,
  `total_diskon` double DEFAULT NULL,
  `total_keuntungan` double DEFAULT NULL,
  `tanggal_beli` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `is_rollback` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_request_barang
#

DROP TABLE IF EXISTS `tbl_request_barang`;

CREATE TABLE `tbl_request_barang` (
  `id_request` bigint(20) NOT NULL AUTO_INCREMENT,
  `kode_request` varchar(100) DEFAULT NULL,
  `request_toko_id` bigint(20) DEFAULT NULL,
  `penerima_toko_id` bigint(20) DEFAULT NULL,
  `atribut_barang` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'id_harga\nnama_barang\nqty request\nketerangan',
  `pengirim` varchar(100) DEFAULT NULL,
  `status` text DEFAULT NULL COMMENT '"proses","terkirim","draft"',
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_request`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_request_delete_barang
#

DROP TABLE IF EXISTS `tbl_request_delete_barang`;

CREATE TABLE `tbl_request_delete_barang` (
  `id_request` bigint(20) NOT NULL AUTO_INCREMENT,
  `barang_id` bigint(20) DEFAULT NULL,
  `harga_id` bigint(20) DEFAULT NULL,
  `type_request` varchar(255) DEFAULT NULL COMMENT 'delete_barang, delete_barang_toko',
  `keterangan` text DEFAULT NULL COMMENT 'alasan',
  `is_deleted` int(11) DEFAULT 0 COMMENT 'jika 0 belum terhapus, tapi jika 1 sudah dihapus',
  `requested_shop` varchar(255) DEFAULT NULL,
  `requested_by` varchar(255) DEFAULT NULL,
  `requested_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_request`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_request_delete_barang` (`id_request`, `barang_id`, `harga_id`, `type_request`, `keterangan`, `is_deleted`, `requested_shop`, `requested_by`, `requested_date`) VALUES ('1', NULL, '3', 'delete_barang_toko', 'data salah', 1, '14', 'PUTRI', '2024-07-07 18:39:21');
INSERT INTO `tbl_request_delete_barang` (`id_request`, `barang_id`, `harga_id`, `type_request`, `keterangan`, `is_deleted`, `requested_shop`, `requested_by`, `requested_date`) VALUES ('2', NULL, '3', 'delete_barang_toko', 'data salah', 0, '14', 'PUTRI', '2024-07-07 22:12:36');


#
# TABLE STRUCTURE FOR: tbl_role
#

DROP TABLE IF EXISTS `tbl_role`;

CREATE TABLE `tbl_role` (
  `id_role` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(100) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_role`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (1, 'Developer', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (2, 'Superadmin', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (3, 'Kasir', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (4, 'Customer', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (5, 'Inventory', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (6, 'Direktur', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (7, 'Akuntan', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (8, 'Marketing', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (9, 'Keuangan', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (17, 'HRD', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (18, 'Admin Toko', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (20, 'Tes', 1);


#
# TABLE STRUCTURE FOR: tbl_satuan
#

DROP TABLE IF EXISTS `tbl_satuan`;

CREATE TABLE `tbl_satuan` (
  `id_satuan` bigint(20) NOT NULL AUTO_INCREMENT,
  `satuan` varchar(255) NOT NULL,
  `is_active` int(11) DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_satuan`),
  KEY `index_satuan` (`id_satuan`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('1', 'KG', 1, 'sistem', 'sistem', '2023-12-22 01:31:04', '2023-12-22 01:31:04');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', 'METER', 1, 'sistem', 'sistem', '2023-12-22 01:31:24', '2023-12-22 01:31:33');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('3', 'GRAM', 1, 'sistem', NULL, '0000-00-00 00:00:00', NULL);
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('4', 'ONS', 1, 'sistem', NULL, '0000-00-00 00:00:00', NULL);
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('5', 'LEMBAR', 1, 'sistem', 'sistem', '2024-01-03 14:02:37', '2024-01-03 14:02:37');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('7', 'BUNGKUS', 1, 'sistem', 'sistem', '2024-01-04 00:51:14', '2024-01-04 09:24:35');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('8', 'ROLL', 1, 'sistem', 'sistem', '2024-01-04 09:25:04', '2024-01-04 09:25:04');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('9', 'BUAH', 1, 'sistem', 'sistem', '2024-01-04 09:25:20', '2024-01-04 09:25:20');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('10', 'PCS', 1, 'sistem', 'sistem', '2024-01-04 09:25:30', '2024-01-04 09:25:30');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('11', 'PACK', 1, 'sistem', 'sistem', '2024-01-04 12:03:04', '2024-01-04 12:03:04');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('12', 'DUS', 1, 'sistem', 'sistem', '2024-01-04 12:03:10', '2024-01-04 12:03:10');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('13', 'SLOP', 1, 'sistem', 'sistem', '2024-01-04 12:03:24', '2024-01-04 12:03:24');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('14', 'SET', 1, 'sistem', 'sistem', '2024-01-04 12:03:30', '2024-01-04 12:03:30');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('15', 'dos', 0, 'sistem', 'sistem', '2024-01-04 12:06:46', '2024-01-04 12:07:12');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('16', 'GROSS', 1, 'sistem', 'sistem', '2024-01-04 14:23:45', '2024-01-04 14:23:45');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('17', 'RENTENG', 1, 'sistem', 'sistem', '2024-01-04 14:24:20', '2024-01-04 14:24:20');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('18', 'RIM', 1, 'sistem', 'sistem', '2024-01-04 14:24:56', '2024-01-04 14:24:56');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('19', 'BIJI', 1, 'sistem', 'sistem', '2024-01-04 17:00:45', '2024-01-04 17:00:45');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('20', 'KALENG', 1, 'sistem', 'sistem', '2024-01-04 17:02:21', '2024-01-04 17:02:21');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('21', 'LUSIN', 1, 'sistem', 'sistem', '2024-01-04 17:02:44', '2024-01-04 17:02:44');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('22', 'LONJOR', 1, 'sistem', 'sistem', '2024-02-06 22:18:40', '2024-02-06 22:18:40');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('23', '1JK', 0, 'sistem', 'sistem', '2024-07-02 21:59:35', '2024-07-02 21:59:48');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('24', 'ML', 1, 'sistem', 'sistem', '2024-07-07 18:44:28', '2024-07-07 18:44:28');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('25', 'LITER', 1, 'sistem', 'sistem', '2024-07-07 19:21:49', '2024-07-07 19:21:49');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('26', 'BAG', 1, 'sistem', 'sistem', '2024-07-10 23:23:55', '2024-07-10 23:23:55');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('27', 'KARTON', 1, 'sistem', 'sistem', '2024-07-10 23:24:03', '2024-07-10 23:24:03');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('28', 'PAKET', 1, 'sistem', 'sistem', '2024-07-10 23:26:26', '2024-07-10 23:26:26');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('29', 'BOTOL', 1, 'sistem', 'sistem', '2024-07-14 15:24:19', '2024-07-14 15:24:19');


#
# TABLE STRUCTURE FOR: tbl_setting
#

DROP TABLE IF EXISTS `tbl_setting`;

CREATE TABLE `tbl_setting` (
  `id_setting` bigint(20) NOT NULL AUTO_INCREMENT,
  `instansi` varchar(255) NOT NULL,
  `kode_instansi` varchar(255) NOT NULL,
  `alamat_instansi` varchar(255) DEFAULT NULL,
  `owner` varchar(255) NOT NULL,
  `wa_instansi` varchar(255) NOT NULL COMMENT 'Untuk Terdaftar di WA API',
  `wa_admin` varchar(255) NOT NULL COMMENT 'Untuk menerima pesan notifikasi, ketika ada order baru',
  `tlp_instansi` varchar(255) NOT NULL COMMENT 'nomor office kantor\n',
  `ig_instansi` varchar(255) DEFAULT NULL,
  `fb_instansi` varchar(255) DEFAULT NULL,
  `email_instansi` varchar(255) DEFAULT NULL,
  `deskripsi_singkat` text DEFAULT NULL,
  `img_instansi` text DEFAULT NULL,
  PRIMARY KEY (`id_setting`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_setting` (`id_setting`, `instansi`, `kode_instansi`, `alamat_instansi`, `owner`, `wa_instansi`, `wa_admin`, `tlp_instansi`, `ig_instansi`, `fb_instansi`, `email_instansi`, `deskripsi_singkat`, `img_instansi`) VALUES ('1', 'CARTA ARUM AGUNG', 'CARTAARUMAGUNG', 'Sidoarjo', 'sumber agung', '628787687682', '6289515314512', '2799896', 'wsss', 'ssdff', 'robby@ardhacodes.com', NULL, 'SUMBERAGUNG1719970418.png');


#
# TABLE STRUCTURE FOR: tbl_submenu
#

DROP TABLE IF EXISTS `tbl_submenu`;

CREATE TABLE `tbl_submenu` (
  `id_submenu` bigint(20) NOT NULL AUTO_INCREMENT,
  `menu_id` bigint(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_submenu`),
  KEY `FK_submenu_menu` (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('1', '1', 'Dashboard', 'dashboard', 'dashboard', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('2', '2', 'Role', 'role_akses', 'role_akses', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('3', '2', 'Menu', 'access', 'access/menu', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('4', '2', 'Sub Menu', 'access', 'access/submenu', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('5', '3', 'Management Toko', 'toko', 'toko/store_management', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('6', '3', 'Karyawan Toko', 'toko', 'toko/karyawan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('7', '7', 'Setting Instansi', 'setting', 'setting', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('8', '7', 'Backup Database', 'setting', 'setting/backupdb', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('9', '2', 'User', 'user', 'user/index', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('10', '4', 'Kategori', 'barang', 'barang/kategori', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('11', '4', 'Satuan', 'barang', 'barang/satuan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('12', '4', 'Barang', 'barang', 'barang/index', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('13', '5', 'Order', 'kasir', 'kasir/order', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('14', '4', 'Barang Masuk', 'barang', 'barang/masuk', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('15', '4', 'Barang Toko', 'barang', 'barang/barang_toko', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('16', '3', 'Diskon', 'toko', 'toko/diskon', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('17', '5', 'Scan', 'kasir', 'kasir/scan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('18', '4', 'Barang Keluar', 'barang', 'barang/keluar', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('19', '5', 'Sales order', 'kasir', 'kasir/sales_order', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('20', '5', 'Transaksi', 'kasir', 'kasir/transaksi', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('21', '6', 'Laporan Penjualan', 'laporan', 'laporan/penjualan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('22', '6', 'Riwayat Transaksi', 'riwayat', 'riwayat/transaksi', 0);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('23', '6', 'Laporan Transaksi', 'laporan', 'laporan/transaksi', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('24', '9', 'Banner', 'marketplace', 'marketplace/banner', 0);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('25', '6', 'Laporan Pendapatan', 'laporan', 'laporan/pendapatan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('26', '6', 'Laporan Stok', 'laporan', 'laporan/stok', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('27', '4', 'Request Hapus Barang', 'barang', 'barang/request_hapus_barang', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('28', '8', 'Banner', 'marketplace', 'marketplace/banner', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('29', '7', 'Bank', 'setting', 'setting/bank', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('30', '7', 'Payment', 'setting', 'setting/payment', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('31', '3', 'Supplier', 'toko', 'toko/supplier', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('32', '4', 'Request Barang', 'barang', 'barang/request_barang', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('33', '9', 'Masuk Cacat', 'barang_cacat', 'barang_cacat/masuk_cacat', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('34', '9', 'Master Cacat', 'barang_cacat', 'barang_cacat/master_cacat', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('35', '9', 'Pos', 'barang_cacat', 'barang_cacat/pos_cacat', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('36', '9', 'Penjualan', 'barang_cacat', 'barang_cacat/penjualan_cacat', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('37', '9', 'Transaksi', 'barang_cacat', 'barang_cacat/transaksi_cacat', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('38', '9', 'Barang Keluar', 'barang_cacat', 'barang_cacat/keluar_cacat', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('39', '9', 'Barang Musnah', 'barang_cacat', 'barang_cacat/musnah_cacat', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('40', '9', 'Laporan Penjualan', 'barang_cacat', 'barang_cacat/lp_penjualan_cacat', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('41', '9', 'Laporan Transaksi', 'barang_cacat', 'barang_cacat/lp_transaksi_cacat', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('42', '10', 'Driver Printer', 'driver', 'driver/driver_printer', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('43', '10', 'Driver App', 'driver', 'driver/driver_app', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('44', '10', 'coba1', 'utility', 'coba', 0);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `uri`, `url`, `is_active`) VALUES ('45', '12', 'Gudang', 'gudang', 'gudang/index', 1);


#
# TABLE STRUCTURE FOR: tbl_submenu_access
#

DROP TABLE IF EXISTS `tbl_submenu_access`;

CREATE TABLE `tbl_submenu_access` (
  `id_submenu_access` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL,
  `submenu_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id_submenu_access`)
) ENGINE=MyISAM AUTO_INCREMENT=1352 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('794', '8', '15');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1323', '1', '43');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1322', '1', '42');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1321', '1', '41');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1320', '1', '40');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1319', '1', '39');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1318', '1', '38');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1317', '1', '37');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1316', '1', '36');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1315', '1', '35');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1314', '1', '34');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1313', '1', '33');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1312', '1', '28');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1311', '1', '30');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1310', '1', '29');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1309', '1', '8');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1308', '1', '7');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1307', '1', '26');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1306', '1', '25');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1305', '1', '23');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1304', '1', '21');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1303', '1', '20');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1302', '1', '19');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1301', '1', '17');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1351', '2', '45');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1350', '2', '43');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1349', '2', '42');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1348', '2', '8');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1347', '2', '7');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1346', '2', '26');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1345', '2', '23');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1344', '2', '21');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1343', '2', '20');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1342', '2', '19');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1341', '2', '17');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1340', '2', '32');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1339', '2', '27');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1338', '2', '18');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1337', '2', '15');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1336', '2', '14');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1335', '2', '12');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1334', '2', '11');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('793', '8', '1');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1300', '1', '32');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('147', '5', '8');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('146', '5', '7');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('145', '5', '26');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('144', '5', '25');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('143', '5', '23');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('142', '5', '21');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('141', '5', '20');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('140', '5', '19');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('139', '5', '17');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('138', '5', '13');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('137', '5', '27');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('136', '5', '18');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('135', '5', '15');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('134', '5', '14');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('133', '5', '12');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('132', '5', '11');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('131', '5', '10');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('130', '5', '16');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('129', '5', '6');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('128', '5', '5');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('127', '5', '9');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('126', '5', '4');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('125', '5', '3');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('124', '5', '2');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('123', '5', '1');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('115', '17', '21');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('114', '17', '1');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('116', '17', '7');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1299', '1', '27');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1298', '1', '18');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1297', '1', '15');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1333', '2', '10');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1296', '1', '14');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1332', '2', '31');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1324', '1', '45');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1295', '1', '12');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1294', '1', '11');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1293', '1', '10');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1292', '1', '31');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1291', '1', '16');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1290', '1', '6');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1289', '1', '5');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1288', '1', '9');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1287', '1', '4');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1245', '3', '45');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1243', '3', '42');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1331', '2', '16');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1286', '1', '3');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1242', '3', '26');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1241', '3', '23');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1240', '3', '20');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1285', '1', '2');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1284', '1', '1');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1330', '2', '6');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1329', '2', '5');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1239', '3', '19');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1238', '3', '17');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1237', '3', '13');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1328', '2', '9');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1327', '2', '3');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1244', '3', '43');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1236', '3', '1');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1326', '2', '2');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1325', '2', '1');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1283', '18', '45');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1282', '18', '43');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1281', '18', '42');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1280', '18', '26');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1279', '18', '23');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1278', '18', '15');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('795', '8', '26');
INSERT INTO `tbl_submenu_access` (`id_submenu_access`, `role_id`, `submenu_id`) VALUES ('1277', '18', '1');


#
# TABLE STRUCTURE FOR: tbl_supplier
#

DROP TABLE IF EXISTS `tbl_supplier`;

CREATE TABLE `tbl_supplier` (
  `id_supplier` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama_supplier` varchar(255) NOT NULL,
  `no_telpon_supplier` varchar(14) NOT NULL,
  `alamat_supplier` text NOT NULL,
  `is_active` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_supplier`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_supplier` (`id_supplier`, `nama_supplier`, `no_telpon_supplier`, `alamat_supplier`, `is_active`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES ('1', 'Aaa', '03178745110', 'Aaa', 1, '2024-07-02 22:47:40', 'robby@ardhacodes.com', NULL, NULL);


#
# TABLE STRUCTURE FOR: tbl_toko
#

DROP TABLE IF EXISTS `tbl_toko`;

CREATE TABLE `tbl_toko` (
  `id_toko` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama_toko` varchar(255) NOT NULL,
  `alamat_toko` text NOT NULL,
  `notelp_toko` varchar(15) NOT NULL,
  `jenis` varchar(255) NOT NULL COMMENT 'MARKETPLACE | TOKO | GUDANG',
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_edit` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_toko`),
  KEY `index_toko` (`id_toko`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', 'SUMBER AGUNG ONLINE STORE', 'ONLINE', '6282333040775', 'MARKETPLACE', 1, '', 'sistem', '2024-07-07 20:04:13', '2023-12-22 01:23:25');
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', 'SUMBER BARU AGUNG', 'Jl. Raya Surabaya Kapuas No.04-AA1', '987689792', 'TOKO', 0, '', 'ss', '2024-01-19 20:27:09', '2023-12-22 01:23:25');
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', 'TOKO BIRU', 'hxjchsvjcv', '62812344556', 'TOKO', 0, 'Sinyo', NULL, '2023-12-22 23:06:04', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('4', 'TOKO HIJAU', 'ahsjhsdsa', '628123445561313', 'TOKO', 0, 'Sinyo', NULL, '2023-12-22 23:07:00', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('5', 'TOKO MERAH', 'Consequatur velit c', '6281234563277', 'TOKO', 0, 'Sinyo', NULL, '2023-12-27 23:24:33', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('6', 'TOKO SUMBER BANGUNAN', 'Jl. Ahmad Yani No.145, Megersari, Gedangan, Kec. Gedangan, Kabupaten Sidoarjo, Jawa Timur 61254', '62817339663', 'TOKO', 0, '', NULL, '2024-01-03 23:44:48', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('7', 'sumber jaya oke', 'asdasdasdasdasdasd', '567890', 'TOKO', 0, '', NULL, '2024-01-04 01:38:08', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('8', 'SUMBER AGUNG ELEKTRO', 'JL. SAMBIKEREP NO. 13 SURABAYA', '6282333040775', 'TOKO', 1, '', NULL, '2024-07-07 20:04:32', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('9', 'SUMBER AGUNG PUSAT', 'Perum. QUALITY REVERSIDE 2 CLUSTER DAISY BLOK II-27 RT. 29 RW. 07, KEMASAN KRIAN SIDOARJO', '6285257162700', 'TOKO', 0, 'Owner Toko', NULL, '2024-01-17 08:49:52', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('10', 'TOKO GARUDA 3', 'Sepanjang', '62317874511', 'TOKO', 0, '', NULL, '2024-01-19 21:10:19', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('11', 'TOKO SUMBER ARUM', 'JL. RAYA SAMBI KEREP', '6285704752548', 'TOKO', 1, '', NULL, '2024-07-07 20:03:41', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('12', 'GUDANG', 'Jl. aaaa', '628567655667', 'GUDANG', 0, 'Ownere', NULL, '2024-02-15 22:48:21', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('13', 'GUDANG COBA', 'COBA1', '62317874511', 'TOKO', 0, '', NULL, '2024-07-02 21:57:27', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('14', 'CAA ADMIN', 'SURABAYA', '12345678', 'GUDANG', 1, 'Owner Toko', NULL, '2024-07-06 20:32:35', NULL);


#
# TABLE STRUCTURE FOR: tbl_transaksi
#

DROP TABLE IF EXISTS `tbl_transaksi`;

CREATE TABLE `tbl_transaksi` (
  `id_transaksi` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) NOT NULL,
  `bank_id` bigint(20) DEFAULT NULL,
  `payment_id` bigint(20) DEFAULT NULL,
  `kode_transaksi` text DEFAULT NULL,
  `terbayar` double DEFAULT 0 COMMENT 'Nominal Customer Membayar',
  `kembalian` double DEFAULT 0 COMMENT 'Nominal Kembalian Customer',
  `tagihan_cart` double DEFAULT NULL COMMENT 'Tagihan Keranjang',
  `total_diskon` double DEFAULT NULL COMMENT 'Jumlah Keseluruhan Diskon',
  `tagihan_after_diskon` double DEFAULT NULL COMMENT 'Tagihan Keranjang - Total Diskon',
  `total_biaya_kirim` double DEFAULT NULL COMMENT 'Jumlah Nominal Biaya Kirim',
  `total_tagihan` double DEFAULT NULL COMMENT 'Total Tagihan = Tagihan After Diskon + Biaya Kirim',
  `tipe_transaksi` varchar(255) DEFAULT NULL COMMENT '"TRANSFER","TUNAI"',
  `bukti_tf` text DEFAULT NULL,
  `tanggal_beli` datetime DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `index_kodetrans` (`kode_transaksi`(1000)),
  KEY `index_transaksi` (`id_transaksi`,`order_id`) USING BTREE,
  KEY `FK_order` (`order_id`),
  CONSTRAINT `FK_order` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`id_order`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '1', NULL, NULL, 'INV-2024070000000001', '25000', '3000', '25000', '3000', '22000', '0', '25000', 'TUNAI', NULL, NULL, 1, 'FANDY', NULL, '2024-07-09 21:30:48', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', '2', NULL, NULL, 'INV-2024070000000002', '30000', '5000', '30000', '5000', '25000', '0', '30000', 'TUNAI', NULL, NULL, 1, 'FANDY', NULL, '2024-07-09 21:41:03', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', '3', NULL, NULL, 'INV-2024070000000003', '55000', '5000', '55000', '5000', '50000', '0', '55000', 'TUNAI', NULL, NULL, 1, 'FANDY', NULL, '2024-07-09 21:48:15', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('4', '4', NULL, NULL, 'INV-2024070000000004', '25000', '2000', '25000', '2000', '23000', '0', '25000', 'TUNAI', NULL, NULL, 1, 'FANDY', NULL, '2024-07-09 22:13:52', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('5', '5', NULL, NULL, 'INV-2024070000000005', '55000', '0', '55000', '0', '55000', '0', '55000', 'TUNAI', NULL, NULL, 1, 'FANDY', NULL, '2024-07-10 09:36:26', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('6', '6', NULL, NULL, 'INV-2024070000000006', '25000', '0', '25000', '0', '25000', '0', '25000', 'TUNAI', NULL, NULL, 1, 'FANDY', NULL, '2024-07-10 09:43:57', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('7', '7', NULL, NULL, 'INV-2024070000000007', '50000', '25000', '25000', '0', '25000', '0', '25000', 'TUNAI', NULL, NULL, 1, 'FANDY', NULL, '2024-07-10 09:48:30', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('8', '8', NULL, NULL, 'INV-2024070000000008', '50000', '25000', '25000', '0', '25000', '0', '25000', 'TUNAI', NULL, NULL, 1, 'FANDY', NULL, '2024-07-10 09:51:10', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('9', '9', NULL, NULL, 'INV-2024070000000009', '50000', '20000', '30000', '0', '30000', '0', '30000', 'TUNAI', NULL, NULL, 1, 'FANDY', NULL, '2024-07-10 09:52:24', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('11', '11', NULL, NULL, 'INV-2024070000000010', '100000', '33000', '67000', '0', '67000', '0', '67000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-14 15:31:52', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('12', '12', NULL, NULL, 'INV-2024070000000011', '100000', '30000', '70000', '0', '70000', '0', '70000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-14 15:34:25', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('13', '13', NULL, NULL, 'INV-2024070000000012', '37000', '0', '37000', '0', '37000', '0', '37000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-15 18:14:37', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('14', '14', NULL, NULL, 'INV-2024070000000013', '64000', '0', '64000', '0', '64000', '0', '64000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-15 18:19:47', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('15', '15', NULL, NULL, 'INV-2024070000000014', '15000', '0', '15000', '0', '15000', '0', '15000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-15 18:20:57', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('16', '16', NULL, NULL, 'INV-2024070000000015', '37000', '0', '37000', '0', '37000', '0', '37000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-20 15:54:02', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('17', '17', NULL, NULL, 'INV-2024070000000016', '23000', '0', '23000', '0', '23000', '0', '23000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-20 15:57:54', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('18', '18', NULL, NULL, 'INV-2024070000000017', '22000', '0', '22000', '0', '22000', '0', '22000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-20 16:00:04', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('19', '19', NULL, NULL, 'INV-2024070000000018', '54500', '0', '54500', '0', '54500', '0', '54500', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-21 10:53:51', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('20', '20', NULL, NULL, 'INV-2024070000000019', '178000', '0', '178000', '0', '178000', '0', '178000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-23 09:13:48', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('21', '21', NULL, NULL, 'INV-2024070000000020', '18000', '0', '18000', '0', '18000', '0', '18000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-23 09:14:51', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('22', '22', NULL, NULL, 'INV-2024070000000021', '22000', '0', '22000', '0', '22000', '0', '22000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-24 08:27:08', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('23', '23', NULL, NULL, 'INV-2024070000000022', '15000', '0', '15000', '0', '15000', '0', '15000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-24 14:20:09', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('24', '24', NULL, NULL, 'INV-2024070000000023', '2500', '0', '2500', '0', '2500', '0', '2500', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-25 11:55:18', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('25', '25', NULL, NULL, 'INV-2024070000000024', '67000', '0', '67000', '0', '67000', '0', '67000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-25 11:56:21', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('26', '26', NULL, NULL, 'INV-2024070000000025', '2500', '0', '2500', '0', '2500', '0', '2500', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-27 15:23:37', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('27', '27', NULL, NULL, 'INV-2024070000000026', '2500', '0', '2500', '0', '2500', '0', '2500', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-27 15:40:21', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('30', '30', NULL, NULL, 'INV-2024070000000027', '2500', '0', '2500', '0', '2500', '0', '2500', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-27 15:41:33', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `bank_id`, `payment_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `tanggal_beli`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('31', '31', NULL, NULL, 'INV-2024070000000028', '15000', '0', '15000', '0', '15000', '0', '15000', 'TUNAI', NULL, NULL, 1, 'BELDA', NULL, '2024-07-28 11:43:27', NULL);


#
# TABLE STRUCTURE FOR: tbl_transaksi_cacat
#

DROP TABLE IF EXISTS `tbl_transaksi_cacat`;

CREATE TABLE `tbl_transaksi_cacat` (
  `id_transaksi_cacat` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_cacat_id` bigint(20) NOT NULL,
  `bank_id` bigint(20) DEFAULT NULL,
  `payment_id` bigint(20) DEFAULT NULL,
  `kode_transaksi` text DEFAULT NULL,
  `terbayar` double DEFAULT 0 COMMENT 'Nominal Customer Membayar',
  `kembalian` double DEFAULT 0 COMMENT 'Nominal Kembalian Customer',
  `tagihan_cart` double DEFAULT NULL COMMENT 'Tagihan Keranjang',
  `total_diskon` double DEFAULT NULL COMMENT 'Jumlah Keseluruhan Diskon',
  `tagihan_after_diskon` double DEFAULT NULL COMMENT 'Tagihan Keranjang - Total Diskon',
  `total_biaya_kirim` double DEFAULT NULL COMMENT 'Jumlah Nominal Biaya Kirim',
  `total_tagihan` double DEFAULT NULL COMMENT 'Total Tagihan = Tagihan After Diskon + Biaya Kirim',
  `tipe_transaksi` varchar(255) DEFAULT NULL COMMENT '"TRANSFER","TUNAI"',
  `bukti_tf` text DEFAULT NULL,
  `tanggal_beli` datetime DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_transaksi_cacat`) USING BTREE,
  KEY `index_kodetrans` (`kode_transaksi`(1000)),
  KEY `index_transaksi` (`id_transaksi_cacat`,`order_cacat_id`) USING BTREE,
  KEY `FK_order` (`order_cacat_id`),
  CONSTRAINT `tbl_transaksi_cacat_ibfk_1` FOREIGN KEY (`order_cacat_id`) REFERENCES `tbl_order` (`id_order`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_user
#

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id_user` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `nama_user` varchar(200) NOT NULL,
  `password` varchar(225) NOT NULL,
  `role_id` int(11) NOT NULL,
  `type_user` varchar(255) DEFAULT NULL COMMENT 'Jika Developer Akan Muncul Menu Management Akses\n\ndan tidak muncul pada menu karyawan toko\n\n\njika null tidak memiliki management akses',
  `is_active` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'robby@ardhacodes.com', 'SINYO', '$2y$10$LehzOBWPnnLpkjTMN4V3fON8golwh6AqGhS5EzLWZ1qLBeHqJwvPC', 1, 'DEV', 1, '2024-01-01 13:00:27', '2024-01-01 13:00:46');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'dev@ardhacodes.com', 'DEVELOPER', '$2y$10$rggSg5krhFPztTGHNYPq4O9rHHBy.5JUeo0XNr5ibP9nKQiyf28y2', 1, 'DEV', 1, '2024-01-01 13:00:27', '2024-01-01 13:03:59');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'owner', 'Owner Toko', '$2y$10$xIxSzi1eHUAQrGodSQTM0.yvuZbN4X5pyv1ZX1wUxmxLqnR3LkbdG', 2, NULL, 1, '2024-01-01 13:25:19', '2024-07-03 08:36:20');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('4', 'bapakhrd', 'bapak HRD', '$2y$10$AfwH04YluzWfoeuIYB5oceWjLhwDlFsPmdyOZuzRnUZ0lDxvZ95wi', 17, NULL, 1, '2024-01-21 16:15:52', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('7', 'kasirbunda', 'Kasir Bunda', '$2y$10$cVdj/0W678RhsmbzDbNJyegRt.KXSqbyqyv8EkVxKSO1iCJLDmmSC', 3, NULL, 1, '2024-02-06 17:55:14', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('9', 'admintoko', 'Admin Toko', '$2y$10$BGL.22u47wNofI//IKz5suYocB33dLYv6ia7G7FQLv2RI6QBzbqmO', 18, NULL, 1, '2024-02-11 18:40:16', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('12', '454545', '123123', '$2y$10$vQMP1hs3gPYnAW3MRp2dH.oQq.FfH5gP4dU2AaJjnU1imZ1P0S5CO', 1, NULL, 1, '2024-07-02 21:58:09', '2024-07-02 21:58:20');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('13', 'Kasir123', 'Fulan rohman', '$2y$10$.d7wAUNkcwy4PWdG338ztuvm1EBRZmVWPzJAasOF1qmu1lljUJg/u', 3, NULL, 1, '2024-07-02 22:56:03', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('14', 'Kasir321', 'Fulano ', '$2y$10$pA9UFsRRnDysjpe1zKY5L.Q1Vhkg2ss7RP6BY3PC.TTwlWgoGGLIG', 3, NULL, 1, '2024-07-02 22:56:03', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('15', 'PUTRI', 'PUTRI', '$2y$10$qeOApTFN/oy9mKez0rgUvOF4NzrRhmWMwaVIKsRF5NeHnhim62e2K', 18, NULL, 1, '2024-07-06 20:23:18', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('16', 'PUTRI01', 'PUTRI', '$2y$10$6a.fxFGWbuMopCsSJPSLPeTHZQHzA1goN5hPyGF9b0.YaYjs382sa', 18, NULL, 1, '2024-07-06 20:26:24', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('17', 'PUTRI02', 'PUTRI', '$2y$10$IQSk6YFY2Nt1g18BvTQu7OwekApbUK8MZnC7a3fNsnkoLGn4MC2CW', 18, NULL, 1, '2024-07-06 20:27:57', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('18', 'PUTRI_01', 'PUTRI', '$2y$10$MwLVKyVN4JJ5EEBKkoRLTO8tzY.qIgsMtC.BBaNr8rMzUhPJse7v.', 18, NULL, 1, '2024-07-06 20:34:29', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('19', 'PUTRI-01', 'PUTRI', '$2y$10$vMQf1mJuw8V9ucHauSbSvOGhF6NhyOzir4RK5.Ohek9O9dl9OV5EG', 18, NULL, 1, '2024-07-06 20:35:31', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('20', 'FANDY_01', 'FANDY', '$2y$10$A/tGgw2CaZIssbjCS8uGF.zv0.118hrOcFFsPNWu7l28euYErGcYa', 3, NULL, 1, '2024-07-06 20:42:28', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('21', 'BELDA_01', 'BELDA', '$2y$10$y36aG7IhuCkwrYSMwCGn5Ofk6yhUdwAFk3es.B0yX2mDzIS/cV6uO', 3, NULL, 1, '2024-07-06 20:44:15', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('22', 'putri_011', 'Putri', '$2y$10$e3j2e85wru2QTljHjAsjaO8xLLGpT8fvJHW24W8BynGER9bEcmzou', 18, NULL, 1, '2024-07-09 21:56:08', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('23', 'PUTRI_1', 'PUTRI', '$2y$10$PTdLk34ALYLKMU9gvo9Z4.hrmnCTVXa9nuJnjUFbRnql90YTzS0ES', 18, NULL, 1, '2024-07-14 15:57:42', NULL);
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `type_user`, `is_active`, `created_at`, `updated_at`) VALUES ('24', 'PUTRI_2', 'PUTRI', '$2y$10$vZWSwSio9DJx8YgQNTeAdOVaff5uEL3fVR850ZABQfCEMeXPbTjRq', 18, NULL, 1, '2024-07-14 15:58:30', NULL);


