#
# TABLE STRUCTURE FOR: log_import
#

DROP TABLE IF EXISTS `log_import`;

CREATE TABLE `log_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` text DEFAULT NULL,
  `file` text DEFAULT NULL,
  `wk_input` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (1, '/tmp/php905M5j', 'format_barang_toko_import_2.xlsx', '2023-12-20 02:35:23');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (2, '/tmp/phpoeeUAU', 'format_barang_toko_import_2 (1).xlsx', '2023-12-20 02:37:34');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (3, '/tmp/php3c88NZ', 'format_barang_toko_import_2.xlsx', '2023-12-20 17:12:19');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (4, '/Applications/MAMP/tmp/php/phpEiZOoL', 'format_barang_toko_import_2.xlsx', '2023-12-20 20:33:01');
INSERT INTO `log_import` (`id`, `path`, `file`, `wk_input`) VALUES (5, '/Applications/MAMP/tmp/php/phpkgSBr0', 'format_barang_toko_import_2 (2).xlsx', '2023-12-20 20:54:59');


#
# TABLE STRUCTURE FOR: tbl_alamat_customer
#

DROP TABLE IF EXISTS `tbl_alamat_customer`;

CREATE TABLE `tbl_alamat_customer` (
  `id_alamat` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `provinsi_id` bigint(20) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `kabupaten_id` bigint(20) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  `is_default` int(11) DEFAULT 0,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_alamat`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_alamat_customer` (`id_alamat`, `customer_id`, `provinsi`, `provinsi_id`, `kabupaten`, `kabupaten_id`, `alamat`, `is_active`, `is_default`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '1', 'Bali', '1', 'Badung', '17', 'hhh', 1, 1, 'dhika', NULL, '2023-12-19 19:48:51', NULL);


#
# TABLE STRUCTURE FOR: tbl_barang
#

DROP TABLE IF EXISTS `tbl_barang`;

CREATE TABLE `tbl_barang` (
  `id_barang` bigint(20) NOT NULL AUTO_INCREMENT,
  `kategori_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_kategori',
  `satuan_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_satuan',
  `kode_barang` varchar(255) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `slug_barang` text NOT NULL,
  `barcode_barang` text NOT NULL,
  `harga_pokok` decimal(65,0) NOT NULL,
  `berat_barang` double NOT NULL,
  `deskripsi` text NOT NULL,
  `informasi` text DEFAULT NULL,
  `gambar` text DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_barang`),
  KEY `index_barang` (`id_barang`,`kategori_id`,`satuan_id`,`kode_barang`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('5', '2', '2', 'BRG-000004', 'Barang mbsk riska', 'barang-mbsk-riska', '12345678', '35435', '45', '&lt;p&gt;jknbhjkbhjhgvghvgggvhjvkbkbkjb&lt;/p&gt;\r\n', NULL, '', 1, 'admin', 'robby@ardhacodes.com', '2023-12-20 01:38:05', '2023-12-20 14:07:36');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('6', '2', '2', 'BRG-000005', 'roti', 'roti', '1234', '313144', '21231', '&lt;p&gt;1132455&lt;/p&gt;\r\n', NULL, '', 1, 'admin', 'kasirbunda', '2023-12-20 07:17:09', '2023-12-21 21:41:14');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('7', '2', '2', 'BRG-000006', 'CobaDhika', 'cobadhika', '869104050113265', '50000', '10', 'Meteran Merk Shicibukai panjang 8 Meter', NULL, '', 1, 'Sinyo', 'robby@ardhacodes.com', '2023-12-20 07:35:45', '2023-12-20 14:04:12');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('8', '1', '2', 'BRG-000006', 'CobaDhikaKun', 'cobadhikakun', '135916423622', '1000000', '5', '&lt;p&gt;Merk Zimbabwe&lt;/p&gt;\r\n', NULL, '', 1, 'Sinyo', 'robby@ardhacodes.com', '2023-12-20 07:35:45', '2023-12-20 07:52:35');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('9', '1', '2', 'BRG-000007', 'Veniam id molestiae', 'veniam-id-molestiae', '863246050723878', '900000', '90', '&lt;p&gt;90&lt;/p&gt;\r\n', NULL, NULL, 1, 'robby@ardhacodes.com', 'kasirbunda', '2023-12-21 20:31:38', '2023-12-21 21:40:21');
INSERT INTO `tbl_barang` (`id_barang`, `kategori_id`, `satuan_id`, `kode_barang`, `nama_barang`, `slug_barang`, `barcode_barang`, `harga_pokok`, `berat_barang`, `deskripsi`, `informasi`, `gambar`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('10', '1', '2', 'BRG-000008', '123', '123', '978302618153', '123', '123', '&lt;p&gt;123&lt;/p&gt;\r\n', NULL, '169592273.png', 1, 'robby@ardhacodes.com', 'robby@ardhacodes.com', '2023-12-21 20:37:11', '2023-12-21 21:45:59');


#
# TABLE STRUCTURE FOR: tbl_barang_history
#

DROP TABLE IF EXISTS `tbl_barang_history`;

CREATE TABLE `tbl_barang_history` (
  `id_barang_history` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_barang` bigint(20) NOT NULL,
  `kategori_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_kategori',
  `satuan_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_satuan',
  `kode_barang` varchar(255) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `slug_barang` text NOT NULL,
  `barcode_barang` text NOT NULL,
  `harga_pokok` decimal(65,0) NOT NULL,
  `berat_barang` double NOT NULL,
  `deskripsi` text NOT NULL,
  `informasi` text DEFAULT NULL,
  `gambar` text NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_barang_history`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_barang_keluar
#

DROP TABLE IF EXISTS `tbl_barang_keluar`;

CREATE TABLE `tbl_barang_keluar` (
  `id_barang_keluar` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_detail_id` bigint(20) DEFAULT NULL,
  `harga_id` bigint(20) NOT NULL,
  `jenis_keluar` varchar(100) NOT NULL COMMENT 'TERJUAL DISTRIBUSI',
  `request_id` bigint(20) DEFAULT 0,
  `jml_keluar` bigint(20) NOT NULL,
  `bukti_keluar` text NOT NULL,
  `is_rollback` int(11) DEFAULT 0,
  `user_input` varchar(100) NOT NULL,
  `user_edit` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_barang_keluar`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '3', '1', 'TERJUAL', '0', '4', '', 0, 'Sinyo', '', '2023-12-19 19:50:25', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('6', NULL, '2', 'DISTRIBUSI', '0', '1', '', 0, 'Sinyo', '', '2023-12-20 08:02:06', NULL);
INSERT INTO `tbl_barang_keluar` (`id_barang_keluar`, `order_detail_id`, `harga_id`, `jenis_keluar`, `request_id`, `jml_keluar`, `bukti_keluar`, `is_rollback`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('5', NULL, '4', 'DISTRIBUSI', '0', '20', '', 0, 'Kasir bunda', '', '2023-12-20 07:46:38', NULL);


#
# TABLE STRUCTURE FOR: tbl_barang_masuk
#

DROP TABLE IF EXISTS `tbl_barang_masuk`;

CREATE TABLE `tbl_barang_masuk` (
  `id_barang_masuk` bigint(20) NOT NULL AUTO_INCREMENT,
  `toko_id` bigint(20) DEFAULT NULL,
  `barang_id` bigint(20) DEFAULT NULL,
  `jml_masuk` bigint(20) DEFAULT NULL,
  `bukti_beli` text DEFAULT NULL,
  `tipe` varchar(100) DEFAULT NULL COMMENT '''toko_luar'',''gudang''',
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_barang_masuk`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_barang_masuk` (`id_barang_masuk`, `toko_id`, `barang_id`, `jml_masuk`, `bukti_beli`, `tipe`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', '2', '6', '21314244', 'bukti struk.PNG', 'gudang', 'admin', NULL, '2023-12-20 07:17:33', NULL);
INSERT INTO `tbl_barang_masuk` (`id_barang_masuk`, `toko_id`, `barang_id`, `jml_masuk`, `bukti_beli`, `tipe`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', '1', '6', '12', 'bukti struk.PNG', 'toko_luar', 'admin', NULL, '2023-12-20 16:37:07', NULL);
INSERT INTO `tbl_barang_masuk` (`id_barang_masuk`, `toko_id`, `barang_id`, `jml_masuk`, `bukti_beli`, `tipe`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('4', '1', '5', '499', 'bukti struk.PNG', 'toko_luar', 'admin', NULL, '2023-12-21 00:42:43', NULL);
INSERT INTO `tbl_barang_masuk` (`id_barang_masuk`, `toko_id`, `barang_id`, `jml_masuk`, `bukti_beli`, `tipe`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('5', '2', '6', '500', 'bukti struk.PNG', 'toko_luar', 'admin', NULL, '2023-12-21 03:40:44', NULL);


#
# TABLE STRUCTURE FOR: tbl_barang_temp
#

DROP TABLE IF EXISTS `tbl_barang_temp`;

CREATE TABLE `tbl_barang_temp` (
  `id_barang` bigint(20) NOT NULL AUTO_INCREMENT,
  `kategori_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_kategori',
  `satuan_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_satuan',
  `kode_barang` varchar(255) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `slug_barang` text NOT NULL,
  `barcode_barang` text NOT NULL,
  `harga_pokok` decimal(65,0) NOT NULL,
  `berat_barang` double NOT NULL,
  `deskripsi` text NOT NULL,
  `gambar` text DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_barang`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_customer
#

DROP TABLE IF EXISTS `tbl_customer`;

CREATE TABLE `tbl_customer` (
  `id_customer` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `hp` varchar(50) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  PRIMARY KEY (`id_customer`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_customer` (`id_customer`, `nama`, `email`, `hp`, `password`, `user_input`, `user_edit`, `created_at`, `updated_at`, `is_active`) VALUES ('1', 'dhika', 'dhika@gmail.com', '62317874510', '$2y$10$05fXI1HpgeHTB5FgkgUvau2eNY1v3IeehODlbYZFKLURnYYxwgJNa', 'dhika', 'dhika', '2023-12-19 19:47:53', '2023-12-19 19:47:53', 1);


#
# TABLE STRUCTURE FOR: tbl_diskon
#

DROP TABLE IF EXISTS `tbl_diskon`;

CREATE TABLE `tbl_diskon` (
  `id_diskon` bigint(20) NOT NULL AUTO_INCREMENT,
  `harga_id` bigint(20) DEFAULT NULL,
  `nama_diskon` varchar(100) DEFAULT NULL,
  `harga_potongan` double DEFAULT NULL,
  `tgl_mulai` date DEFAULT NULL,
  `tgl_akhir` date DEFAULT NULL,
  `minimal_beli` bigint(20) DEFAULT 1,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_active` int(11) DEFAULT 1,
  PRIMARY KEY (`id_diskon`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_harga
#

DROP TABLE IF EXISTS `tbl_harga`;

CREATE TABLE `tbl_harga` (
  `id_harga` bigint(20) NOT NULL AUTO_INCREMENT,
  `barang_id` bigint(20) DEFAULT NULL,
  `toko_id` bigint(20) DEFAULT NULL,
  `stok_toko` bigint(20) DEFAULT NULL,
  `harga_jual` double DEFAULT NULL,
  `is_active` int(11) DEFAULT NULL,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_harga`),
  KEY `index_harga` (`id_harga`,`barang_id`,`toko_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '3', '1', '86', '80000', 1, 'riska', 'riska', '2023-12-20 02:30:34', '2023-12-20 02:30:37');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', '5', '1', '579', '2', 1, NULL, 'Usopp', '2023-12-20 02:32:27', '2023-12-21 00:42:43');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('4', '3', '2', '50', '20000', 1, 'rama', NULL, NULL, NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('5', '6', '2', '510', '50000', 1, 'admin', 'Usopp', '2023-12-20 17:12:19', '2023-12-21 03:40:44');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('6', '7', '1', '20', '7', 1, NULL, NULL, '2023-12-20 20:20:38', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('7', '6', '1', '212', '6', 1, NULL, 'Usopp', '2023-12-20 20:52:12', '2023-12-20 16:37:07');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('8', '5', '2', '100', '5', 0, NULL, NULL, '2023-12-20 20:52:40', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('9', '6', '4', '10', '50000000', 1, 'robby@ardhacodes.com', 'Sinyo', '2023-12-20 20:54:59', '2023-12-21 04:59:53');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('13', '8', '2', '10', '200', 0, NULL, 'Kasir bunda', '2023-12-20 23:25:58', '2023-12-20 23:36:16');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('12', '7', '2', '2', '90', 1, NULL, 'Kasir bunda', '2023-12-20 23:11:22', '2023-12-20 23:39:22');
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('15', '9', '1', '20', '9', 1, NULL, NULL, '2023-12-21 20:32:13', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('16', '10', '1', '100', '10', 1, NULL, NULL, '2023-12-21 20:37:59', NULL);
INSERT INTO `tbl_harga` (`id_harga`, `barang_id`, `toko_id`, `stok_toko`, `harga_jual`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('17', '9', '2', '213', '9', 1, NULL, NULL, '2023-12-21 21:38:16', NULL);


#
# TABLE STRUCTURE FOR: tbl_karyawan_toko
#

DROP TABLE IF EXISTS `tbl_karyawan_toko`;

CREATE TABLE `tbl_karyawan_toko` (
  `id_karyawan` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_user',
  `toko_id` bigint(20) NOT NULL COMMENT 'relasi ke tbl_toko',
  `nama_karyawan` varchar(100) DEFAULT NULL,
  `hp_karyawan` varchar(100) DEFAULT NULL,
  `alamat_karyawan` text DEFAULT NULL,
  `bagian` varchar(100) DEFAULT NULL,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_karyawan`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', '2', '1', 'Rama riska', '0317874511', 'Rama nikah dengan riska', 'tetap', 'sistem', 'sistem', '2023-12-19 19:21:40', '2023-12-19 19:21:40');
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('3', '23', '2', 'Kasir Brian', '23786432846', 'kasjdsajkdh', 'tetap', 'sistem', 'sistem', '0000-00-00 00:00:00', NULL);
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('4', '23', '1', 'hhh', NULL, NULL, NULL, '', NULL, '0000-00-00 00:00:00', NULL);
INSERT INTO `tbl_karyawan_toko` (`id_karyawan`, `user_id`, `toko_id`, `nama_karyawan`, `hp_karyawan`, `alamat_karyawan`, `bagian`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('5', '26', '2', 'Riska Aulia', '08192898712', 'dkvmklsfmklvmflkvmlkmvlk;dgmlkm', 'kontrak', 'sistem', 'sistem', '2023-12-20 06:37:47', '2023-12-20 10:17:50');


#
# TABLE STRUCTURE FOR: tbl_kategori
#

DROP TABLE IF EXISTS `tbl_kategori`;

CREATE TABLE `tbl_kategori` (
  `id_kategori` bigint(20) NOT NULL AUTO_INCREMENT,
  `kode_kategori` varchar(255) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL,
  `slug_kategori` text NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_kategori`),
  KEY `index_kategori` (`id_kategori`,`kode_kategori`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('1', 'BERAT', 'Berat', 'berat', 1, 'sistem', 'sistem', '2023-12-19 19:23:17', '2023-12-19 19:23:17');
INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', 'RINGANS', 'Ringan', 'ringan', 1, 'sistem', 'sistem', '2023-12-19 19:23:34', '2023-12-19 19:23:41');
INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('3', 'Ahh', 'Ahh', 'ahh', 0, 'sistem', 'sistem', '2023-12-19 19:23:47', '2023-12-19 19:23:51');
INSERT INTO `tbl_kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`, `slug_kategori`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('4', '10', 'Batu', 'batu', 0, 'sistem', 'sistem', '2023-12-21 04:32:02', '2023-12-21 04:32:48');


#
# TABLE STRUCTURE FOR: tbl_menu
#

DROP TABLE IF EXISTS `tbl_menu`;

CREATE TABLE `tbl_menu` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(100) NOT NULL,
  `icon` varchar(155) NOT NULL,
  `is_active` int(2) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_menu`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (1, 'Dashboard', 'menu-icon tf-icons bx bx-home-circle', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (2, 'Management Akses', 'menu-icon tf-icons bx bx-lock-open', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (3, 'Toko', 'menu-icon tf-icons bx bxs-store', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (4, 'Barang', 'menu-icon tf-icons bx bxs-buildings', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (5, 'Kasir', 'menu-icon tf-icons bx bxs-wallet', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (6, 'Laporan', 'menu-icon tf-icons bx bxs-report', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (7, 'Setting', 'menu-icon tf-icons bx bxs-cog', 1);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (9, 'Kimoci', 'bx bxl-flask', 0);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (10, 'Kimocisenpai', 'bx bxl-flask', 0);
INSERT INTO `tbl_menu` (`id_menu`, `menu`, `icon`, `is_active`) VALUES (11, 'areh', 'bx bx-child', 0);


#
# TABLE STRUCTURE FOR: tbl_order
#

DROP TABLE IF EXISTS `tbl_order`;

CREATE TABLE `tbl_order` (
  `id_order` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Opsional berlaku pada marketplace',
  `toko_id` bigint(20) NOT NULL,
  `kode_order` longtext NOT NULL,
  `nama_cust` varchar(100) DEFAULT NULL,
  `hp_cust` varchar(100) DEFAULT NULL,
  `alamat_cust` text DEFAULT NULL,
  `tipe_order` enum('Marketplace','Kasir') NOT NULL,
  `tipe_pengiriman` text NOT NULL,
  `biaya_kirim` decimal(10,0) NOT NULL,
  `bukti_kirim` text DEFAULT NULL,
  `total_order` decimal(16,0) NOT NULL,
  `paidst` int(11) NOT NULL DEFAULT 0,
  `status` int(11) DEFAULT 1 COMMENT '1 = belum konfirmasi, 2 = sudah konfirmasi, 3 = dikemas, 4 = dikirim, 5 = selesai, 99 = dibatalkan',
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_edit` varchar(100) DEFAULT NULL,
  `user_input` varchar(100) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_order`),
  KEY `index_order` (`id_order`,`user_id`,`toko_id`),
  FULLTEXT KEY `kode_order_index` (`kode_order`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('1', '1', '2', 'd908fb285c0a49e48eeb8eabd69fd398', 'dhika', '62317874510', 'Bali, Kab.Badung. Alamat rumah : hhh', 'Marketplace', 'JNE', '100000', NULL, '420000', 1, 5, 1, 'robby@ardhacodes.com', 'dhika', '2023-12-20 02:50:38', '2023-12-19 19:49:37');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('2', NULL, '1', 'fb4ae486117d456a9e6b173d125687f6', '', '', '', 'Kasir', '', '0', NULL, '80000', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-19 19:55:03');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('3', NULL, '1', '2fc13df310254925becb9ca0db015ad1', '', '', '', 'Kasir', '', '0', NULL, '80000', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-19 19:55:10');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('4', NULL, '1', '37b4f0418cb34db1b7a1ce087a80dc3b', 'awdawd', '031', 'awdawd', 'Kasir', 'JNE', '10000', NULL, '80000', 0, 1, 1, NULL, 'Kasir bunda', NULL, '2023-12-19 19:55:58');
INSERT INTO `tbl_order` (`id_order`, `user_id`, `toko_id`, `kode_order`, `nama_cust`, `hp_cust`, `alamat_cust`, `tipe_order`, `tipe_pengiriman`, `biaya_kirim`, `bukti_kirim`, `total_order`, `paidst`, `status`, `is_active`, `user_edit`, `user_input`, `updated_at`, `created_at`) VALUES ('5', '1', '2', 'e12e1c7eccb34ec1bcfda9022b3ab5d8', 'dhika', '62317874510', 'Bali, Kab.Badung. Alamat rumah : hhh', 'Marketplace', '', '0', NULL, '156', 0, 1, 1, NULL, 'dhika', NULL, '2023-12-20 15:47:55');


#
# TABLE STRUCTURE FOR: tbl_order_detail
#

DROP TABLE IF EXISTS `tbl_order_detail`;

CREATE TABLE `tbl_order_detail` (
  `id_order_detail` bigint(20) NOT NULL AUTO_INCREMENT,
  `harga_id` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `qty` bigint(20) DEFAULT NULL,
  `harga_total` double DEFAULT NULL,
  `harga_potongan` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`harga_potongan`)),
  `user_edit` varchar(100) DEFAULT NULL,
  `user_input` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_order_detail`),
  KEY `index_order_detail` (`id_order_detail`,`harga_id`,`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('3', '1', '1', '4', '320000', '[]', NULL, 'robby@ardhacodes.com', '2023-12-19 19:50:18', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('4', '3', '1', '2', '100000', '[]', NULL, 'robby@ardhacodes.com', '2023-12-19 19:50:18', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('5', '3', '2', '1', '80000', '[]', NULL, 'Kasir bunda', '2023-12-19 19:55:03', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('6', '2', '5', '8', '16', '[]', NULL, 'dhika', '2023-12-20 15:47:55', NULL);
INSERT INTO `tbl_order_detail` (`id_order_detail`, `harga_id`, `order_id`, `qty`, `harga_total`, `harga_potongan`, `user_edit`, `user_input`, `created_at`, `updated_at`) VALUES ('7', '6', '5', '20', '140', '[]', NULL, 'dhika', '2023-12-20 15:47:55', NULL);


#
# TABLE STRUCTURE FOR: tbl_order_marketplace
#

DROP TABLE IF EXISTS `tbl_order_marketplace`;

CREATE TABLE `tbl_order_marketplace` (
  `id_order_marketplace` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id_order_marketplace`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_privilege_menu
#

DROP TABLE IF EXISTS `tbl_privilege_menu`;

CREATE TABLE `tbl_privilege_menu` (
  `id_privilege` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`id_privilege`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (1, 1, 1);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (2, 1, 2);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (3, 1, 3);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (4, 1, 4);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (5, 1, 5);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (6, 1, 6);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (7, 1, 7);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (8, 3, 1);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (9, 3, 5);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (10, 3, 4);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (11, 3, 3);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (12, 8, 1);
INSERT INTO `tbl_privilege_menu` (`id_privilege`, `role_id`, `menu_id`) VALUES (13, 8, 2);


#
# TABLE STRUCTURE FOR: tbl_privilege_submenu
#

DROP TABLE IF EXISTS `tbl_privilege_submenu`;

CREATE TABLE `tbl_privilege_submenu` (
  `id_privilege_submenu` int(11) NOT NULL AUTO_INCREMENT,
  `privilege_id` int(11) NOT NULL,
  `submenu_id` int(11) NOT NULL,
  PRIMARY KEY (`id_privilege_submenu`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (1, 1, 1);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (2, 2, 2);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (3, 2, 3);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (4, 2, 4);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (5, 3, 5);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (11, 3, 6);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (7, 7, 7);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (8, 7, 8);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (10, 2, 9);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (12, 4, 10);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (18, 4, 11);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (19, 5, 14);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (20, 4, 12);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (21, 4, 15);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (22, 3, 16);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (23, 4, 17);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (24, 3, 18);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (25, 5, 19);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (26, 8, 1);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (27, 9, 19);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (28, 9, 14);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (29, 4, 20);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (30, 5, 21);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (31, 5, 22);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (32, 10, 20);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (33, 11, 18);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (34, 6, 23);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (35, 6, 24);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (36, 6, 25);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (37, 12, 1);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (39, 10, 17);
INSERT INTO `tbl_privilege_submenu` (`id_privilege_submenu`, `privilege_id`, `submenu_id`) VALUES (41, 10, 13);


#
# TABLE STRUCTURE FOR: tbl_request_toko
#

DROP TABLE IF EXISTS `tbl_request_toko`;

CREATE TABLE `tbl_request_toko` (
  `id_request` bigint(20) NOT NULL AUTO_INCREMENT,
  `kode_request` varchar(100) DEFAULT NULL,
  `request_toko_id` bigint(20) DEFAULT NULL,
  `penerima_toko_id` bigint(20) DEFAULT NULL,
  `atribut_barang` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`atribut_barang`)),
  `pengirim` varchar(100) DEFAULT NULL,
  `status` text DEFAULT NULL COMMENT '"proses","terkirim","draft"',
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_request`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_request_toko` (`id_request`, `kode_request`, `request_toko_id`, `penerima_toko_id`, `atribut_barang`, `pengirim`, `status`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '111', '1', '2', NULL, NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tbl_role
#

DROP TABLE IF EXISTS `tbl_role`;

CREATE TABLE `tbl_role` (
  `id_role` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(100) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_role`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (1, 'Administrator', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (2, 'Inventory', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (3, 'Kasir', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (4, 'Customer', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (5, 'coba 2', 1);
INSERT INTO `tbl_role` (`id_role`, `role`, `is_active`) VALUES (8, 'wikwikwik', 1);


#
# TABLE STRUCTURE FOR: tbl_satuan
#

DROP TABLE IF EXISTS `tbl_satuan`;

CREATE TABLE `tbl_satuan` (
  `id_satuan` bigint(20) NOT NULL AUTO_INCREMENT,
  `satuan` varchar(255) NOT NULL,
  `is_active` int(11) DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_update` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_satuan`),
  KEY `index_satuan` (`id_satuan`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('1', 'KGS', 0, 'sistem', 'sistem', '2023-12-19 19:24:09', '2023-12-19 19:24:28');
INSERT INTO `tbl_satuan` (`id_satuan`, `satuan`, `is_active`, `user_input`, `user_update`, `created_at`, `updated_at`) VALUES ('2', 'METER', 1, 'sistem', 'sistem', '2023-12-19 19:24:14', '2023-12-19 19:24:14');


#
# TABLE STRUCTURE FOR: tbl_setting
#

DROP TABLE IF EXISTS `tbl_setting`;

CREATE TABLE `tbl_setting` (
  `id_setting` bigint(20) NOT NULL AUTO_INCREMENT,
  `instansi` varchar(255) NOT NULL,
  `kode_instansi` varchar(255) NOT NULL,
  `kode_kabupaten` bigint(20) DEFAULT NULL,
  `alamat_instansi` varchar(255) DEFAULT NULL,
  `owner` varchar(255) NOT NULL,
  `wa_instansi` varchar(255) NOT NULL,
  `tlp_instansi` varchar(255) NOT NULL,
  `ig_instansi` varchar(255) DEFAULT NULL,
  `fb_instansi` varchar(255) DEFAULT NULL,
  `email_instansi` varchar(255) DEFAULT NULL,
  `deskripsi_singkat` text DEFAULT NULL,
  `img_instansi` text DEFAULT NULL,
  PRIMARY KEY (`id_setting`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_setting` (`id_setting`, `instansi`, `kode_instansi`, `kode_kabupaten`, `alamat_instansi`, `owner`, `wa_instansi`, `tlp_instansi`, `ig_instansi`, `fb_instansi`, `email_instansi`, `deskripsi_singkat`, `img_instansi`) VALUES ('1', 'Ardhacodes', 'ardhacodes', '0', 'Sidoarjo', 'Ardhacodes', '628145676545', '0317888888', '', '', 'robby@ardhacodes.com', NULL, 'ardhacodes1703165210.jpeg');


#
# TABLE STRUCTURE FOR: tbl_submenu
#

DROP TABLE IF EXISTS `tbl_submenu`;

CREATE TABLE `tbl_submenu` (
  `id_submenu` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_submenu`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (1, 1, 'Dashboard', 'dashboard', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (2, 2, 'Role', 'role_akses', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (3, 2, 'Menu', 'access/menu', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (4, 2, 'Sub Menu', 'access/submenu', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (5, 3, 'Management Toko', 'toko/store_management', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (6, 3, 'Karyawan Toko', 'toko/karyawan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (7, 7, 'Setting Instansi', 'setting', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (8, 7, 'Backup Database', 'setting/backupdb', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (9, 2, 'User', 'user/index', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (10, 4, 'Kategori', 'barang/kategori', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (11, 4, 'Satuan', 'barang/satuan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (12, 4, 'Barang', 'barang/index', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (13, 4, 'Barang', 'barang/list', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (14, 5, 'Order', 'kasir/order', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (15, 4, 'Barang Masuk', 'barang/masuk', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (17, 4, 'Barang Toko', 'barang/barang_toko', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (18, 3, 'Diskon', 'toko/diskon', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (19, 5, 'Scan', 'kasir/scan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (20, 4, 'Barang Keluar', 'barang/keluar', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (21, 5, 'Sales order', 'kasir/sales_order', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (22, 5, 'Transaksi', 'kasir/transaksi', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (23, 6, 'Laporan Penjualan', 'laporan/penjualan', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (24, 6, 'Riwayat Transaksi', 'riwayat/transaksi', 0);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (25, 6, 'Laporan Transaksi', 'laporan/transaksi', 1);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (26, 2, 'Ahhhyeah', 'ayeh', 0);
INSERT INTO `tbl_submenu` (`id_submenu`, `menu_id`, `title`, `url`, `is_active`) VALUES (27, 6, 'kentir', 'paijo', 0);


#
# TABLE STRUCTURE FOR: tbl_toko
#

DROP TABLE IF EXISTS `tbl_toko`;

CREATE TABLE `tbl_toko` (
  `id_toko` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama_toko` varchar(255) NOT NULL,
  `alamat_toko` text NOT NULL,
  `notelp_toko` varchar(15) NOT NULL,
  `jenis` varchar(255) NOT NULL COMMENT 'MARKETPLACE | TOKO',
  `is_active` int(11) NOT NULL DEFAULT 1,
  `user_input` varchar(255) NOT NULL,
  `user_edit` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_toko`),
  KEY `index_toko` (`id_toko`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', 'Riskamart Market Place', 'Gayungsari', '62317874511', 'MARKETPLACE', 1, '', 'riska', '2023-12-20 23:09:45', '2023-12-20 02:15:47');
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', 'Brianmart', 'Gayungsariawd', '62317874512', 'TOKO', 1, '', 'brian', '2023-12-20 02:16:56', '2023-12-20 02:16:22');
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', 'Brianmart', 'Gayungsari', '0317874512', 'TOKO', 0, 'brian', 'brian', '2023-12-20 02:16:19', '2023-12-20 02:16:22');
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('4', 'sdssd', 'sdcdsdsad', '232323', 'TOKO', 1, 'Sinyo', NULL, '2023-12-20 20:25:31', NULL);
INSERT INTO `tbl_toko` (`id_toko`, `nama_toko`, `alamat_toko`, `notelp_toko`, `jenis`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('5', 'Ad possimus quasi a', 'qihalaed', '62876567890', 'MARKETPLACE', 1, 'Sinyo', NULL, '2023-12-20 20:25:43', NULL);


#
# TABLE STRUCTURE FOR: tbl_transaksi
#

DROP TABLE IF EXISTS `tbl_transaksi`;

CREATE TABLE `tbl_transaksi` (
  `id_transaksi` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) DEFAULT NULL,
  `kode_transaksi` text DEFAULT NULL,
  `terbayar` double DEFAULT 0 COMMENT 'Nominal Customer Membayar',
  `kembalian` double DEFAULT 0 COMMENT 'Nominal Kembalian Customer',
  `tagihan_cart` double DEFAULT NULL COMMENT 'Tagihan Keranjang',
  `total_diskon` double DEFAULT NULL COMMENT 'Jumlah Keseluruhan Diskon',
  `tagihan_after_diskon` double DEFAULT NULL COMMENT 'Tagihan Keranjang - Total Diskon',
  `total_biaya_kirim` double DEFAULT NULL COMMENT 'Jumlah Nominal Biaya Kirim',
  `total_tagihan` double DEFAULT NULL COMMENT 'Total Tagihan = Tagihan After Diskon + Biaya Kirim',
  `tipe_transaksi` varchar(255) DEFAULT NULL COMMENT '"TRANSFER","TUNAI"',
  `bukti_tf` text DEFAULT NULL,
  `is_active` int(11) DEFAULT 1,
  `user_input` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `index_kodetrans` (`kode_transaksi`(1000)),
  KEY `index_transaksi` (`id_transaksi`,`order_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('1', '1', 'INV-2023120000000001', '520000', '0', '420000', '0', '420000', '100000', '520000', 'transfer', 'bukti-bayar-2023-12-19-19-50-25.jpeg', 1, 'Sinyo', NULL, '2023-12-19 19:50:25', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('2', '2', 'INV-2023120000000002', '90000000', '89920000', '80000', '0', '80000', '0', '80000', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-19 19:55:03', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('3', '3', 'INV-2023120000000003', '90000000', '89920000', '80000', '0', '80000', '0', '80000', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-19 19:55:10', NULL);
INSERT INTO `tbl_transaksi` (`id_transaksi`, `order_id`, `kode_transaksi`, `terbayar`, `kembalian`, `tagihan_cart`, `total_diskon`, `tagihan_after_diskon`, `total_biaya_kirim`, `total_tagihan`, `tipe_transaksi`, `bukti_tf`, `is_active`, `user_input`, `user_edit`, `created_at`, `updated_at`) VALUES ('4', '4', 'INV-2023120000000004', '90000000', '89920000', '80000', '0', '80000', '10000', '90000', 'TUNAI', NULL, 1, 'Kasir bunda', NULL, '2023-12-19 19:55:58', NULL);


#
# TABLE STRUCTURE FOR: tbl_user
#

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `nama_user` varchar(200) NOT NULL,
  `password` varchar(225) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (2, 'admin', 'Usopp', '$2y$10$WRUAaHL29AiW5ZM4mZE2zeKD7QMcCCaflL9RZsssmG8zy1PITaFPG', 1, 1, '2023-10-13 15:23:01', '2023-12-20 06:32:03');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (3, 'admin2', 'Admin', '$2y$10$wra8TkSEoRd5kgF2XkEZsO3axZZ1ojfazE9Q3z5z3S6pNUGIh7k6y', 1, 1, '2023-10-14 10:59:56', '2023-10-14 11:00:18');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (4, 'robby@ardhacodes.com', 'Sinyo', '$2y$10$LehzOBWPnnLpkjTMN4V3fON8golwh6AqGhS5EzLWZ1qLBeHqJwvPC', 1, 1, '2023-10-14 11:01:17', '2023-10-29 10:40:24');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (20, 'sincan', 'Sincan', '$2y$10$.nMGzeSIX1lN1BMWZ2MpgOUGzZljfQ7Iy.uPxH1n0J9yx7KLVHAd.', 4, 1, '2023-10-19 14:46:32', '2023-10-19 17:10:39');
INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES (23, 'kasirbunda', 'Kasir bunda', '$2y$10$zEOrSj4FjkhdIZ24MZtdPO8i4TIzroZop4fMgmzd0hHVC64JhwdNK', 3, 1, '2023-11-16 07:23:21', NULL);


