 <!-- Footer -->
 <footer class="content-footer footer bg-footer-theme">
     <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
         <div class="mb-2 mb-md-0">
             © <script>
                 document.write(new Date().getFullYear())
             </script>
             , made with ❤️ by <a href="<?= DOMAIN_MARKETPLACE ?>" target="_blank" class="footer-link fw-medium"><?= $_ENV['NAME_APP'] ?></a>
         </div>

     </div>
 </footer>
 <!-- / Footer -->

 <div class="content-backdrop fade"></div>
 </div>
 <!-- Content wrapper -->
 </div>
 <!-- / Layout page -->
 </div>

 <!-- Overlay -->
 <div class="layout-overlay layout-menu-toggle"></div>

 </div>

 <!-- / Layout wrapper -->