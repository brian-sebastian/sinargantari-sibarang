<?php

if (isset($content) && !empty($content)) {

    $this->load->view($content);
}
