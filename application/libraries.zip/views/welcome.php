<div>
<img src="<?php echo $barcode; ?>">
</div>
