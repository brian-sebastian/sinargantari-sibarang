<div class="table-responsive">
    <table class="table table-bordered table-nowrap mb-0">
        <thead>
            <tr>
                <th scope="col" class="text-center">Menu</th>
                <th scope="col" class="text-center">Sub-Menu</th>
            </tr>
        </thead>
        <tbody>
            <?= $data_order; ?>
        </tbody>
    </table>
</div>