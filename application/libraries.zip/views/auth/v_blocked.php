<!-- Content -->

<!-- Error -->
<div class="container-xxl container-p-y">
  <div class="misc-wrapper">
    <h2 class="mb-2 mx-2">401 Unauthorized Access</h2>
    <p class="mb-4 mx-2">Oops! 😖 You Don't Have Acces To This Page</p>
    <div class="mt-3">
      <!-- <lottie-player autoplay controls loop mode="normal" src="https://assets3.lottiefiles.com/packages/lf20_UJNc2t.json" background="transparent" style="width: 320px">
        </lottie-player> -->
      <lottie-player autoplay loop mode="normal" src="<?= base_url('assets/be/lottie/kucing-lag.json') ?>" background="transparent" style="width: 400px">
      </lottie-player>

    </div>
    <a href="<?= base_url('auth/err_acces') ?>" class="btn btn-danger">Go Back</a>
  </div>
</div>
<!-- /Error -->

<!-- / Content -->