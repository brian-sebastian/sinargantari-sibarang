<?php
function getReport($report_type, $data)
{
    switch ($report_type) {
        case 'penjualan':
            break;
        case 'transaksi':
            break;
        case 'barang_masuk':
            break;
        case 'barang_keluar':
            break;
        default:
    }
}
